from django.urls import path
from . import views

app_name='User'

urlpatterns = [
    path('dashboard/', views.dashboard, name='user_dashboard'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('register/', views.user_register, name='register'),
    path('profile/', views.view_profile, name='view_profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('profile/upload_resume/', views.upload_resume, name='upload_resume'),
    path('jobs/', views.job_list, name='job_list'),
    path('jobs/<int:job_id>/', views.job_detail, name='job_detail'),
    path('jobs/<int:job_id>/apply/', views.apply_to_job, name='apply_to_job'),
    path('applied-jobs/', views.applied_jobs, name='applied_jobs'),
]
