from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import UserProfile, JobApplication
from Administrator.models import Job
from django.core.files.storage import FileSystemStorage
from django.db import IntegrityError


def user_register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        resume = request.FILES.get('resume')

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('User:register')

        try:
            user = UserProfile.objects.create(
                name=name,
                email=email,
                mobile=mobile,
                password=password,  
                resume=resume
            )
            request.session['user_id'] = user.id
            return redirect('User:login')
        except IntegrityError:
            messages.error(request, "Email already exists.")
            return redirect('User:register')

    return render(request, 'User/register.html')


def user_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            user = UserProfile.objects.get(email=email, password=password)
            request.session['user_id'] = user.id
            return redirect('User:user_dashboard')
        except UserProfile.DoesNotExist:
            messages.error(request, "Invalid credentials.")
            return redirect('User:login')
    return render(request, 'User/login.html')


def user_logout(request):
    request.session.flush()
    return redirect('Administrator:index')




def dashboard(request):
    if 'user_id' not in request.session:
        return redirect('User:login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])
    applications = JobApplication.objects.filter(user=user).select_related('job')
    return render(request, 'User/dashboard.html', {
        'user': user,
        'applications': applications
    })



def view_profile(request):
    if 'user_id' not in request.session:
        return redirect('User:login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])
    return render(request, 'User/profile.html', {'user': user})


def edit_profile(request):
    if 'user_id' not in request.session:
        return redirect('User:login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])

    if request.method == 'POST':
        user.name = request.POST['name']
        user.email = request.POST['email']
        user.mobile = request.POST['mobile']
        user.save()
        messages.success(request, "Profile updated.")
        return redirect('User:view_profile')

    return render(request, 'User/edit_profile.html', {'user': user})


def upload_resume(request):
    if 'user_id' not in request.session:
        return redirect('User:login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])

    if request.method == 'POST' and 'resume' in request.FILES:
        user.resume = request.FILES['resume']
        user.save()
        messages.success(request, "Resume uploaded successfully.")
        return redirect('User:view_profile')

    return render(request, 'User/upload_resume.html', {'user': user})



def job_list(request):
    if 'user_id' not in request.session:
        return redirect('User:login')

    title_query = request.GET.get('title', '')
    location_query = request.GET.get('location', '')
    skills_query = request.GET.get('skills', '')
    experience_query = request.GET.get('experience', '')

    jobs = Job.objects.all()

    if title_query:
        jobs = jobs.filter(title__icontains=title_query)
    if location_query:
        jobs = jobs.filter(location__icontains=location_query)
    if skills_query:
        jobs = jobs.filter(skills_required__icontains=skills_query)
    if experience_query:
        jobs = jobs.filter(experience__icontains=experience_query)

    context = {
        'jobs': jobs,
        'title_query': title_query,
        'location_query': location_query,
        'skills_query': skills_query,
        'experience_query': experience_query,
    }
    return render(request, 'User/job_list.html', context)

def job_detail(request, job_id):
    if 'user_id' not in request.session:
        return redirect('User:login')

    job = get_object_or_404(Job, id=job_id)
    user = get_object_or_404(UserProfile, id=request.session['user_id'])
    already_applied = JobApplication.objects.filter(user=user, job=job).exists()

    return render(request, 'User/job_detail.html', {
        'job': job,
        'already_applied': already_applied
    })


def apply_to_job(request, job_id):
    if 'user_id' not in request.session:
        return redirect('User:login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])
    job = get_object_or_404(Job, id=job_id)

    if JobApplication.objects.filter(user=user, job=job).exists():
        messages.info(request, "You have already applied for this job.")
    else:
        JobApplication.objects.create(user=user, job=job)
        messages.success(request, "Application submitted.")

    return redirect('User:job_detail', job_id=job.id)


def applied_jobs(request):
    if 'user_id' not in request.session:
        return redirect('User:login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])
    applications = JobApplication.objects.filter(user=user).select_related('job')

    return render(request, 'User/applied_jobs.html', {'applications': applications})
