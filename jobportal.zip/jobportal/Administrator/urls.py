from django.urls import path
from . import views

app_name='Administrator'

urlpatterns = [
    path('index/',views.index,name='index'),
    path('Adminlogin/', views.login_view, name='Adminlogin'),
    path('logout/', views.logout_view, name='Adminlogout'),
    path('dashboard/', views.dashboard, name='admin_dashboard'),
    path('view-users/', views.view_users, name='view_users'),
    path('delete-user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('jobs/create/', views.create_job, name='create_job'),
    path('jobs/', views.view_all_jobs, name='view_all_jobs'),
    path('jobs/edit/<int:job_id>/', views.edit_job, name='edit_job'),
    path('jobs/delete/<int:job_id>/', views.delete_job, name='delete_job'),
    path('jobs/<int:job_id>/applications/', views.view_applications, name='view_applications'),
    path('jobs/<int:job_id>/applications/<int:user_id>/', views.view_applicant_detail, name='view_applicant_detail'),
    path('users/', views.view_users, name='view_users'),
    path('users/delete/<int:user_id>/', views.delete_user, name='delete_user'),
]
