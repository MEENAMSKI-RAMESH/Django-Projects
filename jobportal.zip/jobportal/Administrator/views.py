from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import HttpResponse
from Administrator.models import AdminTable, Job,Application
from User.models import JobApplication, UserProfile
from django.core.files.storage import FileSystemStorage
from django.db.models import Count

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            admin_user = AdminTable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin_user.id
            return redirect('Administrator:admin_dashboard')
        except AdminTable.DoesNotExist:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'Administrator/login.html')

def logout_view(request):
    request.session.flush()
    return redirect('Administrator:index')

def index(request):
    return render(request, 'Administrator/index.html')

def dashboard(request):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    jobs = Job.objects.all()

    job_data = []
    for job in jobs:
        count = JobApplication.objects.filter(job=job).count()
        job_data.append({
            'job': job,
            'application_count': count,
        })

    return render(request, 'Administrator/dashboard.html', {
        'job_data': job_data,
    })
def create_job(request):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    if request.method == 'POST':
        title = request.POST['title']
        company_name = request.POST['company_name']
        description = request.POST['description']
        skills_required = request.POST['skills_required']
        experience = request.POST['experience']
        salary = request.POST['salary']
        location = request.POST['location']
        deadline = request.POST['deadline']
        
        Job.objects.create(
            title=title,
            company_name=company_name,
            description=description,
            skills_required=skills_required,
            experience=experience,
            salary=salary,
            location=location,
            deadline=deadline
        )
        messages.success(request, "Job posted successfully.")
        return redirect('Administrator:view_all_jobs')

    return render(request, 'Administrator/create_job.html')

def view_all_jobs(request):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    jobs = Job.objects.all().order_by('-created_at')
    return render(request, 'Administrator/view_jobs.html', {'jobs': jobs})

def edit_job(request, job_id):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    job = get_object_or_404(Job, id=job_id)

    if request.method == 'POST':
        job.title = request.POST['title']
        job.company_name = request.POST['company_name']
        job.description = request.POST['description']
        job.skills_required = request.POST['skills_required']
        job.experience = request.POST['experience']
        job.salary = request.POST['salary']
        job.location = request.POST['location']
        job.deadline = request.POST['deadline']
        job.save()
        messages.success(request, "Job updated successfully.")
        return redirect('Administrator:view_all_jobs')

    return render(request, 'Administrator/edit_job.html', {'job': job})

def delete_job(request, job_id):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    job = get_object_or_404(Job, id=job_id)
    job.delete()
    messages.success(request, "Job deleted successfully.")
    return redirect('Administrator:view_all_jobs')

def view_applications(request, job_id):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    job = get_object_or_404(Job, id=job_id)
    applications = JobApplication.objects.filter(job=job).select_related('user')  # assuming 'user' FK exists

    return render(request, 'Administrator/view_applications.html', {
        'job': job,
        'applications': applications,
    })

def view_applicant_detail(request, job_id, user_id):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    application = get_object_or_404(JobApplication, job_id=job_id, id=user_id)
    return render(request, 'Administrator/view_applicant_detail.html', {
        'application': application
    })

def view_users(request):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    users = UserProfile.objects.all().order_by('-created_at')

    return render(request, 'Administrator/view_users.html', {'users': users})


def delete_user(request, user_id):
    if 'admin_id' not in request.session:
        return redirect('Administrator:Adminlogin')

    user = get_object_or_404(UserProfile, id=user_id)
    user.delete()
    messages.success(request, 'User deleted successfully.')
    return redirect('Administrator:view_users')