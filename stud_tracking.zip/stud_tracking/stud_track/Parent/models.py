from django.db import models

from Administrator.models import Faculty

# Create your models here.
