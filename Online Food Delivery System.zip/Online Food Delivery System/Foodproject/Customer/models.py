from django.db import models
from django.utils import timezone
from Administrator.models import Restaurant, Order,Customer


class CustomerAddress(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    address = models.TextField()
    landmark = models.CharField(max_length=100, blank=True, null=True)  
    pincode = models.CharField(max_length=10)
    is_default = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.customer.name} - {self.address[:30]}"


class PaymentMethod(models.Model):
    PAYMENT_CHOICES = (
        ('Card', 'Card'),
        ('UPI', 'UPI'),
        ('Wallet', 'Wallet'),
        ('COD', 'Cash on Delivery'),
    )
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    payment_type = models.CharField(max_length=20, choices=PAYMENT_CHOICES)
    provider = models.CharField(max_length=50, blank=True)  
    account_number = models.CharField(max_length=30, blank=True) 

    def __str__(self):
        return f"{self.customer.name} - {self.payment_type}"

class CartItem(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    food_item = models.ForeignKey('Owner.FoodItem', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.customer.name} - {self.food_item.name} x {self.quantity}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    food_item = models.ForeignKey('Owner.FoodItem', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price_at_order_time = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"{self.order.id} - {self.food_item.name} x {self.quantity}"

class Wallet(models.Model):
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.customer.name} Wallet - ₹{self.balance}"

class WalletTransaction(models.Model):
    wallet = models.ForeignKey(Wallet, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_type = models.CharField(max_length=10, choices=(('Credit', 'Credit'), ('Debit', 'Debit')))
    description = models.CharField(max_length=200)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.wallet.customer.name} - {self.transaction_type} ₹{self.amount}"

class DeliveryChat(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    delivery_agent_name = models.CharField(max_length=100)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    message = models.TextField()
    sender = models.CharField(max_length=100)  
    sent_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.customer.name} ↔ {self.delivery_agent_name}"

class FoodReview(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    food_item = models.ForeignKey('Owner.FoodItem', on_delete=models.CASCADE)
    order_item = models.ForeignKey(OrderItem, on_delete=models.CASCADE, null=True, blank=True)
    rating = models.IntegerField()
    review = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.customer.name} - {self.food_item.name} ⭐{self.rating}"
