from django.urls import path
from . import views

app_name = 'Customer'

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='customerlogin'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/', views.profile, name='profile'),
    path('profile/update/', views.update_profile, name='update_profile'),
    path('addresses/', views.manage_addresses, name='manage_addresses'),
    path('addresses/add/', views.add_address, name='add_address'),
     path('addresses/edit/<int:address_id>/', views.edit_address, name='edit_address'),
     path('addresses/delete/<int:address_id>/', views.delete_address, name='delete_address'),
    path('payment-methods/', views.payment_methods, name='payment_methods'),
    path('restaurants/', views.restaurant_list, name='restaurant_list'),
    path('restaurant/<int:restaurant_id>/', views.view_menu, name='view_menu'),
    path('search/', views.search_restaurants, name='search_restaurants'),
    path('cart/', views.view_cart, name='view_cart'),
    path('cart/add/<int:item_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/<int:item_id>/', views.checkout_item, name='checkout_item'),
    path('place-order/', views.place_order, name='place_order'),
    path('orders/current/', views.current_orders, name='current_orders'),
    path('orders/track/<int:order_id>/', views.track_order, name='track_order'),
    path('orders/review/<int:order_id>/', views.rate_review, name='rate_review'),
    path('orders/history/', views.order_history, name='order_history'),
    path('orders/reorder/<int:order_id>/', views.reorder, name='reorder'),
    path('wallet/', views.wallet, name='wallet'),
    path('wallet/add/', views.add_to_wallet, name='add_to_wallet'),
    path('wallet/apply-cashback/', views.apply_cashback, name='apply_cashback'),
    path('chat/<int:order_id>/', views.chat_with_delivery, name='chat_with_delivery'),
]
