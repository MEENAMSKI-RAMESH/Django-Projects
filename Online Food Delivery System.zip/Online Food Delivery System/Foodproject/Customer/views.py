# customer/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from Customer.models import (
    CustomerAddress,
    PaymentMethod,
    CartItem,
    Wallet,
    WalletTransaction,
    FoodReview,
)
from Owner.models import FoodItem, FoodCategory  
from Administrator.models import Customer, Feedback, Restaurant, Order
from Customer.models import DeliveryChat, OrderItem
from decimal import Decimal, InvalidOperation
from django.contrib import messages
from django.contrib.auth.hashers import check_password
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password

from django.contrib import messages
from django.contrib.auth.hashers import make_password  
from django.shortcuts import render, redirect

def register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        password = request.POST.get('password')  

        if Customer.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect('Administrator:add_owner')

        Customer.objects.create(
            name=name,
            email=email,
            address=address,
            phone=phone,
            password=password
        )
        messages.success(request, "User added successfully.")
        return redirect('Customer:customerlogin')
    return render(request, 'Customer/register.html')

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            customer = Customer.objects.get(email=email, password=password)
            request.session['Customer_id'] = customer.id
            request.session['Customer_name'] = customer.name
            messages.success(request, 'Login successful!')
            return redirect('Customer:dashboard')
        except Customer.DoesNotExist:
            messages.error(request, 'Invalid email or password.')

    return render(request, 'Customer/login.html')

from django.shortcuts import render, redirect, get_object_or_404
from .models import Customer, Order

def dashboard(request):
    if not request.session.get('Customer_id'):
        return redirect('Customer:customerlogin')

    cust = get_object_or_404(Customer, id=request.session['Customer_id'])

    latest_order = Order.objects.filter(customer=cust).order_by('-order_time').first()

    return render(request, 'Customer/dashboard.html', {
        'latest_order': latest_order
    })



def logout_view(request):
    request.session.flush()
    return redirect('index')

def customer_login_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.session.get('customer_id'):
            return view_func(request, *args, **kwargs)
        return redirect('Customer:customerlogin')
    return wrapper

def profile(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    return render(request, 'Customer/profile.html', {'customer': cust})

def update_profile(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    if request.method == 'POST':
        cust.name = request.POST.get('name')
        cust.phone = request.POST.get('phone')
        cust.save()
        messages.success(request, 'Profile updated')
        return redirect('Customer:profile')
    return render(request, 'Customer/update_profile.html', {'customer': cust})

def manage_addresses(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    addresses = CustomerAddress.objects.filter(customer=cust)
    return render(request, 'Customer/addresses.html', {'addresses': addresses})


def add_address(request):
    if request.method == 'POST':
        cust = get_object_or_404(Customer, id=request.session['Customer_id'])
        address = request.POST.get('address')
        landmark = request.POST.get('landmark')
        pincode = request.POST.get('pincode')

        if all([address, pincode]):
            CustomerAddress.objects.create(
                customer=cust,
                address=address,
                landmark=landmark,
                pincode=pincode
            )
            messages.success(request, "Address added successfully.")
            return redirect('Customer:manage_addresses')
        else:
            messages.error(request, "Please fill in all required fields.")

    return render(request, 'Customer/add_address.html')

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages

def edit_address(request, address_id):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    address = get_object_or_404(CustomerAddress, id=address_id, customer=cust)

    if request.method == 'POST':
        address.address = request.POST.get('address')
        address.pincode = request.POST.get('pincode')
        address.landmark = request.POST.get('landmark', '')
        address.save()
        messages.success(request, "Address updated successfully.")
        return redirect('Customer:manage_addresses')

    return render(request, 'Customer/edit_address.html', {'address': address})

from django.contrib import messages

def delete_address(request, address_id):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    address = get_object_or_404(CustomerAddress, id=address_id, customer=cust)
    address.delete()
    messages.success(request, "Address deleted successfully.")
    return redirect('Customer:manage_addresses')


def payment_methods(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    methods = PaymentMethod.objects.filter(customer=cust)
    return render(request, 'Customer/payment_methods.html', {'methods': methods})

def restaurant_list(request):
    restaurants = Restaurant.objects.filter(is_approved=True)
    return render(request, 'Customer/restaurant_list.html', {'restaurants': restaurants})

def view_menu(request, restaurant_id):
    restaurant = Restaurant.objects.filter(id=restaurant_id).first()
    if not restaurant:
        messages.error(request, "Restaurant not found.")
        return redirect('Customer:restaurant_list')

    menu_items = FoodItem.objects.filter(restaurant_id=restaurant.id)
    return render(request, 'Customer/view_menu.html', {
        'restaurant': restaurant,
        'menu_items': menu_items  
    })



def search_restaurants(request):
    query = request.GET.get('q', '')
    results = Restaurant.objects.filter(name__icontains=query, is_approved=True)
    return render(request, 'Customer/search_results.html', {'results': results, 'query': query})



def view_cart(request):
    customer = get_object_or_404(Customer, id=request.session['Customer_id'])  
    cart_items = CartItem.objects.filter(customer=customer)
    cart_details = []
    total_price = 0

    for item in cart_items:
        item_total = item.quantity * item.food_item.price
        cart_details.append({
            'food_item': item.food_item,
            'quantity': item.quantity,
            'total': item_total,
        })
        total_price += item_total

    return render(request, 'Customer/cart.html', {
        'cart_items': cart_details,
        'total_price': total_price
    })



def add_to_cart(request, item_id):
    customer = get_object_or_404(Customer, id=request.session['Customer_id'])
    item = get_object_or_404(FoodItem, id=item_id, is_available=True)

    cart_item, created = CartItem.objects.get_or_create(customer=customer, food_item=item)
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    return redirect('Customer:view_cart')

from django.views.decorators.http import require_POST

@require_POST
def remove_from_cart(request, item_id):
    customer = get_object_or_404(Customer, id=request.session['Customer_id'])
    CartItem.objects.filter(customer=customer, food_item_id=item_id).delete()
    return redirect('Customer:view_cart')


def checkout_item(request, item_id):
    customer = get_object_or_404(Customer, id=request.session['Customer_id'])
    cart_items = CartItem.objects.filter(customer=customer)

    cart_data = []
    total_price = 0

    for item in cart_items:
        item_total = item.quantity * item.food_item.price
        cart_data.append({
            'food': item.food_item,
            'quantity': item.quantity,
            'total': item_total
        })
        total_price += item_total

    addresses = CustomerAddress.objects.filter(customer=customer)
    wallet, _ = Wallet.objects.get_or_create(customer=customer)
    transactions = WalletTransaction.objects.filter(wallet=wallet)

    return render(request, 'Customer/checkout.html', {
        'cart_items': cart_data,  
        'total_price': total_price,
        'addresses': addresses,
        'wallet_balance': wallet.balance,
    })


from decimal import Decimal
from django.db import transaction

def place_order(request):
    if request.method == 'POST':
        cust = get_object_or_404(Customer, id=request.session['Customer_id'])
        cart_items = CartItem.objects.filter(customer=cust)

        if not cart_items:
            messages.error(request, "Cart is empty.")
            return redirect('Customer:view_cart')

        address_id = request.POST.get('address')
        payment_method = request.POST.get('payment_method')

        total = sum(ci.quantity * ci.food_item.price for ci in cart_items)

        with transaction.atomic():
            order = Order.objects.create(
                customer=cust,
                restaurant=cart_items[0].food_item.restaurant,
                total_amount=total,
                status='Placed'
            )

            for ci in cart_items:
                OrderItem.objects.create(
                    order=order,
                    food_item=ci.food_item,
                    quantity=ci.quantity,
                    price_at_order_time=ci.food_item.price
                )

            if payment_method == 'Wallet':
                wallet = Wallet.objects.get(customer=cust)

                if wallet.balance < total:
                    messages.error(request, "Insufficient wallet balance.")
                    return redirect('Customer:checkout_item', item_id=cart_items[0].id)

                wallet.balance -= Decimal(total)
                wallet.save()

                WalletTransaction.objects.create(
                    wallet=wallet,
                    amount=total,
                    transaction_type='Debit',
                    description=f"Payment for Order #{order.id}"
                )

            elif payment_method == 'Cash on Delivery':
                pass

            if total >= 500:
                cashback_amount = Decimal('20.00')
                wallet = Wallet.objects.get(customer=cust)
                wallet.balance += cashback_amount
                wallet.save()

                WalletTransaction.objects.create(
                    wallet=wallet,
                    amount=cashback_amount,
                    transaction_type='Credit',
                    description=f"Cashback for Order #{order.id}"
                )

            cart_items.delete()
            messages.success(request, f"Order #{order.id} placed successfully.")
            return redirect('Customer:order_history')

    return redirect('Customer:view_cart')


def current_orders(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    orders = Order.objects.filter(customer=cust).exclude(status='Delivered').order_by('-order_time')
    return render(request, 'Customer/current_orders.html', {'orders': orders})


def track_order(request, order_id):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    order = get_object_or_404(Order, id=order_id, customer=cust)
    return render(request, 'Customer/track_order.html', {'order': order})

from django.shortcuts import render, get_object_or_404
from .models import Customer, Order

def order_history(request):
    customer_id = request.session.get('Customer_id')
    if not customer_id:
        return redirect('Customer:login')  
    
    cust = get_object_or_404(Customer, id=customer_id)
    orders = Order.objects.filter(customer=cust).order_by('-order_time') 

    return render(request, 'Customer/order_history.html', {'orders': orders})


def reorder(request, order_id):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    prev_order = get_object_or_404(Order, id=order_id, customer=cust)
    for item in prev_order.items.all():
        CartItem.objects.create(customer=cust, food_item=item.food_item, quantity=item.quantity)
    messages.success(request, f"Items from Order #{order_id} added to cart.")
    return redirect('Customer:view_cart')

from django.utils import timezone

from django.utils import timezone
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

def rate_review(request, order_id):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    order = get_object_or_404(Order, id=order_id, customer=cust)

    if request.method == 'POST':
        rating = int(request.POST.get('rating'))
        review_text = request.POST.get('review')

        for item in order.items.all():
            FoodReview.objects.create(
                customer=cust,
                food_item=item.food_item,
                order_item=item,
                rating=rating,
                review=review_text
            )

        Feedback.objects.create(
            customer=cust,
            restaurant=order.restaurant,
            rating=rating,
            comment=review_text,
            submitted_at=timezone.now()
        )

        messages.success(request, "Thank you for your feedback!")
        return redirect('Customer:order_history')

    print("Restaurant associated with order:", order.restaurant)

    return render(request, 'Customer/rate_review.html', {'order': order})



def wallet(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    wallet_obj, _ = Wallet.objects.get_or_create(customer=cust)
    transactions = WalletTransaction.objects.filter(wallet=wallet_obj)
    return render(request, 'Customer/wallet.html', {'wallet': wallet_obj, 'transactions': transactions})

def add_to_wallet(request):
    if request.method == 'POST':
        cust = get_object_or_404(Customer, id=request.session['Customer_id'])

        try:
            amount = Decimal(request.POST.get('amount'))
        except (TypeError, InvalidOperation):
            messages.error(request, "Invalid amount entered.")
            return redirect('Customer:wallet')

        wallet_obj, _ = Wallet.objects.get_or_create(customer=cust)
        wallet_obj.balance += amount
        wallet_obj.save()

        WalletTransaction.objects.create(
            wallet=wallet_obj,
            amount=amount,
            transaction_type='Credit',
            description='Add to wallet'
        )

        messages.success(request, "Wallet credited successfully.")
        return redirect('Customer:wallet')

    return render(request, 'Customer/add_wallet.html')

def apply_cashback(request):
    cust = get_object_or_404(Customer, id=request.session['Customer_id'])
    wallet_obj, _ = Wallet.objects.get_or_create(customer=cust)
    cashback = wallet_obj.balance * 0.05   
    wallet_obj.balance += cashback
    wallet_obj.save()
    WalletTransaction.objects.create(wallet=wallet_obj, amount=cashback,
                                     transaction_type='Credit', description='Cashback applied')
    messages.success(request, f"₹{cashback:.2f} credited as cashback.")
    return redirect('Customer:wallet')

from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import DeliveryChat, Order, Customer

def chat_with_delivery(request, order_id):
    customer_id = request.session.get('Customer_id')
    if not customer_id:
        return redirect('Customer:CustomerLogin')  

    customer = get_object_or_404(Customer, id=customer_id)
    order = get_object_or_404(Order, id=order_id, customer=customer)

    chats = DeliveryChat.objects.filter(order=order, customer=customer).order_by('sent_at')

    if request.method == 'POST':
        message = request.POST.get('message')
        if message:
            DeliveryChat.objects.create(
                customer=customer,
                order=order,
                delivery_agent_name="Customer",
                message=message,
                sender='Customer',
                sent_at=timezone.now()
            )
            return redirect('Customer:chat_with_delivery', order_id=order.id)

    return render(request, 'Customer/chat.html', {
        'chats': chats,
        'order_id': order.id
    })

