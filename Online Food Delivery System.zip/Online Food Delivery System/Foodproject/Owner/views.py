from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.utils import timezone
from .models import FoodCategory, FoodItem, Offer, InventoryItem, ChatMessage
from Administrator.models import RestaurantOwner, Restaurant, Order, Feedback
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from .models import ChatMessage  


def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            owner = RestaurantOwner.objects.get(email=email, password=password)
            request.session['owner_id'] = owner.id
            request.session['owner_name'] = owner.name
            messages.success(request, 'Login successful!')
            return redirect('Owner:owner_dashboard')
        except RestaurantOwner.DoesNotExist:
            messages.error(request, 'Invalid email or password.')

    return render(request, 'Owner/login.html')


def logout_view(request):
    request.session.flush()
    messages.success(request, 'Logged out successfully.')
    return redirect('index')


def owner_dashboard(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    try:
        owner = RestaurantOwner.objects.get(id=owner_id)
    except RestaurantOwner.DoesNotExist:
        return redirect('Owner:Ownerlogin')

    return render(request, 'Owner/dashboard.html', {'owner': owner})


def owner_profile(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    owner = get_object_or_404(RestaurantOwner, id=owner_id)
    restaurants = Restaurant.objects.filter(owner=owner)

    return render(request, 'Owner/profile.html', {
        'owner': owner,
        'restaurants': restaurants
    })


def update_profile(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    owner = get_object_or_404(RestaurantOwner, id=owner_id)

    if request.method == 'POST':
        owner.name = request.POST.get('name')
        owner.phone = request.POST.get('contact')
        owner.save()
        messages.success(request, "Profile updated successfully.")
        return redirect('Owner:profile')

    return render(request, 'Owner/update_profile.html', {'owner': owner})


def update_restaurant(request, restaurant_id):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = get_object_or_404(Restaurant, id=restaurant_id, owner_id=owner_id)

    if request.method == 'POST':
        restaurant.name = request.POST.get('name')
        restaurant.address = request.POST.get('address')
        restaurant.contact = request.POST.get('contact')
        restaurant.save()
        messages.success(request, 'Restaurant updated successfully.')
        return redirect('Owner:profile')

    return render(request, 'Owner/update_restaurant.html', {'restaurant': restaurant})


def view_menu(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    menu = FoodItem.objects.filter(restaurant=restaurant)
    return render(request, 'Owner/view_menu.html', {'items': menu})




def add_menu_item(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')
    categories = FoodCategory.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        category_id = request.POST.get('category')
        image = request.FILES.get('image')
        is_available = request.POST.get('is_available') == 'on'

        if not all([name, description, price, category_id]):
            messages.error(request, "All fields are required.")
            return render(request, 'Owner/add_menu_item.html', {'categories': categories})

        try:
            price = float(price)
        except ValueError:
            messages.error(request, "Invalid price format.")
            return render(request, 'Owner/add_menu_item.html', {'categories': categories})

        FoodItem.objects.create(
            restaurant=restaurant,
            name=name,
            description=description,
            price=price,
            is_available=is_available,
            category_id=category_id,
            image=image
        )
        messages.success(request, "Menu item added successfully!")
        return redirect('Owner:view_menu')

    return render(request, 'Owner/add_menu_item.html', {'categories': categories})


def add_category(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        if name:
            FoodCategory.objects.create(name=name)
            messages.success(request, 'Category added successfully!')
            return redirect('Owner:add_menu_item')
        else:
            messages.error(request, 'Category name cannot be empty.')

    return render(request, 'Owner/add_category.html')

def edit_menu_item(request, item_id):
    item = get_object_or_404(FoodItem, id=item_id)

    if request.method == 'POST':
        item.name = request.POST.get('name')
        item.description = request.POST.get('description')
        item.price = request.POST.get('price')
        item.is_available = request.POST.get('is_available') == 'on'
        item.category_id = request.POST.get('category')
        if request.FILES.get('image'):
            item.image = request.FILES.get('image')
        item.save()
        return redirect('Owner:view_menu')

    return render(request, 'Owner/edit_menu_item.html', {'item': item})


def delete_menu_item(request, item_id):
    item = get_object_or_404(FoodItem, id=item_id)
    item.delete()
    return redirect('Owner:view_menu')


def view_orders(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    orders = Order.objects.filter(restaurant=restaurant).order_by('-order_time')
    return render(request, 'Owner/view_orders.html', {'orders': orders})


def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)

    if request.method == 'POST':
        order.status = request.POST.get('status')
        order.save()
        return redirect('Owner:view_orders')

    return render(request, 'Owner/update_order_status.html', {'order': order})


def view_offers(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    offers = Offer.objects.filter(restaurant=restaurant)
    return render(request, 'Owner/view_offers.html', {'offers': offers})


def add_offer(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    if request.method == 'POST':
        Offer.objects.create(
            restaurant=restaurant,
            title=request.POST.get('title'),
            code=request.POST.get('code'),
            discount_percent=request.POST.get('discount_percent'),
            valid_from=request.POST.get('valid_from'),
            valid_until=request.POST.get('valid_until')
        )
        return redirect('Owner:view_offers')

    return render(request, 'Owner/add_offer.html')


def edit_offer(request, offer_id):
    offer = get_object_or_404(Offer, id=offer_id)

    if request.method == 'POST':
        offer.title = request.POST.get('title')
        offer.code = request.POST.get('code')
        offer.discount_percent = request.POST.get('discount_percent')
        offer.valid_from = request.POST.get('valid_from')
        offer.valid_until = request.POST.get('valid_until')
        offer.save()
        return redirect('Owner:view_offers')

    return render(request, 'Owner/edit_offer.html', {'offer': offer})


def delete_offer(request, offer_id):
    offer = get_object_or_404(Offer, id=offer_id)
    offer.delete()
    return redirect('Owner:view_offers')

def view_reviews(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    reviews = Feedback.objects.filter(restaurant=restaurant).order_by('-submitted_at')
    return render(request, 'Owner/view_reviews.html', {'reviews': reviews})


def view_inventory(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    items = InventoryItem.objects.filter(restaurant=restaurant)
    return render(request, 'Owner/view_inventory.html', {'items': items})

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import InventoryItem, Restaurant

def add_inventory(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "Restaurant not found.")
        return redirect('Owner:owner_dashboard')

    if request.method == 'POST':
        name = request.POST.get('name')
        quantity = request.POST.get('quantity')
        unit = request.POST.get('unit')

        if name and quantity and unit:
            InventoryItem.objects.create(
                restaurant=restaurant,
                name=name,
                quantity=quantity,
                unit=unit
            )
            messages.success(request, "Item added to inventory.")
            return redirect('Owner:view_inventory')
        else:
            messages.error(request, "All fields are required.")

    return render(request, 'Owner/add_inventory.html')


def update_inventory(request, item_id):
    item = get_object_or_404(InventoryItem, id=item_id)

    if request.method == 'POST':
        item.quantity = request.POST.get('quantity')
        item.unit = request.POST.get('unit')
        item.save()
        return redirect('Owner:view_inventory')

    return render(request, 'Owner/update_inventory.html', {'item': item})


def sales_dashboard(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    orders = Order.objects.filter(restaurant=restaurant)
    total_sales = sum(order.total_amount for order in orders)
    total_orders = orders.count()

    context = {
        'total_sales': total_sales,
        'total_orders': total_orders,
        'orders': orders
    }
    return render(request, 'Owner/sales_dashboard.html', context)



from django.utils import timezone
from Customer.models import DeliveryChat, Customer 

def live_chat(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('Owner:Ownerlogin')

    restaurant = Restaurant.objects.filter(owner_id=owner_id).first()
    if not restaurant:
        messages.error(request, "No restaurant found.")
        return redirect('Owner:owner_dashboard')

    delivery_chats = DeliveryChat.objects.filter(order__restaurant=restaurant).order_by('sent_at')

    if request.method == 'POST':
        message = request.POST.get('message')
        customer_id = request.POST.get('customer_id')
        order_id = request.POST.get('order_id')
        
        if message and customer_id and order_id:
            customer = Customer.objects.get(id=customer_id)
            DeliveryChat.objects.create(
                customer=customer,
                order_id=order_id,
                delivery_agent_name="Owner",
                message=message,
                sender='Owner',
                sent_at=timezone.now()
            )
            return redirect('Owner:live_chat')

    return render(request, 'Owner/live_chat.html', {
        'delivery_chats': delivery_chats,
    })
