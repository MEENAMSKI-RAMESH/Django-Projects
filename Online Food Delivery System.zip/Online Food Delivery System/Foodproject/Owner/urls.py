from django.urls import path
from . import views

app_name = 'Owner'

urlpatterns = [
    path('login/', views.login_view, name='Ownerlogin'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.owner_profile, name='profile'),
    path('profile/update/', views.update_profile, name='update_profile'),
    path('update-restaurant/<int:restaurant_id>/', views.update_restaurant, name='update_restaurant'),
    path('menu/', views.view_menu, name='view_menu'),
    path('category/add/', views.add_category, name='add_category'),
    path('menu/add/', views.add_menu_item, name='add_menu_item'),
    path('menu/edit/<int:item_id>/', views.edit_menu_item, name='edit_menu_item'),
    path('menu/delete/<int:item_id>/', views.delete_menu_item, name='delete_menu_item'),
    path('orders/', views.view_orders, name='view_orders'),
    path('orders/update/<int:order_id>/', views.update_order_status, name='update_order_status'),
    path('offers/', views.view_offers, name='view_offers'),
    path('offers/add/', views.add_offer, name='add_offer'),
    path('offers/edit/<int:offer_id>/', views.edit_offer, name='edit_offer'),
    path('offers/delete/<int:offer_id>/', views.delete_offer, name='delete_offer'),
    path('reviews/', views.view_reviews, name='view_reviews'),
    path('inventory/', views.view_inventory, name='view_inventory'),
    path('inventory/add/', views.add_inventory, name='add_inventory'),

    path('inventory/update/<int:item_id>/', views.update_inventory, name='update_inventory'),
    path('sales/dashboard/', views.sales_dashboard, name='sales_dashboard'),
    path('chat/', views.live_chat, name='live_chat'),
    path('dashboard/', views.owner_dashboard, name='owner_dashboard'),
] 
