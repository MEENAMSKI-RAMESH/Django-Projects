from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Admintable, RestaurantOwner, Customer, Restaurant, Order, Feedback, SalesReport, FraudDetection
from django.contrib import messages
from Customer.models import OrderItem
from datetime import date
from django.db.models import Sum, Count
from django.db.models.functions import TruncDate
from .models import Order, Customer

def index(request):
    return render(request, 'index.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            admin = Admintable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin.id
            return redirect('Administrator:admin_dashboard')
        except Admintable.DoesNotExist:
            messages.error(request, 'Invalid login credentials.')
            return redirect('Administrator:login')
    return render(request, 'Administrator/login.html')


def logout(request):
    request.session.flush()
    return redirect('index')



def view_restaurant_owners(request):
    owners = RestaurantOwner.objects.all()
    return render(request, 'Administrator/view_restaurant_owners.html', {'owners': owners})


def verify_restaurant_owner(request, owner_id):
    owner = get_object_or_404(RestaurantOwner, id=owner_id)
    owner.is_verified = True
    owner.save()
    return redirect('Administrator:view_restaurant_owners')


def view_customers(request):
    customers = Customer.objects.all()
    return render(request, 'Administrator/view_customers.html', {'customers': customers})


def delete_customer(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    customer.delete()
    return redirect('Administrator:view_customers')



def view_restaurants(request):
    restaurants = Restaurant.objects.all()
    return render(request, 'Administrator/view_restaurants.html', {'restaurants': restaurants})


def add_owner(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')  

        if RestaurantOwner.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect('Administrator:add_owner')

        RestaurantOwner.objects.create(
            name=name,
            email=email,
            phone=phone,
            password=password
        )
        messages.success(request, "Owner added successfully.")
        return redirect('Administrator:view_restaurant_owners')
    return render(request, 'Administrator/add_owner.html')

def delete_owner(request, owner_id):
    owner = get_object_or_404(RestaurantOwner, id=owner_id)
    owner.delete()
    return redirect('Administrator:view_restaurant_owners')



def add_restaurant(request):
    if request.method == "POST":
        name = request.POST.get('name')
        address = request.POST.get('address')
        contact = request.POST.get('contact')
        owner_id = request.POST.get('owner')

        owner = get_object_or_404(RestaurantOwner, id=owner_id)

        Restaurant.objects.create(
            name=name,
            address=address,
            contact=contact,
            owner=owner
        )

        return redirect('Administrator:view_restaurants')

    owners = RestaurantOwner.objects.all()
    return render(request, 'Administrator/add_restaurant.html', {'owners': owners})


def edit_restaurant(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if request.method == "POST":
        restaurant.name = request.POST.get('name')
        restaurant.address = request.POST.get('address')
        restaurant.contact = request.POST.get('contact')
        restaurant.save()
        return redirect('Administrator:view_restaurants')
    return render(request, 'Administrator/edit_restaurant.html', {'restaurant': restaurant})


def delete_restaurant(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    restaurant.delete()
    return redirect('Administrator:view_restaurants')


def approve_restaurant(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    restaurant.is_approved = True
    restaurant.save()
    return redirect('Administrator:view_restaurants')


def reject_restaurant(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    restaurant.is_approved = False
    restaurant.save()
    return redirect('Administrator:view_restaurants')



def view_all_orders(request):
    orders = Order.objects.all()
    return render(request, 'Administrator/view_all_orders.html', {'orders': orders})


def resolve_order_issue(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    order.status = 'Cancelled'
    order.save()
    return redirect('Administrator:view_all_orders')




def generate_sales_report(request):
    order_data = (
        Order.objects.filter(status='Delivered')
        .annotate(date=TruncDate('order_time'))
        .values('date')
        .annotate(total_sales=Sum('total_amount'))
        .order_by('date')
    )

    user_data = (
        Customer.objects.annotate(date=TruncDate('registered_on'))
        .values('date')
        .annotate(new_users=Count('id'))
    )

    user_data_dict = {entry['date']: entry['new_users'] for entry in user_data}

    labels = []
    sales_data = []
    new_users_data = []

    for entry in order_data:
        date = entry['date']
        labels.append(date.strftime('%Y-%m-%d'))
        sales_data.append(float(entry['total_sales']))
        new_users_data.append(user_data_dict.get(date, 0))
    print("Labels:", labels)
    print("Sales Data:", sales_data)
    print("New Users:", new_users_data)

    return render(request, 'Administrator/generate_sales_report.html', {
        'labels': labels,
        'sales_data': sales_data,
        'new_users_data': new_users_data,
    })



def generate_top_items_report(request):
    top_items_qs = (
        OrderItem.objects
        .values('food_item__name')  
        .annotate(total_quantity=Count('id'))
        .order_by('-total_quantity')[:5]
    )

    item_labels = [item['food_item__name'] for item in top_items_qs]
    item_data = [item['total_quantity'] for item in top_items_qs]

    return render(request, 'Administrator/top_items.html', {
        'top_items': top_items_qs,
        'item_labels': item_labels,
        'item_data': item_data,
    })



def generate_user_growth_report(request):
    today = date.today()
    new_customers = Customer.objects.filter(registered_on__month=today.month).count()
    new_owners = RestaurantOwner.objects.filter(registered_on__month=today.month).count()
    return render(request, 'Administrator/user_growth.html', {
        'new_customers': new_customers,
        'new_owners': new_owners
    })



def view_feedback(request):
    feedbacks = Feedback.objects.all()
    return render(request, 'Administrator/view_feedback.html', {'feedbacks': feedbacks})


def delete_feedback(request, feedback_id):
    feedback = get_object_or_404(Feedback, id=feedback_id)
    feedback.delete()
    return redirect('Administrator:view_feedback')



def admin_dashboard(request):
    total_restaurants = Restaurant.objects.count()
    customer_count = Customer.objects.count()
    owner_count = RestaurantOwner.objects.count()
    total_orders = Order.objects.count()
    total_sales = sum(order.total_amount for order in Order.objects.all())
    
    context = {
        'total_restaurants': total_restaurants,
        'customer_count': customer_count,
        'owner_count': owner_count,
        'total_users': customer_count + owner_count,
        'total_sales': total_sales,
        'total_orders': total_orders
    }
    return render(request, 'Administrator/dashboard.html', context)



def detect_fraud_activity(request):
    frauds = FraudDetection.objects.all()
    return render(request, 'Administrator/detect_fraud_activity.html', {'frauds': frauds})
