from django.urls import path
from . import views

app_name='Administrator'

urlpatterns = [
    path('login/', views.login, name='Administratorlogin'),
    path('logout/', views.logout, name='logout'),
    path('owners/', views.view_restaurant_owners, name='view_restaurant_owners'),
    path('owners/add/', views.add_owner, name='add_owner'),
    path('owners/delete/<int:owner_id>/', views.delete_owner, name='delete_owner'),
    path('owners/verify/<int:owner_id>/', views.verify_restaurant_owner, name='verify_restaurant_owner'),
    path('customers/', views.view_customers, name='view_customers'),
    path('customers/delete/<int:customer_id>/', views.delete_customer, name='delete_customer'),

    path('restaurants/', views.view_restaurants, name='view_restaurants'),
    path('restaurants/add/', views.add_restaurant, name='add_restaurant'),
    path('restaurants/edit/<int:restaurant_id>/', views.edit_restaurant, name='edit_restaurant'),
    path('restaurants/delete/<int:restaurant_id>/', views.delete_restaurant, name='delete_restaurant'),
    path('restaurants/approve/<int:restaurant_id>/', views.approve_restaurant, name='approve_restaurant'),
    path('restaurants/reject/<int:restaurant_id>/', views.reject_restaurant, name='reject_restaurant'),

    path('orders/', views.view_all_orders, name='view_all_orders'),
    path('orders/resolve/<int:order_id>/', views.resolve_order_issue, name='resolve_order_issue'),

    path('reports/sales/', views.generate_sales_report, name='generate_sales_report'),
    path('reports/top-items/', views.generate_top_items_report, name='generate_top_items_report'),
    path('reports/user-growth/', views.generate_user_growth_report, name='generate_user_growth_report'),

    path('feedback/', views.view_feedback, name='view_feedback'),
    path('feedback/delete/<int:feedback_id>/', views.delete_feedback, name='delete_feedback'),

    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),

    path('fraud-detection/', views.detect_fraud_activity, name='detect_fraud_activity'),
]
