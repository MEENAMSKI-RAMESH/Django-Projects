# Administrator/models.py
from django.db import models

class Admintable(models.Model):
    username = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.username

class RestaurantOwner(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    password = models.CharField(max_length=100)
    registered_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Customer(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    address = models.TextField()
    phone = models.CharField(max_length=15)
    password = models.CharField(max_length=100)
    registered_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Restaurant(models.Model):
    owner = models.ForeignKey(RestaurantOwner, on_delete=models.CASCADE)
    name = models.CharField(max_length=150)
    address = models.TextField()
    contact = models.CharField(max_length=15)
    is_approved = models.BooleanField(default=False)
    added_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Order(models.Model):
    STATUS_CHOICES = (
        ('Placed', 'Placed'),
        ('Accepted', 'Accepted'),
        ('Preparing', 'Preparing'),
        ('Dispatched', 'Dispatched'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled'),
    )
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    order_time = models.DateTimeField(auto_now_add=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Placed')

    def __str__(self):
        return f"Order #{self.id} - {self.customer.name}"

class Feedback(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    rating = models.IntegerField()
    comment = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.customer.name} - {self.restaurant.name}"

class SalesReport(models.Model):
    date = models.DateField()
    total_sales = models.DecimalField(max_digits=12, decimal_places=2)
    top_item = models.CharField(max_length=100)
    new_users = models.IntegerField()

    def __str__(self):
        return f"Report - {self.date}"

class FraudDetection(models.Model):
    suspicious_user_email = models.EmailField()
    issue = models.CharField(max_length=200)
    details = models.TextField()
    detected_on = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)

    def __str__(self):
        return f"Fraud - {self.suspicious_user_email}"
