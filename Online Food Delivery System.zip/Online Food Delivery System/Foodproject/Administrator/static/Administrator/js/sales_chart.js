// sales_chart.js

document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: sales_labels, // defined in HTML using Django: {{ labels|safe }}
            datasets: [{
                label: 'Sales Amount',
                data: sales_data,   // defined in HTML using Django: {{ data|safe }}
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
