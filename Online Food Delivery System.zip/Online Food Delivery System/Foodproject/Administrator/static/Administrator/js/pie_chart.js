document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById('pieChart').getContext('2d');
    const pieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Customers', 'Restaurant Owners'],
            datasets: [{
                data: pieData,  
                backgroundColor: ['#007bff', '#ffc107'],
                borderColor: ['#ffffff', '#ffffff'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
        }
    });
});
