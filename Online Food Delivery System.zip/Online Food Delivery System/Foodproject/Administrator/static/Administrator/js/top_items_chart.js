document.addEventListener("DOMContentLoaded", function () {
    // Make sure these are defined in your HTML using Django:
    // <script>
    //     const item_labels = {{ item_labels|safe }};
    //     const item_data = {{ item_data|safe }};
    // </script>

    // Safety check in case variables are missing
    if (typeof item_labels !== 'undefined' && typeof item_data !== 'undefined' && item_labels.length && item_data.length) {
        const ctx = document.getElementById('topItemsChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: item_labels,
                datasets: [{
                    label: 'Top Items',
                    data: item_data,
                    backgroundColor: [
                        '#f87171', '#60a5fa', '#34d399', '#fbbf24', '#c084fc',
                        '#fd7e14', '#20c997', '#6f42c1', '#0dcaf0', '#dc3545'
                    ],
                    borderColor: '#ffffff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                let value = context.parsed;
                                return `${label}: ${value} orders`;
                            }
                        }
                    }
                }
            }
        });
    } else {
        console.warn("Chart data missing or empty.");
    }
});
