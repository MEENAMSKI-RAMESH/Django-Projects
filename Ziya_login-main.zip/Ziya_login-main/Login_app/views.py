from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from django.contrib.auth import authenticate,login,logout
from .models import CustomUser
from .serializers import CustomUserSerializer

# Create your views here.
@api_view(['POST'])
def login_view(request):
    email=request.data.get('email')
    password=request.data.get('password')

    if not email or not password:
        return Response({'message': 'Email and password are required.'},status=status.HTTP_400_BAD_REQUEST)

    user=authenticate(request,username=email,password=password)

    if user is not None:
        return Response({'message':'Login SuccesFully','user_id':user.id},status=status.HTTP_200_OK)
    else:
        return Response({'message':'Invalid Username Or Password'},status=status.HTTP_400_BAD_REQUEST)
    

@api_view(['GET'])
def get_login_view(request):
    users=CustomUser.objects.all()
    serializer=CustomUserSerializer(users,many=True)
    return Response(serializer.data)
    
