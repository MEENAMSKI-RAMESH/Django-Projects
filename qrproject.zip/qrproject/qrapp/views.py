from django.shortcuts import render

# Create your views here.
import qrcode
from io import BytesIO
from datetime import datetime
from django.http import HttpResponse

def generate_qr(request):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    qr = qrcode.make(f"Current Date & Time: {now}")

    buffer = BytesIO()
    qr.save(buffer, format="PNG")
    buffer.seek(0)

    return HttpResponse(buffer.getvalue(), content_type="image/png")
