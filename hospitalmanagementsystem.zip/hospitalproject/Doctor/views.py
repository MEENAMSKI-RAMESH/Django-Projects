from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from Administrator.models import Doctor, Appointment, Patient, Prescription, MedicalHistory
from django.utils import timezone

# ---------------- Doctor Login ----------------

def doctor_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            doctor = Doctor.objects.get(email=email, password=password)
            request.session['doctor_id'] = doctor.id
            return redirect('Doctor:doctor_dashboard')
        except Doctor.DoesNotExist:
            messages.error(request, 'Invalid email or password')
            return redirect('Doctor:doctor_login')
    return render(request, 'Doctor/login.html')


# ---------------- Doctor Dashboard ----------------

def doctor_dashboard(request):
    doctor_id = request.session.get('doctor_id')
    if not doctor_id:
        return redirect('Doctor:doctor_login')
    doctor = Doctor.objects.get(id=doctor_id)
    return render(request, 'Doctor/dashboard.html', {'doctor': doctor})


# ---------------- View Appointments ----------------

def view_appointments(request):
    doctor_id = request.session.get('doctor_id')
    if not doctor_id:
        return redirect('Doctor:doctor_login')
    appointments = Appointment.objects.filter(doctor_id=doctor_id).order_by('appointment_date')
    return render(request, 'Doctor/appointments.html', {'appointments': appointments})


# ---------------- Add Prescription ----------------

def add_prescription(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    
    if request.method == 'POST':
        text = request.POST['prescription']
        Prescription.objects.create(appointment=appointment, prescription_text=text)
        appointment.status = 'Completed'
        appointment.save()
        return redirect('Doctor:doctor_view_appointments')
    
    return render(request, 'Doctor/add_prescription.html', {'appointment': appointment})


# ---------------- View Medical History ----------------

def view_medical_history(request, patient_id):
    histories = MedicalHistory.objects.filter(patient_id=patient_id)
    patient = get_object_or_404(Patient, id=patient_id)
    return render(request, 'Doctor/view_medical_history.html', {
        'histories': histories,
        'patient': patient
    })


# ---------------- Update Consultation ----------------

def update_consultation(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    
    if request.method == 'POST':
        diagnosis = request.POST['diagnosis']
        treatment = request.POST['treatment']

        # Update appointment status if needed
        appointment.status = 'Completed'
        appointment.save()

        MedicalHistory.objects.create(
            patient=appointment.patient,
            doctor=appointment.doctor,
            diagnosis=diagnosis,
            treatment=treatment,
            date=timezone.now().date()
        )

        return redirect('Doctor:doctor_view_appointments')
    
    return render(request, 'Doctor/update_consultation.html', {
        'appointment': appointment
    })
