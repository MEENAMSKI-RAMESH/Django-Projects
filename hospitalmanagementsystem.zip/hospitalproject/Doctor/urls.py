from django.urls import path
from . import views

app_name='Doctor'

urlpatterns = [
    # Doctor Dashboard & Login
    path('login/', views.doctor_login, name='doctor_login'),
    path('dashboard/', views.doctor_dashboard, name='doctor_dashboard'),

    # Appointment Management
    path('appointments/', views.view_appointments, name='doctor_view_appointments'),

    # Prescription Management
    path('prescription/add/<int:appointment_id>/', views.add_prescription, name='add_prescription'),

    # Medical History
    path('patient/<int:patient_id>/history/', views.view_medical_history, name='doctor_view_medical_history'),

    # Consultation Notes
    path('consultation/update/<int:appointment_id>/', views.update_consultation, name='update_consultation'),
]
