from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.utils import timezone
from Administrator.models import Patient, Doctor, Department, Appointment, Prescription, MedicalHistory

# ---------------- Authentication ----------------

def patient_register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        password = request.POST['password']
        
        if Patient.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect('Patient:patient_register')

        Patient.objects.create(
            name=name,
            email=email,
            phone=phone,
            address=address,
            password=password  # In production, hash this!
        )
        messages.success(request, "Registration successful. Please login.")
        return redirect('Patient:patient_login')

    return render(request, 'Patient/register.html')


def patient_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            patient = Patient.objects.get(email=email, password=password)
            request.session['patient_id'] = patient.id
            return redirect('Patient:patient_dashboard')
        except Patient.DoesNotExist:
            messages.error(request, "Invalid email or password.")
            return redirect('Patient:patient_login')
    return render(request, 'Patient/login.html')


def patient_logout(request):
    request.session.flush()
    return redirect('Patient:patient_login')


# ---------------- Dashboard ----------------

def patient_dashboard(request):
    patient_id = request.session.get('patient_id')
    if not patient_id:
        return redirect('Patient:patient_login')
    patient = Patient.objects.get(id=patient_id)
    return render(request, 'Patient/dashboard.html', {'patient': patient})


# ---------------- Book Appointment ----------------

def book_appointment(request):
    patient_id = request.session.get('patient_id')
    if not patient_id:
        return redirect('Patient:patient_login')
    
    departments = Department.objects.all()
    doctors = Doctor.objects.all()

    if request.method == 'POST':
        doctor_id = request.POST['doctor']
        date = request.POST['appointment_date']
        
        Appointment.objects.create(
            patient_id=patient_id,
            doctor_id=doctor_id,
            appointment_date=date,
            status='Pending'
        )
        messages.success(request, "Appointment booked successfully.")
        return redirect('Patient:patient_view_appointments')

    return render(request, 'Patient/book_appointment.html', {
        'departments': departments,
        'doctors': doctors,
    })


# ---------------- View Appointments ----------------

def view_appointments(request):
    patient_id = request.session.get('patient_id')
    if not patient_id:
        return redirect('Patient:patient_login')

    appointments = Appointment.objects.filter(patient_id=patient_id).order_by('-appointment_date')
    return render(request, 'Patient/appointments.html', {'appointments': appointments})


# ---------------- View Prescriptions ----------------

def view_prescriptions(request):
    patient_id = request.session.get('patient_id')
    if not patient_id:
        return redirect('Patient:patient_login')

    prescriptions = Prescription.objects.filter(appointment__patient_id=patient_id)
    return render(request, 'Patient/prescriptions.html', {'prescriptions': prescriptions})


# ---------------- View Medical History ----------------

def view_medical_history(request):
    patient_id = request.session.get('patient_id')
    if not patient_id:
        return redirect('Patient:patient_login')

    histories = MedicalHistory.objects.filter(patient_id=patient_id)
    return render(request, 'Patient/medical_history.html', {'histories': histories})
