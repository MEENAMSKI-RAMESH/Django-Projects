from django.urls import path
from . import views

app_name='Patient'

urlpatterns = [
    # Authentication
    path('register/', views.patient_register, name='patient_register'),
    path('login/', views.patient_login, name='patient_login'),
    path('logout/', views.patient_logout, name='patient_logout'),

    # Dashboard
    path('dashboard/', views.patient_dashboard, name='patient_dashboard'),

    # Appointments
    path('book-appointment/', views.book_appointment, name='book_appointment'),
    path('appointments/', views.view_appointments, name='patient_view_appointments'),

    # Prescriptions
    path('prescriptions/', views.view_prescriptions, name='patient_view_prescriptions'),

    # Medical History
    path('medical-history/', views.view_medical_history, name='patient_view_medical_history'),
]
