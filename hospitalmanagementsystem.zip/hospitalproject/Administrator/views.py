from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import AdminTable, Doctor, Patient, Department, Appointment, Prescription, MedicalHistory
from django.utils import timezone


# -------------------- Admin Login & Dashboard --------------------

def index(request):
    return render(request, 'Administrator/index.html')


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            admin = AdminTable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin.id
            return redirect('Administrator:admin_dashboard')
        except AdminTable.DoesNotExist:
            messages.error(request, 'Invalid credentials')
            return redirect('Administrator:login')
    return render(request, 'Administrator/login.html')


def admin_dashboard(request):
    return render(request, 'Administrator/dashboard.html')


# -------------------- Doctor Management --------------------

def manage_doctors(request):
    doctors = Doctor.objects.all()
    return render(request, 'Administrator/manage_doctors.html', {'doctors': doctors})



def add_doctor(request):
    departments = Department.objects.all()
    if request.method == 'POST':
        email = request.POST['email']
        if Doctor.objects.filter(email=email).exists():
            messages.error(request, "A doctor with this email already exists.")
            return render(request, 'Administrator/add_doctor.html', {'departments': departments})

        # Store password as plain text (not recommended)
        raw_password = request.POST['password']

        Doctor.objects.create(
            name=request.POST['name'],
            email=email,
            password=raw_password,
            phone=request.POST['phone'],
            specialization=request.POST['specialization'],
            department_id=request.POST.get('department')
        )
        messages.success(request, "Doctor added successfully.")
        return redirect('Administrator:manage_doctors')

    return render(request, 'Administrator/add_doctor.html', {'departments': departments})





def edit_doctor(request, doctor_id):
    doctor = get_object_or_404(Doctor, id=doctor_id)
    departments = Department.objects.all()

    if request.method == 'POST':
        new_email = request.POST['email']
        if Doctor.objects.filter(email=new_email).exclude(id=doctor.id).exists():
            messages.error(request, "Another doctor already uses this email.")
            return render(request, 'Administrator/edit_doctor.html', {'doctor': doctor, 'departments': departments})
        
        doctor.name = request.POST['name']
        doctor.email = new_email
        doctor.phone = request.POST['phone']
        doctor.specialization = request.POST['specialization']
        doctor.department_id = request.POST.get('department')
        doctor.save()
        messages.success(request, "Doctor updated successfully.")
        return redirect('Administrator:manage_doctors')

    return render(request, 'Administrator/edit_doctor.html', {'doctor': doctor, 'departments': departments})


def delete_doctor(request, doctor_id):
    get_object_or_404(Doctor, id=doctor_id).delete()
    return redirect('Administrator:manage_doctors')


# -------------------- Patient Management --------------------

def manage_patients(request):
    patients = Patient.objects.all()
    return render(request, 'Administrator/manage_patients.html', {'patients': patients})


def add_patient(request):
    if request.method == 'POST':
        Patient.objects.create(
            name=request.POST['name'],
            email=request.POST['email'],
            phone=request.POST['phone'],
            address=request.POST['address']
        )
        return redirect('manage_patients')
    return render(request, 'Administrator/add_patient.html')


def edit_patient(request, patient_id):
    patient = get_object_or_404(Patient, id=patient_id)
    if request.method == 'POST':
        patient.name = request.POST['name']
        patient.email = request.POST['email']
        patient.phone = request.POST['phone']
        patient.address = request.POST['address']
        patient.save()
        return redirect('manage_patients')
    return render(request, 'Administrator/edit_patient.html', {'patient': patient})


def delete_patient(request, patient_id):
    get_object_or_404(Patient, id=patient_id).delete()
    return redirect('Administrator:manage_patients')


# -------------------- Department Management --------------------

def manage_departments(request):
    departments = Department.objects.all()
    return render(request, 'Administrator/manage_departments.html', {'departments': departments})


def add_department(request):
    if request.method == 'POST':
        Department.objects.create(
            name=request.POST['name'],
            description=request.POST['description']
        )
        return redirect('Administrator:manage_departments')
    return render(request, 'Administrator/add_department.html')


def edit_department(request, department_id):
    department = get_object_or_404(Department, id=department_id)
    if request.method == 'POST':
        department.name = request.POST['name']
        department.description = request.POST['description']
        department.save()
        return redirect('Administrator:manage_departments')
    return render(request, 'Administrator/edit_department.html', {'department': department})


def delete_department(request, department_id):
    get_object_or_404(Department, id=department_id).delete()
    return redirect('Administrator:manage_departments')


# -------------------- Assign Doctor to Department --------------------

def assign_doctor_department(request):
    doctors = Doctor.objects.all()
    departments = Department.objects.all()
    if request.method == 'POST':
        doctor = Doctor.objects.get(id=request.POST['doctor'])
        doctor.department_id = request.POST['department']
        doctor.save()
        return redirect('Administrator:manage_doctors')
    return render(request, 'Administrator/assign_doctor.html', {'doctors': doctors, 'departments': departments})


# -------------------- Appointment Management --------------------

def view_appointments(request):
    appointments = Appointment.objects.all()
    return render(request, 'Administrator/view_appointments.html', {'appointments': appointments})


def cancel_appointment(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    appointment.status = 'Cancelled'
    appointment.save()
    return redirect('view_appointments')


def reschedule_appointment(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    if request.method == 'POST':
        appointment.appointment_date = request.POST['new_date']
        appointment.status = 'Rescheduled'
        appointment.save()
        return redirect('view_appointments')
    return render(request, 'Administrator/reschedule_appointment.html', {'appointment': appointment})


# -------------------- View Prescriptions & Medical History --------------------

def view_prescriptions(request):
    prescriptions = Prescription.objects.select_related('appointment').all()
    return render(request, 'Administrator/view_prescriptions.html', {'prescriptions': prescriptions})


def view_medical_history(request):
    histories = MedicalHistory.objects.all()
    return render(request, 'Administrator/view_medical_history.html', {'histories': histories})
