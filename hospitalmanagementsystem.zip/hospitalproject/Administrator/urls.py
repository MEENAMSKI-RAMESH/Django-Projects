from django.urls import path
from . import views

app_name='Administrator'

urlpatterns = [
    path('index/', views.index, name='index'),
    path('login/', views.login, name='login'),
    # Admin Dashboard
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),

    # Doctor Management
    path('doctors/', views.manage_doctors, name='manage_doctors'),
    path('doctor/add/', views.add_doctor, name='add_doctor'),
    path('doctor/edit/<int:doctor_id>/', views.edit_doctor, name='edit_doctor'),
    path('doctor/delete/<int:doctor_id>/', views.delete_doctor, name='delete_doctor'),

    # Patient Management
    path('patients/', views.manage_patients, name='manage_patients'),
    path('patient/add/', views.add_patient, name='add_patient'),
    path('patient/edit/<int:patient_id>/', views.edit_patient, name='edit_patient'),
    path('patient/delete/<int:patient_id>/', views.delete_patient, name='delete_patient'),

    # Department Management
    path('departments/', views.manage_departments, name='manage_departments'),
    path('department/add/', views.add_department, name='add_department'),
    path('department/edit/<int:department_id>/', views.edit_department, name='edit_department'),
    path('department/delete/<int:department_id>/', views.delete_department, name='delete_department'),

    # Assign Doctor to Department
    path('assign-doctor/', views.assign_doctor_department, name='assign_doctor_department'),

    # Appointment Management
    path('appointments/', views.view_appointments, name='view_appointments'),
    path('appointment/cancel/<int:appointment_id>/', views.cancel_appointment, name='cancel_appointment'),
    path('appointment/reschedule/<int:appointment_id>/', views.reschedule_appointment, name='reschedule_appointment'),

    # View Prescriptions & Medical History
    path('medical-history/', views.view_medical_history, name='view_medical_history'),
    path('prescriptions/', views.view_prescriptions, name='view_prescriptions'),
]
