from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('favorite_city/<str:city>/', views.favorite_city, name='favorite_city'),
    path('clear_recent', views.clear_recent, name='clear_recent'),
    path('clear_fav',views.clear_fav,name='clear_fav'),
]