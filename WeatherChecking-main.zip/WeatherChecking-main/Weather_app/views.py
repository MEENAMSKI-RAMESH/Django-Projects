from django.shortcuts import render,redirect,get_object_or_404 
from django.contrib import messages 
from django.contrib.auth import authenticate
from . models import *
import requests
from django.conf import settings


API_KEY=settings.MYAPI_KEY

# Create your views here.
def index(request):
    weather_data={}
    city=request.GET.get('city')
    if city:
        url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric'
        response = requests.get(url).json()

        if response.get('cod') == 200:
            weather_data = {
                'city': city,
                'temperature': response['main']['temp'],
                'description': response['weather'][0]['description'].title(),
                'humidity': response['main']['humidity'],
                'wind': response['wind']['speed'],
                'icon': response['weather'][0]['icon'],
            }
            RecentCity.objects.create(city=city)

    recent = RecentCity.objects.order_by('-searched_at')[:5]
    favorites = FavoriteCity.objects.all()

    return render(request, 'index.html', {
        'weather_data': weather_data,
        'recent_searches': recent,
        'favorites': favorites
    })

def clear_recent(request):
    RecentCity.objects.all().delete()
    return redirect('index')

def favorite_city(request,city):
    if not FavoriteCity.objects.filter(city=city).exists():
        FavoriteCity.objects.create(city=city)
    return redirect('index')

def clear_fav(request):
    FavoriteCity.objects.all().delete()
    return redirect('index')

