from django.db import models


# Create your models here.
class RecentCity(models.Model):
    city=models.CharField(max_length=200)
    searched_at=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.city
    
class FavoriteCity(models.Model):
    city=models.CharField(max_length=200)

    def __str__(self):
        return self.city