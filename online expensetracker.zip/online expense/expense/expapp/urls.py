
from django.urls import  path

from expapp import views

urlpatterns = [
    path('',views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('addexpense/', views.addexpense_views, name='addexpense'),
    path('viewexpense/', views.viewexpense_views, name='viewexpense'),
    path('editexpense/', views.editexpense_views, name='editexpense'),
    path('deleteexpense/', views.deleteexpense_views, name='deleteexpense'),
    path('filterexpense/', views.filterexpense_views, name='filterexpense'),
    path('monthlyexpense/', views.monthlyexpense_views, name='monthlyexpense'),
    path('chart/', views.chart_views, name='chart'),        

]