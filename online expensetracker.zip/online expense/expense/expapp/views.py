from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Expense, Category
from django.db.models import Sum
from django.utils.dateformat import DateFormat
from collections import defaultdict
from django.utils.dateformat import DateFormat


def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            messages.success(request, "Account created successfully!")
            return redirect('login')

    return render(request, 'expapp/register.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)

        if user:
            login(request, user)
            return redirect('viewexpense')
        else:
            messages.error(request, "Invalid credentials.")
    return render(request, 'expapp/login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def addexpense_views(request):
    categories = Category.objects.all()
    if request.method == 'POST':
        amount = request.POST['amount']
        category_id = request.POST['category']
        date = request.POST['date']
        description = request.POST['description']

        category = get_object_or_404(Category, id=category_id)
        Expense.objects.create(
            user=request.user,
            amount=amount,
            category=category,
            date=date,
            description=description
        )
        messages.success(request, "Expense added!")
        return redirect('viewexpense')

    return render(request, 'expapp/addexpense.html', {'categories': categories})


@login_required
def viewexpense_views(request):
    expenses = Expense.objects.filter(user=request.user).order_by('-date')
    return render(request, 'expapp/viewexpense.html', {'expenses': expenses})


@login_required
def editexpense_views(request):
    expense_id = request.GET.get('id')
    expense = get_object_or_404(Expense, id=expense_id, user=request.user)
    categories = Category.objects.all()

    if request.method == 'POST':
        expense.amount = request.POST['amount']
        expense.category_id = request.POST['category']
        expense.date = request.POST['date']
        expense.description = request.POST['description']
        expense.save()
        messages.success(request, "Expense updated!")
        return redirect('viewexpense')

    return render(request, 'expapp/editexpense.html', {'expense': expense, 'categories': categories})


@login_required
def deleteexpense_views(request):
    expense_id = request.GET.get('id')
    expense = get_object_or_404(Expense, id=expense_id, user=request.user)
    expense.delete()
    messages.success(request, "Expense deleted!")
    return redirect('viewexpense')


@login_required
def filterexpense_views(request):
    categories = Category.objects.all()
    expenses = Expense.objects.filter(user=request.user)

    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        category_id = request.POST.get('category')

        if start_date:
            expenses = expenses.filter(date__gte=start_date)
        if end_date:
            expenses = expenses.filter(date__lte=end_date)
        if category_id:
            expenses = expenses.filter(category_id=category_id)

    return render(request, 'expapp/filterexpense.html', {
        'categories': categories,
        'expenses': expenses
    })


@login_required
def monthlyexpense_views(request):
    current_user = request.user
    expenses = Expense.objects.filter(user=current_user)
    monthly_totals = {}

    for expense in expenses:
        month = expense.date.strftime('%B %Y')
        monthly_totals[month] = monthly_totals.get(month, 0) + float(expense.amount)

    return render(request, 'expapp/monthlyexpense.html', {'monthly_totals': monthly_totals})


@login_required
def chart_views(request):
    expenses = Expense.objects.filter(user=request.user)

    monthly_data = defaultdict(lambda: {'labels': [], 'data': []})

    grouped = expenses.values('date', 'category__name').annotate(total=Sum('amount'))

    for item in grouped:
        date = item['date']
        month_str = DateFormat(date).format('M Y')  
        category = item['category__name']
        amount = float(item['total'])

        if amount >= 1000:
            monthly_data[month_str]['labels'].append(category)
            monthly_data[month_str]['data'].append(amount)

    return render(request, 'expapp/chart.html', {'monthly_data': dict(monthly_data)})