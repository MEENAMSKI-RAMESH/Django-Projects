from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.user_register, name='user_register'),
    path('login/', views.user_login, name='user_login'),
    path('logout/', views.user_logout, name='user_logout'),
    path('user_home', views.user_home, name='user_home'),  # Homepage for users

    # 1. Browse Pets
    path('pets/', views.browse_pets, name='browse_pets'),

    # 2. Submit Adoption Request
    path('adopt/<int:pet_id>/', views.submit_request, name='submit_request'),

    # 3. View Request Status
    path('my-requests/', views.my_requests, name='my_requests'),
]
