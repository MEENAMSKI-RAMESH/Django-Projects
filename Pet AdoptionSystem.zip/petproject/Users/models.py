from django.db import models

class UserTable(models.Model):
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)  # In production, use hashed passwords

    def __str__(self):
        return self.username
