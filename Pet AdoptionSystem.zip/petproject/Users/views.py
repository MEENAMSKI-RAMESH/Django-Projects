from django.shortcuts import render, redirect, get_object_or_404
from Administrator.models import Pet, AdoptionRequest
from .models import UserTable
from django.contrib import messages

# ✅ User Registration
def user_register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        if UserTable.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered.')
            return redirect('Users:user_register')

        UserTable.objects.create(username=username, email=email, password=password)
        messages.success(request, 'Registration successful. Please login.')
        return redirect('Users:user_login')

    return render(request, 'Users/register.html')


# ✅ User Login
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        try:
            user = UserTable.objects.get(username=username, password=password)
            request.session['user_id'] = user.id
            request.session['user_name'] = user.username
            return redirect('Users:user_home')
        except UserTable.DoesNotExist:
            messages.error(request, 'Invalid username or password.')
            return redirect('Users:user_login')

    return render(request, 'Users/login.html')


# ✅ User Logout
def user_logout(request):
    request.session.flush()
    return redirect('Users:user_login')


# ✅ Dashboard View
def user_dashboard(request):
    if 'user_id' not in request.session:
        return redirect('Users:user_login')
    return render(request, 'Users/dashboard.html', {
        'user_name': request.session.get('user_name')
    })


# ✅ Home Page (optional)
def user_home(request):
    return render(request, 'Users/user_home.html')


# ✅ Browse Pets
def browse_pets(request):
    pets = Pet.objects.filter(status='Available')

    breed = request.GET.get('breed')
    age = request.GET.get('age')

    if breed:
        pets = pets.filter(breed__icontains=breed)
    if age:
        pets = pets.filter(age=age)

    return render(request, 'Users/browse_pets.html', {'pets': pets})


# ✅ Submit Adoption Request (No duplication allowed)
def submit_request(request, pet_id):
    user_id = request.session.get('user_id')
    if not user_id:
        messages.error(request, 'Please log in to submit a request.')
        return redirect('Users:user_login')

    try:
        user = UserTable.objects.get(id=user_id)
    except UserTable.DoesNotExist:
        messages.error(request, 'User not found.')
        return redirect('Users:user_login')

    pet = get_object_or_404(Pet, id=pet_id)

    existing_request = AdoptionRequest.objects.filter(user=user, pet=pet).first()
    if existing_request:
        messages.warning(request, 'You have already requested to adopt this pet.')
    else:
        AdoptionRequest.objects.create(user=user, pet=pet)
        messages.success(request, 'Your adoption request has been submitted.')

    return redirect('Users:browse_pets')


# ✅ View My Adoption Requests
def my_requests(request):
    user_id = request.session.get('user_id')
    if not user_id:
        messages.error(request, 'Please log in to view your requests.')
        return redirect('Users:user_login')

    try:
        user = UserTable.objects.get(id=user_id)
    except UserTable.DoesNotExist:
        messages.error(request, 'User not found.')
        return redirect('Users:user_login')

    requests = AdoptionRequest.objects.select_related('pet').filter(user=user)
    return render(request, 'Users/my_requests.html', {'requests': requests})
