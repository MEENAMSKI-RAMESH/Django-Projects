from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.admin_login, name='admin_login'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('pets/', views.view_pets, name='view_pets'),                         # List all pets
    path('pets/add/', views.add_pet, name='add_pet'),                         # Add a new pet
    path('pets/edit/<int:pet_id>/', views.edit_pet, name='edit_pet'),         # Edit a pet
    path('pets/delete/<int:pet_id>/', views.delete_pet, name='delete_pet'),   # Delete a pet

    path('requests/', views.view_adoption_requests, name='view_requests'),         # View all requests
    path('requests/filter/<str:status>/', views.filter_requests, name='filter_requests'),  # Filter by status

    path('requests/process/<int:request_id>/<str:action>/', views.process_request, name='process_request'),  # Approve/Reject

    path('users/', views.view_users, name='view_users'),  # View users and their requests
]
