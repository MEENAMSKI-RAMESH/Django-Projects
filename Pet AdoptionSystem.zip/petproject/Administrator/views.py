from django.shortcuts import render, redirect, get_object_or_404
from .models import AdminTable, Pet, AdoptionRequest
from Users.models import UserTable  # Assuming this model exists
from django.contrib import messages
from django.db.models import Q

def index(request):
    return render(request, 'Administrator/index.html')

def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            admin = AdminTable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin.id
            return redirect('Administrator:admin_dashboard')
        except AdminTable.DoesNotExist:
            messages.error(request, 'Invalid login credentials.')
            return redirect('Administrator:admin_login')
    return render(request, 'Administrator/admin_login.html')

def admin_dashboard(request):
    return render(request, 'Administrator/admindashboard.html')

def view_pets(request):
    pets = Pet.objects.all()
    return render(request, 'Administrator/view_pets.html', {'pets': pets})

def add_pet(request):
    if request.method == 'POST':
        name = request.POST['name']
        breed = request.POST['breed']
        age = request.POST['age']
        image = request.FILES.get('image')
        Pet.objects.create(name=name, breed=breed, age=age, image=image)
        messages.success(request, 'Pet added successfully.')
        return redirect('Administrator:view_pets')
    return render(request, 'Administrator/add_pet.html')

def edit_pet(request, pet_id):
    pet = get_object_or_404(Pet, id=pet_id)

    if request.method == 'POST':
        pet.name = request.POST['name']
        pet.breed = request.POST['breed']
        pet.age = request.POST['age']
        if 'image' in request.FILES:
            pet.image = request.FILES['image']
        pet.status = request.POST['status']
        pet.save()
        messages.success(request, 'Pet updated successfully.')
        return redirect('Administrator:view_pets')

    return render(request, 'Administrator/edit_pet.html', {'pet': pet})


def delete_pet(request, pet_id):
    pet = get_object_or_404(Pet, id=pet_id)
    pet.delete()
    messages.success(request, 'Pet deleted successfully.')
    return redirect('Administrator/view_pets')

def view_adoption_requests(request):
    requests = AdoptionRequest.objects.select_related('user', 'pet').all()
    return render(request, 'Administrator/view_requests.html', {'requests': requests})

def filter_requests(request, status):
    requests = AdoptionRequest.objects.select_related('user', 'pet').filter(status=status)
    return render(request, 'Administrator/view_requests.html', {'requests': requests, 'filter': status})

def process_request(request, request_id, action):
    adoption_request = get_object_or_404(AdoptionRequest, id=request_id)
    if action == 'Approve':
        adoption_request.status = 'Approved'
        adoption_request.pet.status = 'Adopted'
        adoption_request.pet.save()
    elif action == 'Reject':
        adoption_request.status = 'Rejected'
    adoption_request.save()
    messages.success(request, f"Request {action}d successfully.")
    return redirect('Administrator:view_requests')

def view_users(request):
    users = UserTable.objects.all()
    user_data = []
    for user in users:
        requests = AdoptionRequest.objects.filter(user=user).select_related('pet')
        user_data.append({'user': user, 'requests': requests})
    return render(request, 'Administrator/view_users.html', {'user_data': user_data})
