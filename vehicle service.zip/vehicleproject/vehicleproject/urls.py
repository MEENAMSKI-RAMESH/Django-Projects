"""
URL configuration for vehicleproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
import Administrator.views as administrator_views  # import the index view

urlpatterns = [
    path('Administrator/', include('Administrator.urls')),  # admin module
    path('user/', include('User.urls')),            # user module
    path('vendor/', include('Vendor.urls')),        # vendor module
    path('', administrator_views.index, name='index'), 
    path('maintenance/', include('maintenance_ml.urls', namespace='maintenance_ml')),
    ]