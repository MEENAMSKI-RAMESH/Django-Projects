from django.urls import path
from . import views

app_name='Administrator'

urlpatterns = [
    path('login/', views.login, name='login'),
    path('admin_dashboard', views.admin_dashboard, name='admin_dashboard'),
    path('logout/', views.logout_admin, name='admin_logout'),

    # User Management
    path('users/', views.manage_users, name='manage_users'),

    # Garage Management
    path('garages/', views.manage_garages, name='manage_garages'),
    path('approve/<int:garage_id>/', views.approve_garage, name='approve_garage'),
    path('reject/<int:garage_id>/', views.reject_garage, name='reject_garage'),

    # Analytics
    path('analytics/', views.view_analytics, name='view_analytics'),

    # Feedback/Complaints
    path('feedbacks/', views.view_feedbacks, name='view_feedbacks'),
    path('feedbacks/reply/<int:feedback_id>/', views.reply_feedback, name='reply_feedback'),

]
