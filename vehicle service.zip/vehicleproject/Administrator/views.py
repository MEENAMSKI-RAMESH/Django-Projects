# Administrator/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from User.models import CustomUser
from Vendor.models import Garage, ServiceBooking
from .models import Feedback, Admintable
from django.db.models import Count, Sum
from django.views.decorators.csrf import csrf_exempt


def index(request):
    return render(request, 'Administrator/index.html')

# Admin login view using Admintable
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            admin = Admintable.objects.get(username=username, password=password)
            request.session['admin_logged_in'] = True
            request.session['admin_username'] = admin.username
            return redirect('Administrator:admin_dashboard')
        except Admintable.DoesNotExist:
            messages.error(request, "Invalid administrator credentials.")

    return render(request, 'Administrator/login.html')


# Decorator to check admin login manually
def admin_login_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.session.get('admin_logged_in'):
            return redirect('Administrator:admin_login')
        return view_func(request, *args, **kwargs)
    return wrapper


@admin_login_required
def admin_dashboard(request):
    user_count = CustomUser.objects.filter(role='user').count()
    vendor_count = CustomUser.objects.filter(role='vendor').count()
    garage_pending = Garage.objects.filter(is_approved=False).count()
    total_bookings = ServiceBooking.objects.count()

    context = {
        'user_count': user_count,
        'vendor_count': vendor_count,
        'garage_pending': garage_pending,
        'total_bookings': total_bookings,
    }
    return render(request, 'Administrator/dashboard.html', context)


@admin_login_required
def manage_users(request):
    users = CustomUser.objects.filter(role='user')
    return render(request, 'Administrator/manage_users.html', {'users': users})


@admin_login_required
def manage_garages(request):
    garages = Garage.objects.all()
    return render(request, 'Administrator/manage_garages.html', {'garages': garages})


@admin_login_required
def approve_garage(request, garage_id):
    garage = get_object_or_404(Garage, id=garage_id)
    garage.is_approved = True
    garage.save()
    messages.success(request, "Garage approved successfully.")
    return redirect('Administrator:manage_garages')


@admin_login_required
def reject_garage(request, garage_id):
    garage = get_object_or_404(Garage, id=garage_id)
    garage.is_approved = False
    garage.save()
    messages.warning(request, "Garage rejected.")
    return redirect('Administrator:manage_garages')


@admin_login_required
def view_analytics(request):
    top_services = ServiceBooking.objects.values('service_type').annotate(count=Count('id')).order_by('-count')[:5]
    revenue_by_garage = ServiceBooking.objects.values('garage__name').annotate(total=Sum('price')).order_by('-total')[:5]

    context = {
        'top_services': top_services,
        'revenue_by_garage': revenue_by_garage,
    }
    return render(request, 'Administrator/analytics.html', context)


@admin_login_required
def view_feedbacks(request):
    feedbacks = Feedback.objects.all().order_by('-submitted_at')
    return render(request, 'Administrator/feedbacks.html', {'feedbacks': feedbacks})


@csrf_exempt
@admin_login_required
def reply_feedback(request, feedback_id):
    if request.method == 'POST':
        feedback = get_object_or_404(Feedback, id=feedback_id)
        reply = request.POST.get('reply')
        feedback.reply = reply
        feedback.save()
        messages.success(request, "Reply submitted successfully.")
    return redirect('Administrator:view_feedbacks')



# Optional: Admin logout
def logout_admin(request):
    request.session.flush()
    return redirect('Administrator:index')
