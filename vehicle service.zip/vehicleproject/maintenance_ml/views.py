# maintenance_ml/views.py
from django.shortcuts import render
import joblib
import numpy as np

model = joblib.load('maintenance_model.pkl')  # Load once

def predict_maintenance(request):
    prediction = None
    if request.method == 'POST':
        vehicle_age = int(request.POST['vehicle_age'])
        service_count = int(request.POST['service_count'])
        breakdown_count = int(request.POST['breakdown_count'])

        data = np.array([[vehicle_age, service_count, breakdown_count]])
        result = model.predict(data)[0]
        prediction = "Likely Breakdown Soon ⚠️" if result == 1 else "No Immediate Issue ✅"

    return render(request, 'maintenance_ml/predict.html', {'prediction': prediction})
