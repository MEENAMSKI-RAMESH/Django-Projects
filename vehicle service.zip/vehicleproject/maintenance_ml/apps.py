from django.apps import AppConfig


class MaintenanceMlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'maintenance_ml'
