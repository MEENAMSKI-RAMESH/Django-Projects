from django.urls import path
from . import views

app_name='maintenance_ml'

urlpatterns = [
    path('predict/', views.predict_maintenance, name='predict_maintenance'),
]
