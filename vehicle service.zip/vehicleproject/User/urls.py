from django.urls import path
from . import views

app_name='User'

urlpatterns = [
    # Authentication
    path('register/', views.register_user, name='user_register'),
    path('login/', views.login_user, name='user_login'),
    path('logout/', views.logout_user, name='user_logout'),
    path('dashboard/', views.user_dashboard, name='user_dashboard'),

    # Vehicle Management
    path('vehicles/', views.my_vehicles, name='my_vehicles'),
    path('vehicles/add/', views.add_vehicle, name='add_vehicle'),

    # Service Booking
    path('book/', views.book_service, name='book_service'),
    path('garages/<int:service_type_id>/', views.available_garages, name='available_garages'),
    path('confirm_booking/<int:garage_id>/<int:service_type_id>/', views.service_confirmation, name='service_confirmation'),

    # Booking History & Invoice
    path('bookings/', views.my_bookings, name='my_bookings'),
    path('invoice/<int:booking_id>/', views.download_invoice, name='download_invoice'),
    path('feedback/submit/', views.submit_feedback, name='submit_feedback'),
    path('feedback/view/', views.view_my_feedbacks, name='view_feedbacks'),
]
