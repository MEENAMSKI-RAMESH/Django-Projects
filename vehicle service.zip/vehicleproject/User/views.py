from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from Administrator.models import Feedback
from .models import CustomUser, Vehicle
from Vendor.models import Garage, ServiceType, ServiceBooking
from datetime import datetime


# 🔐 Register User
def register_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
        else:
            user = CustomUser.objects.create_user(username=username, password=password, email=email, role='user')
            messages.success(request, 'Registration successful! Please login.')
            return redirect('User:user_login')
    return render(request, 'User/register.html')


# 🔐 Login User
def login_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user and user.role == 'user':
            auth_login(request, user)
            return redirect('User:user_dashboard')
        else:
            messages.error(request, 'Invalid credentials or not a user.')
    return render(request, 'User/login.html')


# 🔐 Logout
def logout_user(request):
    logout(request)
    return redirect('User:user_login')


# 🏠 User Dashboard
@login_required
def user_dashboard(request):
    return render(request, 'User/dashboard.html')


# 🚗 My Vehicles
@login_required
def my_vehicles(request):
    vehicles = Vehicle.objects.filter(owner=request.user)
    return render(request, 'User/my_vehicles.html', {'vehicles': vehicles})


# 🚗 Add Vehicle
@login_required
def add_vehicle(request):
    if request.method == 'POST':
        vehicle_type = request.POST['vehicle_type']
        model = request.POST['model']
        year = request.POST['year']

        Vehicle.objects.create(
            owner=request.user,
            vehicle_type=vehicle_type,
            model=model,
            year=year
        )
        messages.success(request, 'Vehicle added successfully.')
        return redirect('User:my_vehicles')

    return render(request, 'User/add_vehicle.html')


# 📅 Book Service - Step 1: Select service
@login_required
def book_service(request):
    services = ServiceType.objects.all()
    return render(request, 'User/book_service.html', {'services': services})


# 📍 Step 2: Select garage based on service
@login_required
def available_garages(request, service_type_id):
    garages = Garage.objects.filter(is_approved=True)
    service = get_object_or_404(ServiceType, id=service_type_id)
    return render(request, 'User/available_garages.html', {'garages': garages, 'service': service})


# ✅ Step 3: Confirm Booking
@login_required
def service_confirmation(request, garage_id, service_type_id):
    garage = get_object_or_404(Garage, id=garage_id)
    service = get_object_or_404(ServiceType, id=service_type_id)
    vehicles = Vehicle.objects.filter(owner=request.user)

    if request.method == 'POST':
        vehicle_id = request.POST['vehicle_id']
        date = request.POST['date']
        time = request.POST['time']

        vehicle = get_object_or_404(Vehicle, id=vehicle_id)

        ServiceBooking.objects.create(
            user=request.user,
            vehicle=vehicle,
            garage=garage,
            service_type=service,
            date=date,
            time=time,
            price=service.price
        )
        messages.success(request, "Service booked successfully!")
        return redirect('User:my_bookings')

    return render(request, 'User/service_confirmation.html', {
        'garage': garage,
        'service': service,
        'vehicles': vehicles,
    })


# 📋 My Bookings
@login_required
def my_bookings(request):
    bookings = ServiceBooking.objects.filter(user=request.user).order_by('-date')
    return render(request, 'User/my_bookings.html', {'bookings': bookings})


# 🧾 Download Invoice (basic HTML)
@login_required
def download_invoice(request, booking_id):
    booking = get_object_or_404(ServiceBooking, id=booking_id, user=request.user)
    return render(request, 'User/invoice.html', {'booking': booking})


@login_required
def submit_feedback(request):
    if request.user.role != 'user':
        return redirect('User:user_login')  # Redirect non-users

    if request.method == 'POST':
        subject = request.POST.get('subject')  # ✅ fixed line
        message = request.POST.get('message')
        Feedback.objects.create(user=request.user, subject=subject, message=message)
        messages.success(request, 'Feedback submitted successfully.')
        return redirect('User:user_dashboard')

    return render(request, 'User/submit_feedback.html')



# ✅ View My Feedbacks (User)
@login_required
def view_my_feedbacks(request):
    if request.user.role != 'user':
        return redirect('User:user_login')

    feedbacks = Feedback.objects.filter(user=request.user).order_by('-submitted_at')  # Again, use 'user' if applicable
    return render(request, 'User/view_feedbacks.html', {'feedbacks': feedbacks})
