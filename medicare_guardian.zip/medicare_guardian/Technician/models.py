from django.db import models

# Create your models here.
from django.db import models
from Administrator.models import Department


# class Technician(models.Model):

#     STATUS_CHOICES = [
#         ('Active', 'Active'),
#         ('Inactive', 'Inactive'),
#     ]

#     GENDER_CHOICES = [
#         ('Male', 'Male'),
#         ('Female', 'Female'),
#         ('Other', 'Other'),
#     ]

#     technician_id = models.CharField(max_length=20, unique=True)

#     first_name = models.CharField(max_length=50)

#     last_name = models.CharField(max_length=50)

#     gender = models.CharField(
#         max_length=10,
#         choices=GENDER_CHOICES
#     )

#     email = models.EmailField(unique=True)

#     phone = models.CharField(max_length=15)

#     password = models.CharField(max_length=255)

#     profile_image = models.ImageField(
#         upload_to='technicians/',
#         blank=True,
#         null=True
#     )

#     designation = models.CharField(max_length=100)

#     qualification = models.CharField(max_length=100)

#     experience = models.PositiveIntegerField(
#         help_text="Experience in years"
#     )

#     department = models.ForeignKey(
#         Department,
#         on_delete=models.SET_NULL,
#         null=True,
#         blank=True,
#         related_name='technicians'
#     )

#     address = models.TextField(blank=True)

#     joining_date = models.DateField()

#     status = models.CharField(
#         max_length=20,
#         choices=STATUS_CHOICES,
#         default='Active'
#     )

#     created_at = models.DateTimeField(auto_now_add=True)

#     updated_at = models.DateTimeField(auto_now=True)

#     def __str__(self):
#         return f"{self.first_name} {self.last_name}"




class Technician(models.Model):

    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
    ]

    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]

    technician_id = models.CharField(max_length=20, unique=True)

    first_name = models.CharField(max_length=50)

    last_name = models.CharField(max_length=50)

    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)

    email = models.EmailField(unique=True)

    phone = models.CharField(max_length=15)

    password = models.CharField(max_length=255)

    profile_image = models.ImageField(
        upload_to="technicians/",
        blank=True,
        null=True
    )

    designation = models.CharField(max_length=100)

    qualification = models.CharField(max_length=100)

    experience = models.PositiveIntegerField()

    department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        related_name="technicians"
    )

    address = models.TextField(blank=True)

    joining_date = models.DateField()

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="Active"
    )

    # Optional improvements
    is_online = models.BooleanField(default=False)

    last_login = models.DateTimeField(
        blank=True,
        null=True
    )

    created_at = models.DateTimeField(auto_now_add=True)

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"