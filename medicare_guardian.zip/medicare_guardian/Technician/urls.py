from django.urls import path
from . import views

urlpatterns = [

    # ==========================================
    # Authentication
    # ==========================================

    path(
        "",
        views.technician_login,
        name="technician_login"
    ),

    path(
        "logout/",
        views.technician_logout,
        name="technician_logout"
    ),

    # ==========================================
    # Dashboard
    # ==========================================

    path(
        "dashboard/",
        views.technician_dashboard,
        name="technician_dashboard"
    ),

    path(
        "statistics/",
        views.technician_statistics,
        name="technician_statistics"
    ),

    # ==========================================
    # Profile
    # ==========================================

    path(
        "profile/",
        views.view_profile,
        name="view_profile"
    ),

    path(
        "edit-profile/",
        views.edit_profile,
        name="edit_profile"
    ),

    # ==========================================
    # Department
    # ==========================================

    path(
        "assigned-department/",
        views.assigned_department,
        name="assigned_department"
    ),



    path(
    "assigned-equipment/",
    views.assigned_equipment,
    name="assigned_equipment",
    ),

    path(
        "maintenance/",
        views.pending_maintenance,
        name="pending_maintenance",
    ),

    path(
        "maintenance/update/<int:maintenance_id>/",
        views.update_maintenance,
        name="update_maintenance",
    ),

    path(
        "equipment-status/",
        views.equipment_status,
        name="equipment_status",
    ),

    path(
        "equipment-health/",
        views.equipment_health,
        name="equipment_health",
    ),

    path(
        "dashboard-notifications/",
        views.dashboard_notifications,
        name="dashboard_notifications",
    ),

    path(
        "email-notifications/",
        views.email_notifications,
        name="email_notifications",
    ),

    path(
    "email-notifications/update/<int:notification_id>/",
    views.update_notification,
    name="update_notification",
    ),
    path(
    "api/live-equipment-status/",
    views.live_equipment_status_data,
    name="live_equipment_status_data",
    ),

    path(
    "api/health-score/",
    views.health_score_data,
    name="technician_health_score_data",
    ),

]