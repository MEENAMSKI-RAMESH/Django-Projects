from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

from .models import Technician
from Administrator.models import (
    Department,
    Equipment,
    Maintenance,
    LiveMonitoring,
    AIPrediction,
    Notification
)


# ==========================================================
# Technician Login
# ==========================================================

def technician_login(request):

    if request.method == "POST":

        email = request.POST.get("email")
        password = request.POST.get("password")

        try:

            technician = Technician.objects.get(
                email=email,
                password=password,
                status="Active"
            )

            request.session["technician_id"] = technician.id
            request.session["technician_name"] = (
                technician.first_name + " " + technician.last_name
            )

            technician.is_online = True
            technician.save()

            messages.success(request, "Login Successful")

            return redirect("technician_dashboard")

        except Technician.DoesNotExist:

            messages.error(request, "Invalid Email or Password")

    return render(
        request,
        "Technician/login.html"
    )


# ==========================================================
# Technician Logout
# ==========================================================

def technician_logout(request):

    if "technician_id" in request.session:

        technician = Technician.objects.get(
            id=request.session["technician_id"]
        )

        technician.is_online = False
        technician.save()

    request.session.flush()

    return redirect("Administrator:common_login")


# ==========================================================
# Technician Dashboard
# ==========================================================

def technician_dashboard(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    total_equipment = Equipment.objects.filter(
        department=technician.department
    ).count()

    # --- CHANGED: filter by department, not exact technician match ---
    pending = Maintenance.objects.filter(
        equipment__department=technician.department,
        status="Pending"
    ).count()

    progress = Maintenance.objects.filter(
        equipment__department=technician.department,
        status="In Progress"
    ).count()

    completed = Maintenance.objects.filter(
        equipment__department=technician.department,
        status="Completed"
    ).count()
    # --------------------------------------------------------------

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    context = {

        "technician": technician,

        "total_equipment": total_equipment,

        "pending": pending,

        "progress": progress,

        "completed": completed,

        "alerts": alerts,

    }

    return render(
        request,
        "Technician/dashboard.html",
        context
    )

# ==========================================================
# Statistics
# ==========================================================

def technician_statistics(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    total_jobs = Maintenance.objects.filter(
        technician=technician
    ).count()

    pending_jobs = Maintenance.objects.filter(
        technician=technician,
        status="Pending"
    ).count()

    progress_jobs = Maintenance.objects.filter(
        technician=technician,
        status="In Progress"
    ).count()

    completed_jobs = Maintenance.objects.filter(
        technician=technician,
        status="Completed"
    ).count()

    context = {

        "total_jobs": total_jobs,

        "pending_jobs": pending_jobs,

        "progress_jobs": progress_jobs,

        "completed_jobs": completed_jobs,

    }

    return render(
        request,
        "Technician/statistics.html",
        {
            "technician": technician,
            "total_jobs": total_jobs,
            "pending_jobs": pending_jobs,
            "progress_jobs": progress_jobs,
            "completed_jobs": completed_jobs,
            "alerts": alerts,
        }
    )


# ==========================================================
# View Profile
# ==========================================================

def view_profile(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    return render(
        request,
        "Technician/view_profile.html",
        {
            "technician": technician,
            "alerts": alerts,
        }
    )


# ==========================================================
# Edit Profile
# ==========================================================

def edit_profile(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    if request.method == "POST":

        technician.first_name = request.POST.get("first_name")

        technician.last_name = request.POST.get("last_name")

        technician.email = request.POST.get("email")

        technician.phone = request.POST.get("phone")

        technician.address = request.POST.get("address")

        technician.password = request.POST.get("password")

        if request.FILES.get("profile_image"):

            technician.profile_image = request.FILES.get(
                "profile_image"
            )

        technician.save()

        messages.success(
            request,
            "Profile Updated Successfully"
        )

        return redirect("view_profile")

    return render(
        request,
        "Technician/edit_profile.html",
        {
            "technician": technician,
            "alerts": alerts,
        }
    )


# ==========================================================
# View Assigned Department
# ==========================================================

def assigned_department(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.select_related(
        "department"
    ).get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    return render(
        request,
        "Technician/assigned_department.html",
        {
            "technician": technician,
            "department": technician.department,
            "alerts": alerts,
        }
    )



from django.utils import timezone


# ==========================================================
# View Assigned Equipment
# ==========================================================

def assigned_equipment(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    equipments = Equipment.objects.filter(
        department=technician.department
    ).select_related("department").prefetch_related(
        "department__technicians"
    ).order_by("equipment_name")

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    return render(
        request,
        "Technician/assigned_equipment.html",
        {
            "technician": technician,
            "equipments": equipments,
            "alerts": alerts,
        }
    )


# ==========================================================
# View Pending Maintenance
# ==========================================================
def pending_maintenance(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    # --- CHANGED: filter by department, not exact technician match ---
    maintenances = Maintenance.objects.select_related(
        "equipment", "technician"
    ).filter(
        equipment__department=technician.department
    ).order_by("scheduled_date")
    # --------------------------------------------------------------

    return render(
        request,
        "Technician/pending_maintenance.html",
        {
            "maintenances": maintenances,
            "alerts": alerts,
        }
    )




# ==========================================================
# Update Maintenance Status
# ==========================================================

def update_maintenance(request, maintenance_id):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    maintenance = get_object_or_404(
        Maintenance,
        id=maintenance_id
    )

    if request.method == "POST":

        maintenance.status = request.POST.get("status")
        maintenance.remarks = request.POST.get("remarks")

        if request.FILES.get("service_report"):
            maintenance.service_report = request.FILES.get(
                "service_report"
            )

        if maintenance.status == "Completed":
            maintenance.completed_date = timezone.now().date()

        maintenance.save()

        messages.success(
            request,
            "Maintenance Updated Successfully."
        )

        return redirect("pending_maintenance")

    return render(
        request,
        "Technician/update_maintenance.html",
        {
            "maintenance": maintenance
        }
    )


# ==========================================================
# Live Monitoring
# ==========================================================

def equipment_status(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    live_data = LiveMonitoring.objects.filter(
        equipment__department=technician.department
    ).select_related(
        "equipment"
    ).order_by("-updated_at")

    return render(
        request,
        "Technician/equipment_status.html",
        {
            "live_data": live_data,
            "alerts": alerts,
        }
    )


# ==========================================================
# Equipment Health Score
# ==========================================================

def equipment_health(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )
    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    predictions = AIPrediction.objects.filter(
        equipment__department=technician.department
    ).select_related(
        "equipment"
    ).order_by("-predicted_at")

    return render(
        request,
        "Technician/equipment_health.html",
        {
            "predictions": predictions,
            "alerts": alerts,
        }
    )


# ==========================================================
# Dashboard Notifications
# ==========================================================

def dashboard_notifications(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    notifications = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).order_by("-created_at")

    alerts = notifications.count()

    return render(
        request,
        "Technician/dashboard_notifications.html",
        {
            "notifications": notifications,
            "alerts": alerts,
        }
    )


# ==========================================================
# Email Notifications
# ==========================================================

def email_notifications(request):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    alerts = Notification.objects.filter(
        technician=technician,
        notification_type="Dashboard"
    ).count()

    status_filter = request.GET.get("status")

    emails = Notification.objects.filter(
        technician=technician,
        notification_type="Email"
    ).select_related("equipment").order_by("-created_at")

    if status_filter in ("Pending", "Processing", "Completed"):
        emails = emails.filter(status=status_filter)

    return render(
        request,
        "Technician/email_notifications.html",
        {
            "emails": emails,
            "status_filter": status_filter,
            "alerts": alerts,
        }
    )



def update_notification(request, notification_id):

    if "technician_id" not in request.session:
        return redirect("technician_login")

    notification = get_object_or_404(
        Notification,
        id=notification_id,
        technician_id=request.session["technician_id"]
    )

    if request.method == "POST":

        notification.status = request.POST.get("status")
        notification.technician_remarks = request.POST.get("remarks")
        notification.responded_at = timezone.now()
        notification.save()

        messages.success(request, "Notification Updated Successfully")

        return redirect("email_notifications")

    return render(
        request,
        "Technician/update_notification.html",
        {"notification": notification}
    )



def live_equipment_status_data(request):

    if "technician_id" not in request.session:
        return JsonResponse({"error": "Not logged in"}, status=403)

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    live_data = LiveMonitoring.objects.filter(
        equipment__department=technician.department
    ).select_related("equipment").order_by("-updated_at")

    data = []
    for item in live_data:
        data.append({
            "equipment": item.equipment.equipment_name,
            "temperature": item.temperature,
            "battery_health": item.battery_health,
            "operating_hours": item.operating_hours,
            "error_count": item.error_count,
            "device_status": item.device_status,
        })

    return JsonResponse({"live_data": data})

def health_score_data(request):

    if "technician_id" not in request.session:
        return JsonResponse({"error": "Not logged in"}, status=403)

    technician = Technician.objects.get(
        id=request.session["technician_id"]
    )

    predictions = AIPrediction.objects.filter(
        equipment__department=technician.department
    ).select_related("equipment").order_by("-predicted_at")

    data = []
    for p in predictions:
        data.append({
            "equipment": p.equipment.equipment_name,
            "health_score": p.health_score,
            "failure_probability": p.failure_probability,
            "remaining_useful_life": p.remaining_useful_life,
            "priority": p.maintenance_priority,
        })

    return JsonResponse({"predictions": data})