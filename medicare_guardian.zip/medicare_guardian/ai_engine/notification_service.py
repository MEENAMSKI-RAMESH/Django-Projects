from Administrator.models import Notification
from Technician.models import Technician

from Administrator.models import Notification
from Technician.models import Technician


def create_dashboard_notification(equipment, probability, priority):

    technician = Technician.objects.filter(
        department=equipment.department,
        status="Active"
    ).first()

    if technician is None:
        return

    Notification.objects.create(
        equipment=equipment,
        technician=technician,
        title=f"{priority} Equipment Alert",
        message=(
            f"{equipment.equipment_name} has "
            f"{probability:.2f}% failure probability.\n"
            f"Maintenance Priority: {priority}"
        ),
        notification_type="Dashboard"
    )


# --- NEW ---
def create_email_notification(equipment, technician, probability, priority):

    if technician is None:
        return

    Notification.objects.create(
        equipment=equipment,
        technician=technician,
        title=f"{priority} Equipment Alert - Email Sent",
        message=(
            f"An email alert was sent to {technician.first_name} "
            f"regarding {equipment.equipment_name} "
            f"({probability:.2f}% failure probability, {priority} priority)."
        ),
        notification_type="Email"
    )