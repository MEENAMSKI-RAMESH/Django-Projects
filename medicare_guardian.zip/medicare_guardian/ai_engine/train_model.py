import os
import sys
import joblib
import pandas as pd

# Project root (folder containing manage.py)
BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

# Add project root to Python path
sys.path.insert(0, BASE_DIR)

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)

import django

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "medicare_guardian.settings"
)

django.setup()

from ai_engine.models import ModelTraining


dataset_path = os.path.join(
    BASE_DIR,
    "dataset",
    "equipment_dataset.csv"
)

df = pd.read_csv(dataset_path)

X = df[
    [
        "temperature",
        "battery_health",
        "operating_hours",
        "error_count",
    ]
]

y = df["failure"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

model = RandomForestClassifier(

    n_estimators=200,

    random_state=42

)

model.fit(

    X_train,

    y_train

)

predictions = model.predict(X_test)

accuracy = accuracy_score(
    y_test,
    predictions
)

precision = precision_score(
    y_test,
    predictions
)

recall = recall_score(
    y_test,
    predictions
)

f1 = f1_score(
    y_test,
    predictions
)


model_folder = os.path.join(
    BASE_DIR,
    "ml_models"
)

os.makedirs(
    model_folder,
    exist_ok=True
)

model_path = os.path.join(
    model_folder,
    "random_forest.pkl"
)

joblib.dump(
    model,
    model_path
)

print("\n===========================")
print("Random Forest Trained")
print("===========================")

print(f"Accuracy : {accuracy:.2%}")
print(f"Precision: {precision:.2%}")
print(f"Recall   : {recall:.2%}")
print(f"F1 Score : {f1:.2%}")

print("\nModel Saved Successfully")

print(model_path)