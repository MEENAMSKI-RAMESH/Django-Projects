from django.apps import AppConfig


class AiEngineConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = 'ai_engine'
    def ready(self):

        from .scheduler import start

        start()
