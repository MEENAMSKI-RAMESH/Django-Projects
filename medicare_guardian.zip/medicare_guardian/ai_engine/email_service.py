from django.core.mail import send_mail
from django.conf import settings


def send_failure_alert(
    technician,
    equipment,
    probability,
    priority
):

    subject = f"🚨 {priority} Equipment Alert"

    message = f"""
Dear {technician.first_name},

The AI Monitoring System has detected a potential issue.

Equipment Details
-------------------------
Equipment : {equipment.equipment_name}
Department: {equipment.department.department_name}

Failure Probability : {probability:.2f}%
Priority            : {priority}

Please inspect the equipment immediately.

Regards,
MediCare Guardian AI
"""

    send_mail(

        subject,

        message,

        settings.EMAIL_HOST_USER,

        [technician.email],

        fail_silently=False,

    )