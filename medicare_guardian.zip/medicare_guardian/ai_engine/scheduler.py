from apscheduler.schedulers.background import BackgroundScheduler

from .simulator import generate_sensor_data


scheduler = BackgroundScheduler()


def start():

    if not scheduler.running:

        scheduler.add_job(

            generate_sensor_data,

            "interval",

            seconds=15,

            id="live_simulation",

            replace_existing=True

        )

        scheduler.start()

        print("APScheduler Started")