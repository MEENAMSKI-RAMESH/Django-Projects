import random

from Administrator.models import Equipment, LiveMonitoring
from .models import SimulationLog
from .predictor import predict_equipment

def generate_sensor_data():

    equipments = Equipment.objects.all()

    for equipment in equipments:

        temperature = round(random.uniform(30, 90), 2)

        battery_health = round(random.uniform(40, 100), 2)

        operating_hours = random.randint(100, 10000)

        error_count = random.randint(0, 10)

        if temperature < 50 and battery_health > 70:

            device_status = "Working"

        elif temperature < 70:

            device_status = "Maintenance"

        else:

            device_status = "Critical"

        LiveMonitoring.objects.update_or_create(

            equipment=equipment,

            defaults={

                "temperature": temperature,

                "battery_health": battery_health,

                "operating_hours": operating_hours,

                "error_count": error_count,

                "device_status": device_status

            }

        )
        predict_equipment(equipment)

        SimulationLog.objects.create(

            equipment=equipment,

            temperature=temperature,

            battery_health=battery_health,

            operating_hours=operating_hours,

            error_count=error_count,

            device_status=device_status

        )

    print("Live Data Generated")