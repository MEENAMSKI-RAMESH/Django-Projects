from django.db import models

# Create your models here.
from django.db import models
from Administrator.models import Equipment


class ModelTraining(models.Model):

    model_name = models.CharField(
        max_length=100,
        default="Random Forest"
    )

    accuracy = models.FloatField()

    precision = models.FloatField()

    recall = models.FloatField()

    f1_score = models.FloatField()

    trained_at = models.DateTimeField(
        auto_now_add=True
    )

    training_samples = models.IntegerField()

    def __str__(self):
        return self.model_name


class SimulationLog(models.Model):

    equipment = models.ForeignKey(
        Equipment,
        on_delete=models.CASCADE,
        related_name="simulation_logs"
    )

    temperature = models.FloatField()

    battery_health = models.FloatField()

    operating_hours = models.IntegerField()

    error_count = models.IntegerField()

    device_status = models.CharField(
        max_length=30
    )

    generated_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.equipment.equipment_name


class PredictionHistory(models.Model):

    equipment = models.ForeignKey(
        Equipment,
        on_delete=models.CASCADE
    )

    failure_probability = models.FloatField()

    health_score = models.FloatField()

    remaining_useful_life = models.IntegerField()

    maintenance_recommendation = models.TextField()

    predicted_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.equipment.equipment_name


class MaintenanceRecommendation(models.Model):

    equipment = models.ForeignKey(
        Equipment,
        on_delete=models.CASCADE
    )

    recommendation = models.TextField()

    priority = models.CharField(
        max_length=20
    )

    generated_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.equipment.equipment_name