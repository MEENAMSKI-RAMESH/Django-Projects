import os
import joblib
import pandas as pd

from django.conf import settings

from Administrator.models import (
    Equipment,
    LiveMonitoring,
    AIPrediction,
    Maintenance,
)
from .models import PredictionHistory
from .notification_service import create_dashboard_notification, create_email_notification
from .email_service import send_failure_alert

from Technician.models import Technician
from datetime import date

# -----------------------------
# Load Random Forest Model
# -----------------------------

MODEL_PATH = os.path.join(
    settings.BASE_DIR,
    "ml_models",
    "random_forest.pkl"
)

model = joblib.load(MODEL_PATH)


# -----------------------------
# Predict Equipment Failure
# -----------------------------

def predict_equipment(equipment):

    try:
        live = LiveMonitoring.objects.get(equipment=equipment)
    except LiveMonitoring.DoesNotExist:
        return

    data = pd.DataFrame([{
        "temperature": live.temperature,
        "battery_health": live.battery_health,
        "operating_hours": live.operating_hours,
        "error_count": live.error_count
    }])

    prediction = model.predict(data)[0]
    probability = model.predict_proba(data)[0][1] * 100

    health_score = calculate_health_score(live)
    rul = calculate_rul(live)
    priority = maintenance_priority(probability)

    AIPrediction.objects.update_or_create(
        equipment=equipment,
        defaults={
            "health_score": health_score,
            "failure_probability": round(probability, 2),
            "remaining_useful_life": rul,
            "maintenance_priority": priority
        }
    )
    # Sync Equipment.status based on AI priority
    if priority == "Critical":
        equipment.status = "Critical"
    elif priority in ("High", "Medium"):
        equipment.status = "Maintenance"
    else:
        equipment.status = "Working"

    equipment.save()

    PredictionHistory.objects.create(
        equipment=equipment,
        failure_probability=round(probability, 2),
        health_score=health_score,
        remaining_useful_life=rul,
        maintenance_recommendation=f"{priority} Priority Maintenance"
    )

    # -----------------------------------------
    # Create / Update Maintenance Record + Notify
    # -----------------------------------------
    if probability >= 70:

        maintenance = Maintenance.objects.filter(
            equipment=equipment,
            status="Pending"
        ).order_by("-created_at").first()

        if maintenance:
            maintenance.predicted_issue = (
                f"AI detected possible failure with {probability:.2f}% probability."
            )
            maintenance.failure_probability = probability
            maintenance.health_score = health_score
            maintenance.maintenance_priority = priority
            maintenance.save()
        else:
            maintenance = Maintenance.objects.create(
                equipment=equipment,
                technician=equipment.department.technicians.first(),
                scheduled_date=date.today(),
                predicted_issue=(
                    f"AI detected possible failure with {probability:.2f}% probability."
                ),
                failure_probability=probability,
                health_score=health_score,
                maintenance_priority=priority,
            )

        create_dashboard_notification(equipment, probability, priority)

        technician = Technician.objects.filter(
            department=equipment.department,
            status="Active"
        ).first()

        if technician:
            try:
                send_failure_alert(technician, equipment, probability, priority)
            except Exception as e:
                print(f"Email failed for {equipment.equipment_name}: {e}")

            create_email_notification(equipment, technician, probability, priority)

# -----------------------------
# Health Score
# -----------------------------

def calculate_health_score(live):
    score = 100
    score -= (live.temperature - 30) * 0.5
    score -= (100 - live.battery_health) * 0.4
    score -= live.error_count * 4
    score -= live.operating_hours / 1000
    score = max(0, min(100, score))
    return round(score, 2)


# -----------------------------
# Remaining Useful Life
# -----------------------------

def calculate_rul(live):
    rul = 365
    rul -= live.operating_hours / 40
    rul -= live.error_count * 5
    rul -= (live.temperature - 30)
    rul = max(0, int(rul))
    return rul


# -----------------------------
# Maintenance Priority
# -----------------------------

def maintenance_priority(probability):
    if probability >= 90:
        return "Critical"
    elif probability >= 70:
        return "High"
    elif probability >= 40:
        return "Medium"
    else:
        return "Low"