import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "medicare_guardian.settings")
django.setup()

from django.core.mail import send_mail

send_mail(
    subject="Test Email",
    message="This is a test email from MediCare Guardian AI.",
    from_email=None,
    recipient_list=["meenakshirameshflp@gmail.com"],  # Replace with your email
    fail_silently=False,
)

print("Email sent successfully!")