from django.db import models

# Create your models here.
from django.db import models


# -------------------- Admin --------------------

class Admin(models.Model):
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=255)

    def __str__(self):
        return self.username


# -------------------- Department --------------------

class Department(models.Model):
    department_name = models.CharField(max_length=100, unique=True)
    location = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.department_name


# -------------------- Equipment --------------------

class Equipment(models.Model):

    STATUS_CHOICES = [
        ('Working', 'Working'),
        ('Maintenance', 'Maintenance'),
        ('Critical', 'Critical'),
        ('Inactive', 'Inactive'),
    ]

    equipment_name = models.CharField(max_length=100)
    equipment_type = models.CharField(max_length=100)
    manufacturer = models.CharField(max_length=100)
    model_number = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=100, unique=True)

    purchase_date = models.DateField()
    warranty_expiry = models.DateField()

    department = models.ForeignKey(
        Department,
        on_delete=models.CASCADE,
        related_name='equipments'
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='Working'
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.equipment_name


# -------------------- Maintenance --------------------

from django.db import models
from Technician.models import Technician

class Maintenance(models.Model):

    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed'),
        ('Overdue', 'Overdue'),
    ]

    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
        ('Critical', 'Critical'),
    ]

    equipment = models.ForeignKey(
        Equipment,
        on_delete=models.CASCADE,
        related_name='maintenances'
    )

    # Assigned Technician
    technician = models.ForeignKey(
        Technician,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='maintenances'
    )

    scheduled_date = models.DateField()

    completed_date = models.DateField(
        blank=True,
        null=True
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='Pending'
    )

    # Admin's free-text note when manually scheduling maintenance
    remarks = models.TextField(
        blank=True,
        null=True,
        help_text="Optional remarks added when scheduling maintenance."
    )

    # AI-generated fields (filled automatically by ai_engine/predictor.py)
    predicted_issue = models.TextField(
        blank=True,
        null=True,
        help_text="AI-generated description of the predicted failure."
    )

    failure_probability = models.FloatField(
        blank=True,
        null=True,
        help_text="Failure probability (%) at the time this record was created/updated."
    )

    health_score = models.FloatField(
        blank=True,
        null=True,
        help_text="Equipment health score at the time this record was created/updated."
    )

    maintenance_priority = models.CharField(
        max_length=20,
        choices=PRIORITY_CHOICES,
        blank=True,
        null=True,
        help_text="AI-recommended maintenance priority."
    )

    # Technician records the actual fault
    issue_found = models.TextField(
        blank=True,
        null=True,
        help_text="Describe the issue identified in the equipment."
    )

    # Technician records the repair work
    maintenance_performed = models.TextField(
        blank=True,
        null=True,
        help_text="Describe the maintenance or repair performed."
    )

    # Upload service report (PDF/Image)
    service_report = models.FileField(
        upload_to='service_reports/',
        blank=True,
        null=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    def __str__(self):
        return f"{self.equipment.equipment_name} - {self.status}"
# -------------------- Live Monitoring --------------------

class LiveMonitoring(models.Model):

    equipment = models.ForeignKey(
        Equipment,
        on_delete=models.CASCADE,
        related_name='live_data'
    )

    temperature = models.FloatField()
    battery_health = models.FloatField()
    operating_hours = models.IntegerField()
    error_count = models.IntegerField()

    device_status = models.CharField(max_length=30)

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.equipment.equipment_name


# -------------------- AI Prediction --------------------

class AIPrediction(models.Model):

    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
        ('Critical', 'Critical'),
    ]

    equipment = models.ForeignKey(
        Equipment,
        on_delete=models.CASCADE,
        related_name='predictions'
    )

    health_score = models.FloatField()

    failure_probability = models.FloatField(
        help_text="Failure probability in percentage"
    )

    remaining_useful_life = models.IntegerField(
        help_text="Remaining Useful Life (days)"
    )

    maintenance_priority = models.CharField(
        max_length=20,
        choices=PRIORITY_CHOICES
    )

    predicted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.equipment.equipment_name} Prediction"


# -------------------- Notification --------------------

from django.db import models
from Technician.models import Technician


class Notification(models.Model):

    NOTIFICATION_TYPES = [
        ('Dashboard', 'Dashboard'),
        ('Email', 'Email'),
    ]

    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Processing', 'Processing'),
        ('Completed', 'Completed'),
    ]

    equipment = models.ForeignKey(
        'Equipment',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='notifications'
    )

    title = models.CharField(max_length=200)
    message = models.TextField()

    notification_type = models.CharField(
        max_length=20,
        choices=NOTIFICATION_TYPES
    )

    technician = models.ForeignKey(
        Technician,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='notifications'
    )

    is_read = models.BooleanField(default=False)

    # --- NEW: technician response tracking ---
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='Pending'
    )

    technician_remarks = models.TextField(
        blank=True,
        null=True,
        help_text="Technician's update on how this alert was handled."
    )

    responded_at = models.DateTimeField(
        blank=True,
        null=True
    )
    # -------------------------------------------

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    