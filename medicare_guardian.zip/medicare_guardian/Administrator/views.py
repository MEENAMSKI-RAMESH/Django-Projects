from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

from .models import Admin
from Technician.models import Technician


# =====================================================
# Admin Login
# =====================================================

from django.shortcuts import render, redirect
from django.contrib import messages

from Administrator.models import Admin
from Technician.models import Technician


def common_login(request):

    role = "Administrator"  # default for initial GET

    if request.method == "POST":

        role = request.POST.get("role")
        username = request.POST.get("username")
        password = request.POST.get("password")

        if role == "Administrator":
            try:
                admin = Admin.objects.get(username=username, password=password)
                request.session["admin_id"] = admin.id
                request.session["admin_username"] = admin.username
                return redirect("Administrator:admin_dashboard")
            except Admin.DoesNotExist:
                messages.error(request, "Invalid Administrator Login")

        elif role == "Technician":
            try:
                technician = Technician.objects.get(
                    email=username, password=password, status="Active"
                )
                request.session["technician_id"] = technician.id
                request.session["technician_name"] = technician.first_name

                technician.is_online = True
                technician.save()

                return redirect("technician_dashboard")
            except Technician.DoesNotExist:
                messages.error(request, "Invalid Technician Login")

    return render(request, "common/login.html", {"selected_role": role})
# =====================================================
# Admin Logout
# =====================================================

def admin_logout(request):

    request.session.flush()

    return redirect("common_login")


# =====================================================
# Dashboard
# =====================================================

from .models import (
    Department,
    Equipment,
    Maintenance,
    LiveMonitoring,
    Notification,
    AIPrediction
)
from Technician.models import Technician


def admin_dashboard(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    # --- ADD THIS ---
    today = timezone.now().date()
    overdue_count = Maintenance.objects.filter(
        scheduled_date__lt=today
    ).exclude(status="Completed").count()
    # ----------------


    context = {

        # Technician
        "total_technicians": Technician.objects.count(),
        "active_technicians": Technician.objects.filter(status="Active").count(),

        # Department
        "total_departments": Department.objects.count(),

        # Equipment
        "total_equipment": Equipment.objects.count(),
        "working_equipment": Equipment.objects.filter(status="Working").count(),
        "maintenance_equipment": Equipment.objects.filter(status="Maintenance").count(),
        "critical_equipment": Equipment.objects.filter(status="Critical").count(),

        # Maintenance
        "pending_maintenance": Maintenance.objects.filter(status="Pending").count(),
        "completed_maintenance": Maintenance.objects.filter(status="Completed").count(),
        "overdue_maintenance": overdue_count,

        # AI
        "critical_predictions": AIPrediction.objects.filter(
            maintenance_priority="Critical"
        ).count(),

        # Notifications
        "unread_notifications": Notification.objects.filter(
            is_read=False
        ).count(),

        # Recent Data
        "recent_predictions": AIPrediction.objects.select_related(
            "equipment"
        ).order_by("-predicted_at")[:5],

        "recent_notifications": Notification.objects.order_by(
            "-created_at"
        )[:5],

        "recent_live_data": LiveMonitoring.objects.select_related(
            "equipment"
        ).order_by("-updated_at")[:5],

    }

    return render(
        request,
        "Administrator/dashboard.html",
        context
    )

# =====================================================
# Add Technician
# =====================================================

def add_technician(request):

    if "admin_id" not in request.session:

        return redirect("admin_login")

    if request.method == "POST":

        Technician.objects.create(

            technician_id=request.POST.get("technician_id"),

            first_name=request.POST.get("first_name"),

            last_name=request.POST.get("last_name"),

            gender=request.POST.get("gender"),

            email=request.POST.get("email"),

            phone=request.POST.get("phone"),

            password=request.POST.get("password"),

            designation=request.POST.get("designation"),

            qualification=request.POST.get("qualification"),

            experience=request.POST.get("experience"),

            joining_date=request.POST.get("joining_date"),

            address=request.POST.get("address"),

            status=request.POST.get("status"),

            profile_image=request.FILES.get("profile_image")

        )

        messages.success(request, "Technician Added Successfully")

        return redirect("Administrator:view_technicians")

    return render(
        request,
        "Administrator/add_technician.html"
    )


# =====================================================
# View Technicians
# =====================================================

def view_technicians(request):

    if "admin_id" not in request.session:

        return redirect("Administrator:admin_login")

    technicians = Technician.objects.all().order_by("technician_id")

    return render(
        request,
        "Administrator/view_technicians.html",
        {
            "technicians": technicians
        }
    )


# =====================================================
# Edit Technician
# =====================================================

def edit_technician(request, id):

    if "admin_id" not in request.session:

        return redirect("Administrator:admin_login")

    technician = get_object_or_404(
        Technician,
        id=id
    )

    if request.method == "POST":

        technician.technician_id = request.POST.get("technician_id")

        technician.first_name = request.POST.get("first_name")

        technician.last_name = request.POST.get("last_name")

        technician.gender = request.POST.get("gender")

        technician.email = request.POST.get("email")

        technician.phone = request.POST.get("phone")

        technician.password = request.POST.get("password")

        technician.designation = request.POST.get("designation")

        technician.qualification = request.POST.get("qualification")

        technician.experience = request.POST.get("experience")

        technician.joining_date = request.POST.get("joining_date")

        technician.address = request.POST.get("address")

        technician.status = request.POST.get("status")

        if request.FILES.get("profile_image"):

            technician.profile_image = request.FILES.get(
                "profile_image"
            )

        technician.save()

        messages.success(request, "Technician Updated Successfully")

        return redirect("Administrator:view_technicians")

    return render(
        request,
        "Administrator/edit_technician.html",
        {
            "technician": technician
        }
    )


# =====================================================
# Delete Technician
# =====================================================

def delete_technician(request, id):

    if "admin_id" not in request.session:

        return redirect("Administrator:admin_login")

    technician = get_object_or_404(
        Technician,
        id=id
    )

    technician.delete()

    messages.success(
        request,
        "Technician Deleted Successfully"
    )

    return redirect("view_technicians")



from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

from .models import Department, Equipment
from Technician.models import Technician


# ======================================================
# Department Management
# ======================================================

# Add Department
def add_department(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    if request.method == "POST":

        department_name = request.POST.get("department_name")
        location = request.POST.get("location")
        description = request.POST.get("description")

        Department.objects.create(
            department_name=department_name,
            location=location,
            description=description
        )

        messages.success(request, "Department Added Successfully")
        return redirect("Administrator:view_departments")

    return render(request, "Administrator/add_department.html")


# View Departments
def view_departments(request):

    if "admin_id" not in request.session:
        return redirect("admin_login")

    departments = Department.objects.all().order_by("department_name")

    return render(
        request,
        "Administrator/view_departments.html",
        {"departments": departments}
    )


# Assign Technician to Department
def assign_technician(request, department_id):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    department = get_object_or_404(Department, id=department_id)

    technicians = Technician.objects.all()

    if request.method == "POST":

        technician = get_object_or_404(
            Technician,
            id=request.POST.get("technician")
        )

        technician.department = department
        technician.save()

        messages.success(request, "Technician Assigned Successfully")

        return redirect("Administrator:view_departments")

    return render(
        request,
        "Administrator/assign_technician.html",
        {
            "department": department,
            "technicians": technicians
        }
    )
# ======================================================
# Edit Department
# ======================================================

def edit_department(request, id):

    if "admin_id" not in request.session:
        return redirect("admin_login")

    department = get_object_or_404(
        Department,
        id=id
    )

    if request.method == "POST":

        department.department_name = request.POST.get("department_name")

        department.location = request.POST.get("location")

        department.description = request.POST.get("description")

        department.save()

        messages.success(
            request,
            "Department Updated Successfully"
        )

        return redirect("Administrator:view_departments")

    return render(
        request,
        "Administrator/edit_department.html",
        {
            "department": department
        }
    )
# ======================================================
# Delete Department
# ======================================================

def delete_department(request, id):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    department = get_object_or_404(Department, id=id)

    department.delete()

    messages.success(request, "Department Deleted Successfully")

    return redirect("Administrator:view_departments")
# ======================================================
# Equipment Management
# ======================================================

# Add Equipment
def add_equipment(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    departments = Department.objects.all()

    if request.method == "POST":

        department = get_object_or_404(
            Department,
            id=request.POST.get("department")
        )

        Equipment.objects.create(

            equipment_name=request.POST.get("equipment_name"),

            equipment_type=request.POST.get("equipment_type"),

            manufacturer=request.POST.get("manufacturer"),

            model_number=request.POST.get("model_number"),

            serial_number=request.POST.get("serial_number"),

            purchase_date=request.POST.get("purchase_date"),

            warranty_expiry=request.POST.get("warranty_expiry"),

            department=department,

            status=request.POST.get("status")

        )

        messages.success(request, "Equipment Added Successfully")

        return redirect("Administrator:view_equipment")

    return render(
        request,
        "Administrator/add_equipment.html",
        {
            "departments": departments
        }
    )


# View Equipment
def view_equipment(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    equipments = Equipment.objects.select_related(
        "department"
    ).prefetch_related(
        "department__technicians"
    ).all().order_by("equipment_name")

    return render(
        request,
        "Administrator/view_equipment.html",
        {"equipments": equipments}
    )


# Edit Equipment
def edit_equipment(request, equipment_id):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    equipment = get_object_or_404(
        Equipment,
        id=equipment_id
    )

    departments = Department.objects.all()

    if request.method == "POST":

        equipment.equipment_name = request.POST.get("equipment_name")

        equipment.equipment_type = request.POST.get("equipment_type")

        equipment.manufacturer = request.POST.get("manufacturer")

        equipment.model_number = request.POST.get("model_number")

        equipment.serial_number = request.POST.get("serial_number")

        equipment.purchase_date = request.POST.get("purchase_date")

        equipment.warranty_expiry = request.POST.get("warranty_expiry")

        equipment.department = get_object_or_404(
            Department,
            id=request.POST.get("department")
        )

        equipment.status = request.POST.get("status")

        equipment.save()

        messages.success(request, "Equipment Updated Successfully")

        return redirect("Administrator:view_equipment")

    return render(
        request,
        "Administrator/edit_equipment.html",
        {
            "equipment": equipment,
            "departments": departments
        }
    )


# Delete Equipment
def delete_equipment(request, equipment_id):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    equipment = get_object_or_404(
        Equipment,
        id=equipment_id
    )

    equipment.delete()

    messages.success(request, "Equipment Deleted Successfully")

    return redirect("Administrator:view_equipment")



from .models import Maintenance, LiveMonitoring, Equipment
from django.utils import timezone


# ======================================================
# Create Maintenance Schedule
# ======================================================

def create_maintenance(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    equipments = Equipment.objects.all().order_by("equipment_name")

    if request.method == "POST":

        equipment = get_object_or_404(
            Equipment,
            id=request.POST.get("equipment")
        )

        Maintenance.objects.create(

            equipment=equipment,

            scheduled_date=request.POST.get("scheduled_date"),

            remarks=request.POST.get("remarks"),

            status="Pending"

        )

        messages.success(
            request,
            "Maintenance Schedule Created Successfully"
        )

        return redirect("Administrator:pending_maintenance")

    return render(
        request,
        "Administrator/create_maintenance.html",
        {
            "equipments": equipments
        }
    )


# ======================================================
# View Pending Maintenance
# ======================================================

def pending_maintenance(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    maintenances = Maintenance.objects.filter(
        status="Pending"
    ).order_by("scheduled_date")

    return render(
        request,
        "Administrator/pending_maintenance.html",
        {
            "maintenances": maintenances
        }
    )


# ======================================================
# View Completed Maintenance
# ======================================================

def completed_maintenance(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    maintenances = Maintenance.objects.filter(
        status="Completed"
    ).order_by("-completed_date")

    return render(
        request,
        "Administrator/completed_maintenance.html",
        {
            "maintenances": maintenances
        }
    )


# ======================================================
# View Overdue Maintenance
# ======================================================

def overdue_maintenance(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    today = timezone.now().date()

    overdue = Maintenance.objects.filter(
        scheduled_date__lt=today
    ).exclude(status="Completed")

    return render(
        request,
        "Administrator/overdue_maintenance.html",
        {
            "maintenances": overdue
        }
    )


# ======================================================
# Live Monitoring
# ======================================================

def live_monitoring(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    live_data = LiveMonitoring.objects.select_related(
        "equipment"
    ).all().order_by("-updated_at")

    return render(
        request,
        "Administrator/live_monitoring.html",
        {
            "live_data": live_data
        }
    )


# ======================================================
# Simulated Equipment Data
# ======================================================

def simulated_equipment_data(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    simulated_data = LiveMonitoring.objects.select_related(
        "equipment"
    ).all().order_by("-updated_at")

    return render(
        request,
        "Administrator/simulated_data.html",
        {
            "simulated_data": simulated_data
        }
    )


from .models import (
    AIPrediction,
    Notification,
    Equipment,
    Maintenance,
    Department
)

from Technician.models import Technician

# ======================================================
# Equipment Health Score
# ======================================================

def equipment_health_score(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    predictions = AIPrediction.objects.select_related(
        "equipment"
    ).all().order_by("-predicted_at")

    return render(
        request,
        "Administrator/health_score.html",
        {
            "predictions": predictions
        }
    )

# ======================================================
# Failure Probability
# ======================================================

def failure_probability(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    predictions = AIPrediction.objects.select_related(
        "equipment"
    ).all().order_by("-failure_probability")

    return render(
        request,
        "Administrator/failure_probability.html",
        {
            "predictions": predictions
        }
    )

# ======================================================
# Remaining Useful Life
# ======================================================

def remaining_useful_life(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    predictions = AIPrediction.objects.select_related(
        "equipment"
    ).all().order_by("remaining_useful_life")

    return render(
        request,
        "Administrator/rul.html",
        {
            "predictions": predictions
        }
    )

# ======================================================
# Maintenance Priority
# ======================================================

def maintenance_priority(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    predictions = AIPrediction.objects.select_related(
        "equipment"
    ).all()

    return render(
        request,
        "Administrator/maintenance_priority.html",
        {
            "predictions": predictions
        }
    )


# ======================================================
# Dashboard Alerts
# ======================================================

def dashboard_alerts(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    alerts = Notification.objects.filter(
        notification_type="Dashboard"
    ).order_by("-created_at")

    return render(
        request,
        "Administrator/dashboard_alerts.html",
        {
            "alerts": alerts
        }
    )

# ======================================================
# Email Notifications
# ======================================================

def email_notifications(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    status_filter = request.GET.get("status")

    emails = Notification.objects.filter(
        notification_type="Email"
    ).select_related("equipment", "technician").order_by("-created_at")

    if status_filter in ("Pending", "Processing", "Completed"):
        emails = emails.filter(status=status_filter)

    return render(
        request,
        "Administrator/email_notifications.html",
        {
            "emails": emails,
            "status_filter": status_filter,
        }
    )

# ======================================================
# Notification History
# ======================================================

def notification_history(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    notifications = Notification.objects.all().order_by("-created_at")

    return render(
        request,
        "Administrator/notification_history.html",
        {
            "notifications": notifications
        }
    )

# ======================================================
# Equipment Report
# ======================================================

def equipment_report(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    equipments = Equipment.objects.select_related(
        "department"
    ).all()

    return render(
        request,
        "Administrator/equipment_report.html",
        {
            "equipments": equipments
        }
    )

# ======================================================
# Maintenance Report
# ======================================================

def maintenance_report(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    maintenances = Maintenance.objects.select_related(
        "equipment"
    ).all()

    return render(
        request,
        "Administrator/maintenance_report.html",
        {
            "maintenances": maintenances
        }
    )

# ======================================================
# Technician Report
# ======================================================

def technician_report(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    technicians = Technician.objects.all()

    return render(
        request,
        "Administrator/technician_report.html",
        {
            "technicians": technicians
        }
    )


# ======================================================
# Department Report
# ======================================================

def department_report(request):

    if "admin_id" not in request.session:
        return redirect("Administrator:admin_login")

    departments = Department.objects.all()

    return render(
        request,
        "Administrator/department_report.html",
        {
            "departments": departments
        }
    )



from django.http import JsonResponse

from django.http import JsonResponse

def live_dashboard_data(request):

    # --- ADD THIS ---
    today = timezone.now().date()
    overdue_count = Maintenance.objects.filter(
        scheduled_date__lt=today
    ).exclude(status="Completed").count()
    # ----------------

    data = {

        "total_technicians": Technician.objects.count(),

        "active_technicians": Technician.objects.filter(
            status="Active"
        ).count(),

        "total_departments": Department.objects.count(),

        "total_equipment": Equipment.objects.count(),

        "working_equipment": Equipment.objects.filter(
            status="Working"
        ).count(),

        "maintenance_equipment": Equipment.objects.filter(
            status="Maintenance"
        ).count(),

        "critical_equipment": Equipment.objects.filter(
            status="Critical"
        ).count(),

        "pending_maintenance": Maintenance.objects.filter(
            status="Pending"
        ).count(),

        "completed_maintenance": Maintenance.objects.filter(
            status="Completed"
        ).count(),

        "overdue_maintenance": overdue_count,

        "critical_predictions": AIPrediction.objects.filter(
            maintenance_priority="Critical"
        ).count(),

        "unread_notifications": Notification.objects.filter(
            is_read=False
        ).count(),

    }

    return JsonResponse(data)

def live_prediction_data(request):

    predictions = AIPrediction.objects.select_related(
        "equipment"
    ).order_by("-predicted_at")[:10]

    data = []

    for prediction in predictions:

        data.append({

            "equipment": prediction.equipment.equipment_name,

            "health_score": prediction.health_score,

            "failure_probability": prediction.failure_probability,

            "priority": prediction.maintenance_priority,

        })

    return JsonResponse(
        {"predictions": data}
    )

def live_notification_data(request):

    notifications = Notification.objects.order_by(
        "-created_at"
    )[:10]

    data = []

    for notification in notifications:

        data.append({

            "title": notification.title,

            "message": notification.message,

            "type": notification.notification_type,

            "created_at": notification.created_at.strftime(
                "%d-%m-%Y %H:%M"
            ),

        })

    return JsonResponse(
        {"notifications": data}
    )


# ======================================================
# Live Monitoring JSON (AJAX)
# ======================================================

def live_monitoring_data(request):

    live_data = LiveMonitoring.objects.select_related(
        "equipment"
    ).all().order_by("-updated_at")

    data = []

    for item in live_data:
        data.append({
            "equipment": item.equipment.equipment_name,
            "temperature": item.temperature,
            "battery_health": item.battery_health,
            "operating_hours": item.operating_hours,
            "error_count": item.error_count,
            "device_status": item.device_status,
            "updated_at": timezone.localtime(item.updated_at).strftime("%d-%m-%Y %I:%M %p"),
        })

    return JsonResponse({"live_data": data})


# ======================================================
# Simulated Data JSON (AJAX)
# ======================================================

def simulated_data_json(request):

    simulated_data = LiveMonitoring.objects.select_related(
        "equipment"
    ).all().order_by("-updated_at")

    data = []

    for item in simulated_data:
        data.append({
            "equipment": item.equipment.equipment_name,
            "temperature": item.temperature,
            "battery_health": item.battery_health,
            "operating_hours": item.operating_hours,
            "error_count": item.error_count,
            "device_status": item.device_status,
        })

    return JsonResponse({"simulated_data": data})


# ======================================================
# Health Score JSON (AJAX + Charts)
# ======================================================

def health_score_data(request):

    predictions = AIPrediction.objects.select_related(
        "equipment"
    ).all().order_by("-predicted_at")

    data = []

    for p in predictions:
        data.append({
            "equipment": p.equipment.equipment_name,
            "department": p.equipment.department.department_name,
            "health_score": p.health_score,
            "failure_probability": p.failure_probability,
            "maintenance_priority": p.maintenance_priority,
            "updated_at": timezone.localtime(p.predicted_at).strftime("%d-%m-%Y %I:%M %p"),
        })

    return JsonResponse({"predictions": data})