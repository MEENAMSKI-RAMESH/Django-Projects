from django.urls import path
from . import views

app_name = "Administrator"

urlpatterns = [

    # Authentication
    path('', views.common_login, name='common_login'),
    path('logout/', views.admin_logout, name='admin_logout'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),

    # Technician Management
    path('add-technician/', views.add_technician, name='add_technician'),
    path('view-technicians/', views.view_technicians, name='view_technicians'),
    path('edit-technician/<int:id>/', views.edit_technician, name='edit_technician'),
    path('delete-technician/<int:id>/', views.delete_technician, name='delete_technician'),

    # Department Management
    path('add-department/', views.add_department, name='add_department'),
    path('view-departments/', views.view_departments, name='view_departments'),
    path(
        'assign-technician/<int:department_id>/',
        views.assign_technician,
        name='assign_technician'
    ),
    path('edit-department/<int:id>/', views.edit_department, name='edit_department'),
    path(
    'delete-department/<int:id>/',
    views.delete_department,
    name='delete_department'
),

    # Equipment Management
    path('add-equipment/', views.add_equipment, name='add_equipment'),
    path('view-equipment/', views.view_equipment, name='view_equipment'),
    path(
        'edit-equipment/<int:equipment_id>/',
        views.edit_equipment,
        name='edit_equipment'
    ),
    path(
        'delete-equipment/<int:equipment_id>/',
        views.delete_equipment,
        name='delete_equipment'
    ),


    # ===========================
    # Maintenance Management
    # ===========================

    path(
        'create-maintenance/',
        views.create_maintenance,
        name='create_maintenance'
    ),

    path(
        'pending-maintenance/',
        views.pending_maintenance,
        name='pending_maintenance'
    ),

    path(
        'completed-maintenance/',
        views.completed_maintenance,
        name='completed_maintenance'
    ),

    path(
        'overdue-maintenance/',
        views.overdue_maintenance,
        name='overdue_maintenance'
    ),

    # ===========================
    # Live Monitoring
    # ===========================

    path(
        'live-monitoring/',
        views.live_monitoring,
        name='live_monitoring'
    ),

    path(
        'simulated-data/',
        views.simulated_equipment_data,
        name='simulated_equipment_data'
    ),

        # AI Prediction
    path(
        'health-score/',
        views.equipment_health_score,
        name='equipment_health_score'
    ),

    path(
        'failure-probability/',
        views.failure_probability,
        name='failure_probability'
    ),

    path(
        'remaining-useful-life/',
        views.remaining_useful_life,
        name='remaining_useful_life'
    ),

    path(
        'maintenance-priority/',
        views.maintenance_priority,
        name='maintenance_priority'
    ),

    # Notifications
    path(
        'dashboard-alerts/',
        views.dashboard_alerts,
        name='dashboard_alerts'
    ),

    path(
        'email-notifications/',
        views.email_notifications,
        name='email_notifications'
    ),

    path(
        'notification-history/',
        views.notification_history,
        name='notification_history'
    ),

    # Reports
    path(
        'equipment-report/',
        views.equipment_report,
        name='equipment_report'
    ),

    path(
        'maintenance-report/',
        views.maintenance_report,
        name='maintenance_report'
    ),

    path(
        'technician-report/',
        views.technician_report,
        name='technician_report'
    ),

    path(
        'department-report/',
        views.department_report,
        name='department_report'
    ),



    # ==========================
    # Live Dashboard APIs
    # ==========================

    path('api/dashboard-data/', views.live_dashboard_data, name='live_dashboard_data'),
    path('api/predictions/', views.live_prediction_data, name='live_prediction_data'),
    path('api/notifications/', views.live_notification_data, name='live_notification_data'),

    path('api/live-monitoring/', views.live_monitoring_data, name='live_monitoring_data'),
    path('api/simulated-data/', views.simulated_data_json, name='simulated_data_json'),
    path('api/health-score/', views.health_score_data, name='health_score_data'),
    
]