from django.db import models
from django.contrib.auth.models import User

# ---------------------------- Admin & Event ----------------------------
class AdminTable(models.Model):
    username = models.CharField(max_length=150, unique=True)
    password = models.CharField(max_length=128)  # Ideally store hashed password

    def __str__(self):
        return self.username

class EventCategory(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    category = models.ForeignKey(EventCategory, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    venue = models.CharField(max_length=200)
    capacity = models.IntegerField()
    registration_deadline = models.DateTimeField()
    feedback_enabled = models.BooleanField(default=False)
    otp_enabled = models.BooleanField(default=False)
    is_closed = models.BooleanField(default=False)

    def __str__(self):
        return self.title
