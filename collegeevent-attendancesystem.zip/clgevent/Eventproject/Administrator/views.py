from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import HttpResponse, FileResponse
from django.utils import timezone
from django.core.mail import send_mail
from django.db.models import Count, Q
from reportlab.pdfgen import canvas
import io

from .models import *
from Coordinator.models import Announcement, Attendance, Coordinator, CoordinatorAssignment, Registration
from Student.models import Student

# ---------------------------- Home Page ----------------------------
def index(request):
    return render(request, 'index.html')

# ---------------------------- Admin Login ----------------------------
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            admin = AdminTable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin.id
            return redirect('admin_dashboard')
        except AdminTable.DoesNotExist:
            messages.error(request, 'Invalid credentials')
            return redirect('login')
    return render(request, 'Administrator/login.html')

# ---------------------------- Dashboard ----------------------------
def admin_dashboard(request):
    events = Event.objects.all()
    total_events = events.count()
    upcoming_events = events.filter(date__gte=timezone.now().date()).count()
    total_participants = Registration.objects.filter(is_approved=True).count()
    attendance_rate = (
        Attendance.objects.filter(is_present=True).count() /
        Attendance.objects.count() * 100
        if Attendance.objects.exists() else 0
    )
    context = {
        'events': events,
        'total_events': total_events,
        'upcoming_events': upcoming_events,
        'total_participants': total_participants,
        'attendance_rate': round(attendance_rate, 2)
    }
    return render(request, 'Administrator/dashboard.html', context)

# ---------------------------- Event Management ----------------------------
def create_event(request):
    categories = EventCategory.objects.all()
    if request.method == 'POST':
        Event.objects.create(
            title=request.POST['title'],
            description=request.POST['description'],
            category=EventCategory.objects.get(id=request.POST['category']),
            date=request.POST['date'],
            time=request.POST['time'],
            venue=request.POST['venue'],
            capacity=request.POST['capacity'],
            registration_deadline=request.POST['registration_deadline']
        )
        messages.success(request, "Event created successfully")
        return redirect('admin_dashboard')
    return render(request, 'Administrator/create_event.html', {'categories': categories})

# ---------------------------- Coordinator Registration ----------------------------
def register_coordinator(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        if Coordinator.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
        else:
            Coordinator.objects.create(
                username=username,
                email=email,
                password=password
            )
            messages.success(request, "Coordinator registered successfully")
            return redirect('manage_users')
    return render(request, 'Administrator/register_coordinator.html')

# ---------------------------- Event Categorization ----------------------------
def categorize_event(request):
    if request.method == 'POST':
        EventCategory.objects.create(name=request.POST['name'])
        messages.success(request, "Category added")
        return redirect('categorize_event')
    categories = EventCategory.objects.all()
    return render(request, 'Administrator/categorize_event.html', {'categories': categories})

# ---------------------------- Assign Coordinators ----------------------------
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from Coordinator.models import Coordinator, CoordinatorAssignment
from Administrator.models import Event

def assign_coordinators(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    # Get all coordinators
    all_coordinators = Coordinator.objects.all()
    print("All coordinators:", all_coordinators)  # Debugging

    # Get assigned coordinator IDs for this event
    assigned_ids = CoordinatorAssignment.objects.filter(event=event).values_list('coordinator_id', flat=True)

    if request.method == 'POST':
        selected_ids = request.POST.getlist('coordinators')
        
        # Clear previous assignments to avoid duplication
        CoordinatorAssignment.objects.filter(event=event).delete()
        
        for coordinator_id in selected_ids:
            coordinator = get_object_or_404(Coordinator, id=coordinator_id)
            CoordinatorAssignment.objects.create(coordinator=coordinator, event=event)
        
        messages.success(request, "Coordinators assigned successfully!")
        return redirect('admin_dashboard')

    return render(request, 'Administrator/assign_coordinators.html', {
        'event': event,
        'users': all_coordinators,
        'assigned_ids': list(assigned_ids),
    })


# ---------------------------- Registration Approvals ----------------------------
def approve_registration(request, registration_id):
    reg = get_object_or_404(Registration, id=registration_id)
    reg.is_approved = True
    reg.save()
    return redirect('admin_dashboard')

def reject_registration(request, registration_id):
    reg = get_object_or_404(Registration, id=registration_id)
    reg.delete()
    return redirect('admin_dashboard')

# ---------------------------- User Management ----------------------------
def manage_users(request):
    coordinators = Coordinator.objects.all()
    return render(request, 'Administrator/manage_users.html', {'coordinators': coordinators})

def remove_user(request, user_id):
    coordinator = get_object_or_404(Coordinator, id=user_id)
    coordinator.delete()
    return redirect('manage_users')

# ---------------------------- Attendance & Participation Reports ----------------------------
def attendance_reports(request):
    reports = Attendance.objects.all()
    return render(request, 'Administrator/attendance_reports.html', {'reports': reports})

def participation_summaries(request):
    regs = Registration.objects.all()
    return render(request, 'Administrator/participation_summaries.html', {'registrations': regs})

# ---------------------------- Announcements ----------------------------
def add_announcement(request):
    if request.method == 'POST':
        event = Event.objects.get(id=request.POST['event']) if request.POST['event'] else None
        Announcement.objects.create(event=event, message=request.POST['message'])
        messages.success(request, "Announcement added")
        return redirect('admin_dashboard')
    events = Event.objects.all()
    return render(request, 'Administrator/add_announcement.html', {'events': events})

# ---------------------------- Feedback and OTP Enable ----------------------------
def enable_feedback(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    event.feedback_enabled = True
    event.save()
    return redirect('admin_dashboard')

def enable_otp(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    event.otp_enabled = True
    event.save()
    return redirect('admin_dashboard')

# ---------------------------- Set Event Capacity ----------------------------
def set_event_capacity(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if request.method == 'POST':
        event.capacity = request.POST['capacity']
        event.save()
        messages.success(request, "Capacity updated")
        return redirect('admin_dashboard')
    return render(request, 'Administrator/set_event_capacity.html', {'event': event})

# ---------------------------- Auto Close Registration ----------------------------
def auto_close_registration(request):
    now = timezone.now()
    closed_count = 0
    for event in Event.objects.filter(is_closed=False):
        if event.registration_deadline < now or event.registrations.count() >= event.capacity:
            event.is_closed = True
            event.save()
            closed_count += 1
    messages.success(request, f"{closed_count} events auto-closed.")
    return redirect('admin_dashboard')

# ---------------------------- Export Reports ----------------------------
def export_event_report(request, event_id, format):
    event = get_object_or_404(Event, id=event_id)
    if format == 'pdf':
        buffer = io.BytesIO()
        p = canvas.Canvas(buffer)
        p.drawString(100, 800, f"Event Report: {event.title}")
        p.drawString(100, 780, f"Date: {event.date}")
        p.drawString(100, 760, f"Venue: {event.venue}")
        p.drawString(100, 740, f"Total Registered: {event.registrations.count()}")
        p.showPage()
        p.save()
        buffer.seek(0)
        return FileResponse(buffer, as_attachment=True, filename=f'{event.title}_report.pdf')
    else:
        return HttpResponse("Format not supported yet.")

# ---------------------------- Promote to Coordinator ----------------------------
def promote_to_coordinator(request, user_id):
    coordinator = get_object_or_404(Coordinator, id=user_id)
    messages.success(request, f"{coordinator.username} is already a coordinator.")
    return redirect('manage_users')

# ---------------------------- Send Notifications ----------------------------
def send_notifications(request):
    users = Student.objects.all()
    for user in users:
        send_mail(
            'Upcoming Events',
            'Check out the new events on the portal!',
            'youremail@gmail.com',
            [user.email],
            fail_silently=True
        )
    messages.success(request, "Notifications sent to all students.")
    return redirect('admin_dashboard')
