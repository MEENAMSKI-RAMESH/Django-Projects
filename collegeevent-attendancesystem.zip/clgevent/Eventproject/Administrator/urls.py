from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login, name='login'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('coordinator_registration/' , views.register_coordinator, name='register_coordinator'),

    # Event management
    path('create_event/', views.create_event, name='create_event'),
    path('categorize_event/', views.categorize_event, name='categorize_event'),
    path('assign_coordinators/<int:event_id>/', views.assign_coordinators, name='assign_coordinators'),


    # User role management
    path('manage_users/', views.manage_users, name='manage_users'),
    path('promote_coordinator/<int:user_id>/', views.promote_to_coordinator, name='promote_to_coordinator'),
    path('remove_user/<int:user_id>/', views.remove_user, name='remove_user'),

    # Attendance and reports
    path('attendance_reports/', views.attendance_reports, name='attendance_reports'),
    path('participation_summaries/', views.participation_summaries, name='participation_summaries'),

    # Event capacity and notifications
    path('set_event_capacity/<int:event_id>/', views.set_event_capacity, name='set_event_capacity'),
    path('add_announcement/', views.add_announcement, name='add_announcement'),

    # Export reports
    path('export_event_report/<int:event_id>/<str:format>/', views.export_event_report, name='export_event_report'),

    # Feedback and OTP attendance
    path('enable_feedback/<int:event_id>/', views.enable_feedback, name='enable_feedback'),
    path('enable_otp/<int:event_id>/', views.enable_otp, name='enable_otp'),

    # Dashboard and stats
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),

    # Notifications
    path('send_notifications/', views.send_notifications, name='send_notifications'),

    # Auto close registrations
    path('auto_close_registration/', views.auto_close_registration, name='auto_close_registration'),
]
