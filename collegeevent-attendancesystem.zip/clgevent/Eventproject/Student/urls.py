from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login, name='student_login'),
    path('register/', views.register, name='student_register'),  # <-- Add this line
    path('dashboard/', views.student_dashboard, name='student_dashboard'),
    path('events/', views.event_list, name='event_list'),
    path('event/<int:event_id>/', views.event_detail, name='event_detail'),
    path('event/register/<int:event_id>/', views.register_event, name='register_event'),
    path('participation/', views.participation_history, name='participation_history'),
    path('attendance/', views.attendance_records, name='attendance_records'),
    path('feedback/<int:registration_id>/', views.submit_feedback, name='submit_feedback'),
    path('certificate/<int:registration_id>/', views.download_certificate, name='download_certificate'),
    path('filter_events/', views.filter_events, name='filter_events'),
    path('notifications/', views.notifications, name='student_notifications'),
    path('send_reminders/', views.send_event_reminders, name='send_reminders'),

]
