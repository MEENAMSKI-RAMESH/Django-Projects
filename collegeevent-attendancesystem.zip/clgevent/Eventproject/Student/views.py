from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import HttpResponse
from django.utils import timezone
from Administrator.models import Event
from Coordinator.models import Announcement, Attendance, Feedback, Registration
from .models import ParticipationCertificate, Student, StudentProfile 
import io

# -------------------- Student Registration --------------------
def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        full_name = request.POST['full_name']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        department = request.POST['department']
        year = request.POST['year']
        contact_number = request.POST['contact_number']

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, 'Student/register.html')

        if Student.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return render(request, 'Student/register.html')

        student = Student.objects.create(
            username=username,
            email=email,
            password=password,
            full_name=full_name
        )

        StudentProfile.objects.create(
            student=student,
            department=department,
            year=year,
            contact_number=contact_number
        )

        messages.success(request, "Registration successful. Please login.")
        return redirect('student_login')

    return render(request, 'Student/register.html')


# -------------------- Authentication --------------------
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            student = Student.objects.get(username=username)
            if student.password == password:
                request.session['student_id'] = student.id
                return redirect('student_dashboard')
            else:
                messages.error(request, "Invalid credentials.")
        except Student.DoesNotExist:
            messages.error(request, "User not found.")
    return render(request, 'Student/login.html')


# -------------------- Dashboard --------------------
def student_dashboard(request):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    announcements = Announcement.objects.filter(event__isnull=True).order_by('-created_at')
    return render(request, 'Student/dashboard.html', {'student': student, 'announcements': announcements})


# -------------------- Event Listing and Detail --------------------
def event_list(request):
    events = Event.objects.filter(is_closed=False).order_by('date')
    return render(request, 'Student/event_list.html', {'events': events})


def event_detail(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    return render(request, 'Student/event_detail.html', {'event': event})


def register_event(request, event_id):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    event = get_object_or_404(Event, id=event_id)

    if event.is_closed or timezone.now() > event.registration_deadline:
        messages.error(request, "Registration closed for this event.")
        return redirect('event_list')

    Registration.objects.get_or_create(student=student, event=event)
    messages.success(request, "You have successfully registered.")
    return redirect('participation_history')


# -------------------- Participation and Attendance --------------------
def participation_history(request):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    registrations = Registration.objects.filter(student=student)
    return render(request, 'Student/participation_history.html', {'registrations': registrations})


def attendance_records(request):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    attendance = Attendance.objects.filter(registration__student=student)
    return render(request, 'Student/attendance_records.html', {'attendance': attendance})


# -------------------- Feedback --------------------
def submit_feedback(request, registration_id):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    registration = get_object_or_404(Registration, id=registration_id, student=student)

    if not registration.event.feedback_enabled:
        messages.error(request, "Feedback is not enabled for this event.")
        return redirect('participation_history')

    if request.method == 'POST':
        rating = int(request.POST['rating'])
        comments = request.POST.get('comments', '')
        Feedback.objects.create(registration=registration, rating=rating, comments=comments)
        messages.success(request, "Thank you for your feedback.")
        return redirect('participation_history')

    return render(request, 'Student/submit_feedback.html', {'registration': registration})


# -------------------- Certificate Download --------------------
def download_certificate(request, registration_id):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    reg = get_object_or_404(Registration, id=registration_id, student=student)

    if not reg.is_approved:
        return HttpResponse("Not eligible for certificate", status=403)

    cert, created = ParticipationCertificate.objects.get_or_create(registration=reg, defaults={'issued': True})

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename=certificate_{reg.event.title}.pdf'
    response.write(f"Certificate of Participation: {reg.student.username} in {reg.event.title}")
    return response


# -------------------- Filter Events --------------------
def filter_events(request):
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    events = Event.objects.all()

    if query:
        events = events.filter(title__icontains=query)
    if category:
        events = events.filter(category__name__icontains=category)

    return render(request, 'Student/event_list.html', {'events': events})


# -------------------- Notifications --------------------
def notifications(request):
    student = get_object_or_404(Student, id=request.session.get('student_id'))
    announcements = Announcement.objects.filter(event__isnull=True).order_by('-created_at')
    return render(request, 'Student/notifications.html', {'announcements': announcements})


from django.core.mail import send_mail
from django.utils import timezone

def send_event_reminders(request):
    from Student.models import Student
    upcoming_events = Event.objects.filter(date__gte=timezone.now(), is_closed=False)
    
    for event in upcoming_events:
        registrations = Registration.objects.filter(event=event, is_approved=True)
        for reg in registrations:
            send_mail(
                subject=f"Reminder: {event.title}",
                message=f"Dear {reg.student.full_name},\n\nThis is a reminder that the event '{event.title}' is scheduled on {event.date} at {event.time} in {event.venue}.",
                from_email='youremail@example.com',
                recipient_list=[reg.student.email],
                fail_silently=True
            )

    messages.success(request, "Reminders sent.")
    return redirect('student_dashboard')
