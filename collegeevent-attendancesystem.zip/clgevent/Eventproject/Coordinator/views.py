import csv
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import HttpResponse
from Administrator.models import Event
from Coordinator.models import Announcement, Attendance, Coordinator, CoordinatorAssignment, EventReport, EventUpdateRequest, Feedback, Registration

# Login view
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            coordinator = Coordinator.objects.get(username=username)
            if coordinator.password == password:  # Ideally hash check
                request.session['coordinator_id'] = coordinator.id
                return redirect('coordinator_dashboard')
            else:
                messages.error(request, "Incorrect password")
        except Coordinator.DoesNotExist:
            messages.error(request, "Coordinator not found")
    return render(request, 'Coordinator/login.html')

# Dashboard
def coordinator_dashboard(request):
    coordinator = get_object_or_404(Coordinator, id=request.session.get('coordinator_id'))
    assignments = CoordinatorAssignment.objects.filter(coordinator=coordinator)
    return render(request, 'Coordinator/dashboard.html', {'assignments': assignments})

# Assigned events
def assigned_events(request):
    coordinator = get_object_or_404(Coordinator, id=request.session.get('coordinator_id'))
    events = Event.objects.filter(coordinatorassignment__coordinator=coordinator)
    return render(request, 'Coordinator/assigned_events.html', {'events': events})

# Approve/Reject registration
def approve_registration(request, registration_id):
    reg = get_object_or_404(Registration, id=registration_id)
    reg.is_approved = True
    reg.save()
    return redirect('assigned_events')

def reject_registration(request, registration_id):
    reg = get_object_or_404(Registration, id=registration_id)
    reg.delete()
    return redirect('assigned_events')

# Download student registration list
def download_registrations(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    registrations = Registration.objects.filter(event=event)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{event.title}_registrations.csv"'
    writer = csv.writer(response)
    writer.writerow(['Student', 'Email', 'Approved'])
    for reg in registrations:
        writer.writerow([reg.student.username, reg.student.email, reg.is_approved])
    return response

# Mark attendance
def mark_attendance(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    registrations = Registration.objects.filter(event=event, is_approved=True)
    if request.method == 'POST':
        for reg in registrations:
            status = request.POST.get(f'attend_{reg.id}') == 'on'
            Attendance.objects.update_or_create(registration=reg, defaults={'is_present': status})
        messages.success(request, "Attendance marked successfully")
        return redirect('assigned_events')
    return render(request, 'Coordinator/mark_attendance.html', {'event': event, 'registrations': registrations})

# Update event request
def update_event(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    coordinator = get_object_or_404(Coordinator, id=request.session.get('coordinator_id'))
    if request.method == 'POST':
        EventUpdateRequest.objects.create(
            event=event,
            coordinator=coordinator,
            new_date=request.POST.get('new_date'),
            new_time=request.POST.get('new_time'),
            new_venue=request.POST.get('new_venue'),
            reason=request.POST['reason']
        )
        messages.success(request, "Update request submitted")
        return redirect('assigned_events')
    return render(request, 'Coordinator/update_event.html', {'event': event})

# View attendance data
def attendance_data(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    records = Attendance.objects.filter(registration__event=event)
    return render(request, 'Coordinator/attendance_data.html', {'event': event, 'records': records})

# Export attendance
def export_attendance(request, event_id, format):
    event = get_object_or_404(Event, id=event_id)
    records = Attendance.objects.filter(registration__event=event)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{event.title}_attendance.csv"'
    writer = csv.writer(response)
    writer.writerow(['Student', 'Email', 'Present'])
    for record in records:
        writer.writerow([record.registration.student.username, record.registration.student.email, record.is_present])
    return response

# View feedback
def view_feedback(request, event_id):
    feedbacks = Feedback.objects.filter(registration__event__id=event_id)
    return render(request, 'Coordinator/view_feedback.html', {'feedbacks': feedbacks})

# Submit report
def submit_report(request, event_id):
    coordinator = get_object_or_404(Coordinator, id=request.session.get('coordinator_id'))
    if request.method == 'POST':
        EventReport.objects.create(
            event=Event.objects.get(id=event_id),
            coordinator=coordinator,
            content=request.POST['content']
        )
        messages.success(request, "Report submitted successfully")
        return redirect('assigned_events')
    return render(request, 'Coordinator/submit_report.html', {'event_id': event_id})

# Post update to event
def post_update(request, event_id):
    if request.method == 'POST':
        Announcement.objects.create(
            event=Event.objects.get(id=event_id),
            message=request.POST['message']
        )
        messages.success(request, "Update posted")
        return redirect('assigned_events')
    return render(request, 'Coordinator/post_update.html', {'event_id': event_id})

# Live participant count
def participant_count(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    count = Registration.objects.filter(event=event, is_approved=True).count()
    return render(request, 'Coordinator/participant_count.html', {'event': event, 'count': count})


def promote_to_coordinator(request, user_id):
    coordinator = get_object_or_404(Coordinator, id=user_id)
    # Logic can be added here (you already save them as coordinator during registration)
    messages.success(request, f"{coordinator.username} is already a coordinator.")
    return redirect('manage_users')