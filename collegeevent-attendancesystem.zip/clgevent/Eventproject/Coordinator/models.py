from django.db import models
from django.contrib.auth.models import User
from Administrator.models import Event 

class Coordinator(models.Model):
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField()
    password = models.CharField(max_length=128)
    full_name = models.CharField(max_length=200, blank=True)
    department = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.username

class CoordinatorAssignment(models.Model):
    coordinator = models.ForeignKey(Coordinator, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.coordinator.username} - {self.event.title}"

# ---------------------------- Event Participation ----------------------------
class Registration(models.Model):
    student = models.ForeignKey('Student.Student', on_delete=models.CASCADE, related_name='registrations')
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='registrations')
    is_approved = models.BooleanField(default=False)
    registered_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.username} - {self.event.title}"

class Attendance(models.Model):
    registration = models.ForeignKey(Registration, on_delete=models.CASCADE)
    is_present = models.BooleanField(default=False)
    otp_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"Attendance: {self.registration.student.username} - {self.registration.event.title}"

class Announcement(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, null=True, blank=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Announcement for {self.event.title if self.event else 'All Events'}"

class Feedback(models.Model):
    registration = models.ForeignKey(Registration, on_delete=models.CASCADE)
    rating = models.IntegerField()
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Feedback by {self.registration.student.username} for {self.registration.event.title}"

class ExportLog(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    exported_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    exported_at = models.DateTimeField(auto_now_add=True)
    format = models.CharField(max_length=10)

    def __str__(self):
        return f"{self.exported_by} exported {self.event} as {self.format}"

class EventReport(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    coordinator = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Report by {self.coordinator.username} for {self.event.title}"

class EventUpdateRequest(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    coordinator = models.ForeignKey(User, on_delete=models.CASCADE)
    new_date = models.DateField(null=True, blank=True)
    new_time = models.TimeField(null=True, blank=True)
    new_venue = models.CharField(max_length=200, null=True, blank=True)
    reason = models.TextField()
    is_approved = models.BooleanField(default=False)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Update Request by {self.coordinator.username} for {self.event.title}"

