from django.urls import path
from . import views

urlpatterns = [
    # Login and dashboard
    path('login/', views.login, name='coordinator_login'),
    path('dashboard/', views.coordinator_dashboard, name='coordinator_dashboard'),

    # View and manage assigned events
    path('assigned_events/', views.assigned_events, name='assigned_events'),

    # Registration approval
    path('approve_registration/<int:registration_id>/', views.approve_registration, name='approve_registration'),
    path('reject_registration/<int:registration_id>/', views.reject_registration, name='reject_registration'),

    # Download registration list
    path('download_registrations/<int:event_id>/', views.download_registrations, name='download_registrations'),

    # Mark attendance
    path('mark_attendance/<int:event_id>/', views.mark_attendance, name='mark_attendance'),

    # Update event schedule/location (requires admin approval)
    path('update_event/<int:event_id>/', views.update_event, name='update_event'),

    # View and export attendance
    path('attendance_data/<int:event_id>/', views.attendance_data, name='attendance_data'),
    path('export_attendance/<int:event_id>/<str:format>/', views.export_attendance, name='export_attendance'),

    # Feedback
    path('view_feedback/<int:event_id>/', views.view_feedback, name='view_feedback'),

    # Post-event report
    path('submit_report/<int:event_id>/', views.submit_report, name='submit_report'),

    # Post updates or changes
    path('post_update/<int:event_id>/', views.post_update, name='post_update'),

    # Live participant dashboard
    path('participant_count/<int:event_id>/', views.participant_count, name='participant_count'),
    #path('promote_coordinator/<int:user_id>/', views.promote_to_coordinator, name='promote_to_coordinator'),
]
