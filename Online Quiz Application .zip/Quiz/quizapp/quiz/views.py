from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Quiz, Question, Choice, Result

def home(request):
    return render(request, 'quiz/home.html')

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'quiz/register.html', {'form': form})

def user_login(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'quiz/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    quizzes = Quiz.objects.all()
    results = Result.objects.filter(user=request.user)
    return render(request, 'quiz/dashboard.html', {'quizzes': quizzes, 'results': results})

@login_required
def start_quiz(request, quiz_id):
    quiz = Quiz.objects.get(pk=quiz_id)
    questions = Question.objects.filter(quiz=quiz)

    if request.method == 'POST':
        score = 0
        for question in questions:
            selected = request.POST.get(str(question.id))
            if selected:
                choice = Choice.objects.get(pk=int(selected))
                if choice.is_correct:
                    score += 1

        percentage = (score / questions.count()) * 100
        Result.objects.create(user=request.user, quiz=quiz, score=percentage)
        return redirect('view_result', quiz_id=quiz.id)

    return render(request, 'quiz/quiz.html', {'quiz': quiz, 'questions': questions})

@login_required
def view_result(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    results = Result.objects.filter(user=request.user, quiz_id=quiz_id).order_by('-date_taken')
    if not results.exists():
        return render(request, 'quiz/result.html', {'quiz': quiz, 'result': None, 'questions': []})

    result = results.first()
    questions = Question.objects.filter(quiz=quiz)
    return render(request, 'quiz/result.html', {
        'quiz': quiz,
        'result': result,
        'questions': questions
    })