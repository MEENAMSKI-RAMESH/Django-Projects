from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from .models import Admintable, Product
from Users.models import UserOrder  


def index(request):
    return render(request, 'Administrator/index.html')

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            admin = Admintable.objects.get(username=username, password=password)
            request.session['aid'] = admin.id
            request.session['admin_logged_in'] = True   
            return redirect('Administrator:Adminhome')
        except Admintable.DoesNotExist:
            return render(request, 'Administrator/Login.html', {'ERR': 'Invalid Credentials'})
    return render(request, 'Administrator/Login.html')

def logout_view(request):
    request.session.flush()
    return redirect('Administrator:index')

def Adminhome_view(request):
    if 'aid' not in request.session:
        return redirect('Administrator:Adminlogin')
    return render(request, 'Administrator/Adminhome.html')


def product_list(request):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')
    products = Product.objects.all()
    return render(request, 'Administrator/product_list.html', {'products': products})

def add_product(request):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        category = request.POST.get('category')
        image = request.FILES.get('image')

        Product.objects.create(
            name=name,
            description=description,
            price=price,
            category=category,
            image=image
        )
        return redirect('Administrator:product_list')

    return render(request, 'Administrator/add_product.html')

def edit_product(request, product_id):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        product.name = request.POST.get('name')
        product.description = request.POST.get('description')
        product.price = request.POST.get('price')
        product.category = request.POST.get('category')

        if request.FILES.get('image'):
            product.image = request.FILES.get('image')

        product.save()
        return redirect('Administrator:product_list')

    return render(request, 'Administrator/edit_product.html', {'product': product})

def delete_product(request, product_id):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    product = get_object_or_404(Product, id=product_id)
    product.delete()
    return redirect('Administrator:product_list')


def order_list(request):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    orders = UserOrder.objects.all()
    return render(request, 'Administrator/order_list.html', {'orders': orders})

def order_detail(request, order_id):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    order = get_object_or_404(UserOrder, id=order_id)
    return render(request, 'Administrator/order_detail.html', {'order': order})

def mark_as_shipped(request, order_id):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    order = get_object_or_404(UserOrder, id=order_id)
    order.status = "Shipped"
    order.save()
    return redirect('Administrator:order_list')

def mark_as_delivered(request, order_id):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    order = get_object_or_404(UserOrder, id=order_id)
    order.status = "Delivered"
    order.save()
    return redirect('Administrator:order_list')


def search_orders(request):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    query = request.GET.get('q')
    orders = UserOrder.objects.filter(Q(customer_name__icontains=query) | Q(id__icontains=query))
    return render(request, 'Administrator/order_list.html', {'orders': orders})

def filter_orders_by_status(request, status):
    if not request.session.get('admin_logged_in'):
        return redirect('Administrator:Adminlogin')

    orders = UserOrder.objects.filter(status=status)
    return render(request, 'Administrator/order_list.html', {'orders': orders})
