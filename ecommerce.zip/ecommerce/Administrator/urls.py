from django.urls import path
from . import views

app_name='Administrator'

urlpatterns = [
    path('Adminlogin/', views.login_view, name='Adminlogin'),
    path('index/',views.index,name='index'),
    path('Adminhome', views.Adminhome_view, name='Adminhome'),
    path('logout/', views.logout_view, name='Adminlogout'),
    path('products/', views.product_list, name='product_list'),
    path('products/add/', views.add_product, name='add_product'),
    path('products/edit/<int:product_id>/', views.edit_product, name='edit_product'),
    path('products/delete/<int:product_id>/', views.delete_product, name='delete_product'),
    path('orders/', views.order_list, name='order_list'),
    path('orders/<int:order_id>/', views.order_detail, name='order_detail'),
    path('orders/<int:order_id>/mark-shipped/', views.mark_as_shipped, name='mark_as_shipped'),
    path('orders/<int:order_id>/mark-delivered/', views.mark_as_delivered, name='mark_as_delivered'),
    path('orders/search/', views.search_orders, name='search_orders'),
    path('orders/filter/<str:status>/', views.filter_orders_by_status, name='filter_orders_by_status'),
]
