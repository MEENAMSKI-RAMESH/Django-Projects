from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404
from .models import Usertable, CartItem, UserOrder
from Administrator.models import Product
from django.db.models import Q


def user_register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if Usertable.objects.filter(email=email).exists():
            return render(request, 'users/register.html', {'error': 'Email already registered.'})

        Usertable.objects.create(name=name, email=email, password=password)
        return redirect('Users:user_login')

    return render(request, 'users/register.html')


def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = Usertable.objects.filter(email=email, password=password).first()

        if user:
            request.session['user_id'] = user.id
            request.session['user_name'] = user.name
            return redirect('Users:user_product_list')
        else:
            return render(request, 'users/login.html', {'error': 'Invalid credentials.'})

    return render(request, 'users/login.html')

def user_logout(request):
    request.session.flush()
    return redirect('Administrator:index')

def product_list(request):
    user_id = request.session.get('user_id')
    products = Product.objects.all()
    orders = UserOrder.objects.filter(user_id=user_id).order_by('-order_date') if user_id else []
    return render(request, 'users/product_list.html', {'products': products, 'orders': orders})

def product_detail(request, product_id):
    user_id = request.session.get('user_id')
    product = get_object_or_404(Product, id=product_id)
    orders = UserOrder.objects.filter(user_id=user_id).order_by('-order_date') if user_id else []
    return render(request, 'users/product_detail.html', {'product': product, 'orders': orders})


def search_products(request):
    query = request.GET.get('q')
    if query:
        products = Product.objects.filter(
            Q(name__icontains=query) | Q(category__icontains=query)
        )
    else:
        products = Product.objects.all()  
    return render(request, 'users/product_list.html', {
        'products': products,
        'search': query
    })


def view_cart(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    cart_items = CartItem.objects.filter(user_id=user_id)

    for item in cart_items:
        item.subtotal = item.product.price * item.quantity

    total = sum(item.subtotal for item in cart_items)

    return render(request, 'users/cart.html', {
        'cart_items': cart_items,
        'total': total
    })


def add_to_cart(request, product_id):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    product = get_object_or_404(Product, id=product_id)
    cart_item, created = CartItem.objects.get_or_create(user_id=user_id, product=product)

    if not created:
        cart_item.quantity += 1
    cart_item.save()

    return redirect('Users:view_cart')


def update_cart(request, item_id):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    item = get_object_or_404(CartItem, id=item_id, user_id=user_id)

    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))
        item.quantity = quantity
        item.save()

    return redirect('Users:view_cart')


def remove_from_cart(request, item_id):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    item = get_object_or_404(CartItem, id=item_id, user_id=user_id)
    item.delete()

    return redirect('Users:view_cart')


def checkout_single_item(request, item_id):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    item = get_object_or_404(CartItem, id=item_id, user_id=user_id)
    item.subtotal = item.product.price * item.quantity

    return render(request, 'users/checkout_single.html', {
        'item': item,
        'total': item.subtotal
    })



def place_single_order(request, item_id):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    cart_item = get_object_or_404(CartItem, id=item_id, user_id=user_id)

    if request.method == 'POST':
        name = request.POST.get('name')
        address = request.POST.get('address')
        payment_mode = request.POST.get('payment_mode')

        if payment_mode == 'Online':
            request.session['payment_data'] = {
                'item_id': item_id,
                'name': name,
                'address': address,
                'payment_mode': payment_mode
            }
            return redirect('Users:demo_payment')

        user = get_object_or_404(Usertable, id=user_id)
        total = cart_item.product.price * cart_item.quantity

        order = UserOrder.objects.create(
            user=user,
            customer_name=name,
            customer_address=address,
            payment_mode=payment_mode,
            total_amount=total,
            status='Pending'
        )
        order.products.add(cart_item.product)
        order.save()
        cart_item.delete()

        return redirect('Users:order_history')

    return redirect('Users:view_cart')

def demo_payment(request):
    return render(request, 'users/demo_payment.html')


def confirm_payment(request):
    user_id = request.session.get('user_id')
    payment_data = request.session.get('payment_data')

    if not user_id or not payment_data:
        return redirect('Users:view_cart')

    item_id = payment_data['item_id']
    cart_item = get_object_or_404(CartItem, id=item_id, user_id=user_id)
    user = get_object_or_404(Usertable, id=user_id)

    total = cart_item.product.price * cart_item.quantity

    order = UserOrder.objects.create(
        user=user,
        customer_name=payment_data['name'],
        customer_address=payment_data['address'],
        payment_mode='Online',
        total_amount=total,
        status='Pending'
    )
    order.products.add(cart_item.product)
    order.save()
    cart_item.delete()
    del request.session['payment_data']

    return redirect('Users:order_history')

def order_history(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Users:user_login')

    orders = UserOrder.objects.filter(user_id=user_id).order_by('-order_date')
    return render(request, 'users/order_history.html', {'orders': orders})

def track_order_status(request, order_id):
    order = get_object_or_404(UserOrder, id=order_id)
    return render(request, 'users/order_detail.html', {'order': order})

def delete_order(request, order_id):
    user_id = request.session.get('user_id')
    order = get_object_or_404(UserOrder, id=order_id, user__id=user_id)

    if request.method == 'POST':
        order.delete()

    return redirect('Users:order_history')
