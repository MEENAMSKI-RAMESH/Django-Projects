
# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import CustomUser, Group, Expense, Settlement
from expenseapp import models


# ===========================
#  USER AUTHENTICATION
# ===========================
from django.shortcuts import render

def index(request):
    return render(request, "expenseapp/index.html")

def register(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect("register")
        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, "Email already exists")
            return redirect("register")

        hashed_pw = make_password(password)
        CustomUser.objects.create(username=username, email=email, password=hashed_pw)
        messages.success(request, "Registration successful. Please log in.")
        return redirect("login")

    return render(request, "expenseapp/register.html")


def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            user = CustomUser.objects.get(username=username)
        except CustomUser.DoesNotExist:
            messages.error(request, "Invalid username or password")
            return redirect("login")

        if check_password(password, user.password):
            request.session["user_id"] = user.id
            request.session["username"] = user.username
            return redirect("dashboard")
        else:
            messages.error(request, "Invalid username or password")
            return redirect("login")

    return render(request, "expenseapp/login.html")


def logout_view(request):
    request.session.flush()
    return redirect("index")


# ===========================
#  DASHBOARD
# ===========================

def dashboard(request):
    if "user_id" not in request.session:
        return redirect("login")

    user_id = request.session["user_id"]

    # Show all groups where the user is a member
    groups = Group.objects.filter(members__id=user_id)

    return render(request, "expenseapp/dashboard.html", {"groups": groups})



# ===========================
#  GROUP MANAGEMENT
# ===========================

def add_group(request):
    if "user_id" not in request.session:
        return redirect("login")

    if request.method == "POST":
        name = request.POST.get("name")
        description = request.POST.get("description")
        creator = CustomUser.objects.get(id=request.session["user_id"])

        group = Group.objects.create(name=name, description=description, created_by=creator)
        group.members.add(creator)  # add creator as member
        messages.success(request, "Group created successfully")
        return redirect("view_groups")

    return render(request, "expenseapp/add_group.html")


def view_groups(request):
    if "user_id" not in request.session:
        return redirect("login")

    groups = Group.objects.filter(members__id=request.session["user_id"])
    return render(request, "expenseapp/view_groups.html", {"groups": groups})


def add_members(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    group = get_object_or_404(Group, id=group_id)
    users = CustomUser.objects.exclude(id__in=group.members.all())  # exclude already added members

    if request.method == "POST":
        username = request.POST.get("username")
        try:
            member = CustomUser.objects.get(username=username)
            group.members.add(member)
            messages.success(request, f"{member.username} added to the group")
        except CustomUser.DoesNotExist:
            messages.error(request, "User not found")

        return redirect("add_members", group_id=group.id)

    return render(request, "expenseapp/add_members.html", {"group": group, "users": users})


def view_members(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    group = get_object_or_404(Group, id=group_id)
    members = group.members.all()
    return render(request, "expenseapp/view_members.html", {"group": group, "members": members})


# ===========================
#  EXPENSES
# ===========================

from django.http import JsonResponse

from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from .models import Group, Expense, CustomUser

def add_expense(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    group = get_object_or_404(Group, id=group_id)
    payer = get_object_or_404(CustomUser, id=request.session["user_id"])

    if request.method == "POST":
        amount = request.POST.get("amount")
        description = request.POST.get("description")

        expense = Expense.objects.create(
            group=group,
            payer=payer,
            amount=amount,
            description=description
        )

        # If request is AJAX, return JSON
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({
                "success": True,
                "expense_id": expense.id,
                "description": expense.description,
                "amount": str(expense.amount),
                "payer": payer.username,
                "date": expense.date.strftime("%b %d, %Y %H:%M")
            })

        messages.success(request, "Expense added successfully")
        return redirect("view_expenses", group_id=group.id)

    members = group.members.all()
    return render(request, "expenseapp/add_expense.html", {"group": group, "members": members})

def view_expenses(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    group = get_object_or_404(Group, id=group_id)
    expenses = group.expenses.all()
    return render(request, "expenseapp/view_expenses.html", {"group": group, "expenses": expenses})

from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Expense, CustomUser

from django.http import JsonResponse

def edit_expense(request, expense_id):
    if "user_id" not in request.session:
        return redirect("login")

    expense = get_object_or_404(Expense, id=expense_id)

    # Only payer can edit
    if expense.payer.id != request.session["user_id"]:
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"success": False, "error": "You are not allowed to edit this expense."})
        messages.error(request, "You are not allowed to edit this expense.")
        return redirect("view_expenses", group_id=expense.group.id)

    if request.method == "POST":
        expense.amount = request.POST.get("amount")
        expense.description = request.POST.get("description")
        expense.save()

        # AJAX request → return JSON
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({
                "success": True,
                "expense_id": expense.id,
                "description": expense.description,
                "amount": str(expense.amount),
                "payer": expense.payer.username,
                "date": expense.date.strftime("%Y-%m-%d %H:%M")
            })

        # Normal request → redirect
        messages.success(request, "Expense updated successfully")
        return redirect("view_expenses", group_id=expense.group.id)

    return render(request, "expenseapp/edit_expense.html", {"expense": expense})


def delete_expense(request, expense_id):
    if "user_id" not in request.session:
        return redirect("login")

    expense = get_object_or_404(Expense, id=expense_id)

    # Only payer can delete
    if expense.payer.id != request.session["user_id"]:
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"success": False, "error": "You are not allowed to delete this expense."})
        messages.error(request, "You are not allowed to delete this expense.")
        return redirect("view_expenses", group_id=expense.group.id)

    group_id = expense.group.id
    expense.delete()

    # Return JSON response if AJAX request
    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        return JsonResponse({"success": True, "expense_id": expense_id})

    messages.success(request, "Expense deleted successfully")
    return redirect("view_expenses", group_id=group_id)

# ===========================
#  BALANCES & SETTLEMENTS
# ===========================
from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Sum
from django.contrib import messages
from decimal import Decimal
from .models import Group, Expense, CustomUser, Settlement

# ===========================
#  BALANCES
# ===========================
from django.http import JsonResponse
from decimal import Decimal
from django.db.models import Sum

def show_balances(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    group = get_object_or_404(Group, id=group_id)
    members = group.members.all()

    total_expense = Expense.objects.filter(group=group).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
    num_members = members.count()
    share_per_person = (total_expense / Decimal(num_members)) if num_members > 0 else Decimal('0.00')

    results = []
    for member in members:
        paid_amount = Expense.objects.filter(group=group, payer=member).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        settlements_received = Settlement.objects.filter(group=group, receiver=member).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        settlements_made = Settlement.objects.filter(group=group, payer=member).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')

        balance = paid_amount - share_per_person - settlements_received + settlements_made
        balance = balance.quantize(Decimal('0.01'))

        results.append({
            "member": member.username,
            "balance": float(balance),        # JSON friendly
            "abs_balance": float(abs(balance))
        })

    # ✅ Return JSON if AJAX request
    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        return JsonResponse({"results": results})

    # Normal render
    return render(request, "expenseapp/balances.html", {"group": group, "results": results})


# ===========================
#  SETTLE BALANCE
# ===========================
from decimal import Decimal, ROUND_HALF_UP
from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Sum
from django.contrib import messages
from .models import Group, Expense, Settlement, CustomUser

from django.http import JsonResponse
from decimal import Decimal, ROUND_HALF_UP
from django.db.models import Sum

def settle_balance(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    payer = get_object_or_404(CustomUser, id=request.session["user_id"])
    group = get_object_or_404(Group, id=group_id)
    members = group.members.exclude(id=payer.id)

    if request.method == "POST":
        receiver_id = request.POST.get("receiver")
        amount = Decimal(request.POST.get("amount") or 0).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        receiver = get_object_or_404(CustomUser, id=receiver_id)

        # ---- Calculate current balance ----
        total_expense = Expense.objects.filter(group=group).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        num_members = group.members.count()
        share_per_person = (total_expense / Decimal(num_members)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) if num_members > 0 else Decimal('0.00')

        paid_amount = Expense.objects.filter(group=group, payer=payer).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        settlements_received = Settlement.objects.filter(group=group, receiver=payer).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        settlements_made = Settlement.objects.filter(group=group, payer=payer).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')

        current_balance = (paid_amount - share_per_person - settlements_received + settlements_made).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )

        # ---- Validation ----
        error_msg = None
        if current_balance < 0:  # Owes
            max_payable = abs(current_balance)
            if amount > max_payable:
                error_msg = f"Cannot pay more than your owed amount ({max_payable:.2f})"
        elif current_balance > 0:  # Should receive
            max_payable = current_balance
            if amount > max_payable:
                error_msg = f"Cannot receive more than your balance ({max_payable:.2f})"

        if error_msg:
            if request.headers.get("x-requested-with") == "XMLHttpRequest":
                return JsonResponse({"success": False, "error": error_msg})
            messages.error(request, error_msg)
            return redirect("settle_balance", group_id=group.id)

        # ---- Record Settlement ----
        settlement = Settlement.objects.create(group=group, payer=payer, receiver=receiver, amount=amount)

        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({
                "success": True,
                "settlement_id": settlement.id,
                "payer": payer.username,
                "receiver": receiver.username,
                "amount": str(settlement.amount),
            })

        messages.success(request, "Settlement recorded successfully")
        return redirect("settlement_history", group_id=group.id)

    return render(request, "expenseapp/settle.html", {
        "group": group,
        "members": members,
        "payer": payer
    })


def settlement_history(request, group_id):
    if "user_id" not in request.session:
        return redirect("login")

    group = get_object_or_404(Group, id=group_id)
    settlements = group.settlements.all()
    return render(request, "expenseapp/settlement_history.html", {"group": group, "settlements": settlements})
