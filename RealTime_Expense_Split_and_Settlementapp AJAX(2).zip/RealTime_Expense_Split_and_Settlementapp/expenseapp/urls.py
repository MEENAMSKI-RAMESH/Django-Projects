from . import views   

from django.urls import path

urlpatterns = [
    path('', views.index, name='index'),
    path('login', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('add_group/', views.add_group, name='add_group'),
    path('view_groups/', views.view_groups, name='view_groups'),
    path('add_members/<int:group_id>/', views.add_members, name='add_members'),
    path('view_members/<int:group_id>/', views.view_members, name='view_members'),
    path('add_expense/<int:group_id>/', views.add_expense, name='add_expense'),
    path('view_expenses/<int:group_id>/', views.view_expenses, name='view_expenses'),
    path('expense/edit/<int:expense_id>/', views.edit_expense, name='edit_expense'),
    path('expense/delete/<int:expense_id>/', views.delete_expense, name='delete_expense'),
    path('balances/<int:group_id>/', views.show_balances, name='show_balances'),
    path('settle/<int:group_id>/', views.settle_balance, name='settle_balance'),
    path('settlement_history/<int:group_id>/', views.settlement_history, name='settlement_history'),
]
