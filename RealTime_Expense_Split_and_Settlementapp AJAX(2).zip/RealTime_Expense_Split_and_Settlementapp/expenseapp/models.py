from django.db import models

# Create your models here.


class CustomUser(models.Model):
    username = models.CharField(max_length=50, unique=True)   
    email = models.EmailField(unique=True)                    
    password = models.CharField(max_length=128)               
    date_joined = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username


class Group(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="created_groups")
    members = models.ManyToManyField(CustomUser, related_name="member_groups", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} (by {self.created_by.username})"


class Expense(models.Model):
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name="expenses")
    payer = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="paid_expenses")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.CharField(max_length=255)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.description} - {self.amount} ({self.group.name})"


class Settlement(models.Model):
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name="settlements")
    payer = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="settlements_made")
    receiver = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="settlements_received")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.payer.username} → {self.receiver.username}: {self.amount}"
