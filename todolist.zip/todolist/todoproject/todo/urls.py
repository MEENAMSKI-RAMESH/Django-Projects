from django.urls import path
from . import views

urlpatterns = [
    path('', views.task_list_view, name='task_list'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('create/', views.create_task_view, name='create_task'),
    path('toggle/<int:task_id>/', views.toggle_status, name='toggle_status'),
]
