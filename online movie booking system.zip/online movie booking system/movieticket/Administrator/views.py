from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import AdminTable, Movie, Show, SeatLayout, Booking
from django.db.models import Sum, Count
from django.utils.dateparse import parse_date, parse_time


def index(request):
    return render(request, 'Administrator/index.html')


def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            admin = AdminTable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin.id
            return redirect('Administrator:admin_dashboard')
        except AdminTable.DoesNotExist:
            messages.error(request, 'Invalid login credentials.')
            return redirect('Administrator:admin_login')
    return render(request, 'Administrator/admin_login.html')


def admin_dashboard(request):
    if 'admin_id' not in request.session:
        return redirect('Administrator:admin_login')
    total_bookings = Booking.objects.count()
    total_revenue = Booking.objects.filter(status='Confirmed').aggregate(Sum('total_price'))['total_price__sum'] or 0
    top_movies = Movie.objects.annotate(bookings=Count('show__booking')).order_by('-bookings')[:5]
    return render(request, 'Administrator/dashboard.html', {
        'total_bookings': total_bookings,
        'total_revenue': total_revenue,
        'top_movies': top_movies,
    })


def movie_list(request):
    movies = Movie.objects.all()
    return render(request, 'Administrator/movie_list.html', {'movies': movies})


def add_movie(request):
    if request.method == 'POST':
        Movie.objects.create(
            title=request.POST['title'],
            poster_image=request.FILES['poster_image'],
            description=request.POST['description'],
            genre=request.POST['genre'],
            language=request.POST['language'],
            duration=request.POST['duration'],
            release_date=request.POST['release_date']
        )
        messages.success(request, 'Movie added successfully.')
        return redirect('Administrator:movie_list')
    return render(request, 'Administrator/add_movie.html')


def edit_movie(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    if request.method == 'POST':
        movie.title = request.POST['title']
        if 'poster_image' in request.FILES:
            movie.poster_image = request.FILES['poster_image']
        movie.description = request.POST['description']
        movie.genre = request.POST['genre']
        movie.language = request.POST['language']
        movie.duration = request.POST['duration']
        movie.release_date = request.POST['release_date']
        movie.save()
        messages.success(request, 'Movie updated.')
        return redirect('Administrator:movie_list')
    return render(request, 'Administrator/edit_movie.html', {'movie': movie})


def delete_movie(request, movie_id):
    Movie.objects.filter(id=movie_id).delete()
    messages.success(request, 'Movie deleted.')
    return redirect('Administrator:movie_list')


def show_list(request):
    movies = Movie.objects.annotate(total_shows=Count('show')).filter(total_shows__gt=0)
    return render(request, 'Administrator/show_list.html', {'movies': movies})

def add_show(request):
    movies = Movie.objects.all()
    if request.method == 'POST':
        try:
            Show.objects.create(
                movie_id=request.POST['movie_id'],
                date=request.POST['date'],
                start_time=request.POST['start_time'],
                end_time=request.POST['end_time'],
                theater_name=request.POST['theater_name'],
                screen_number=request.POST['screen_number'],
                language=request.POST['language'],
                normal_price=request.POST.get('normal_price') or 0,
                premium_price=request.POST.get('premium_price') or 0
            )
            messages.success(request, 'Show added successfully.')
            return redirect('Administrator:show_list')
        except Exception as e:
            messages.error(request, f"Error adding show: {e}")
    return render(request, 'Administrator/add_show.html', {'movies': movies})


def edit_show(request, show_id):
    show = get_object_or_404(Show, id=show_id)
    movies = Movie.objects.all()

    if request.method == 'POST':
        try:
            show.movie_id = request.POST.get('movie_id')
            show.date = parse_date(request.POST.get('date', ''))
            show.start_time = parse_time(request.POST.get('start_time', ''))
            show.end_time = parse_time(request.POST.get('end_time', ''))
            show.theater_name = request.POST.get('theater_name', '').strip()
            show.screen_number = request.POST.get('screen_number', '').strip()
            show.language = request.POST.get('language', '').strip()
            show.normal_price = request.POST.get('normal_price') or 0
            show.premium_price = request.POST.get('premium_price') or 0

            show.save()
            messages.success(request, 'Show updated successfully.')
            return redirect('Administrator:show_list')
        except Exception as e:
            messages.error(request, f'Error updating show: {e}')

    return render(request, 'Administrator/edit_show.html', {'show': show, 'movies': movies})


def delete_show(request, show_id):
    Show.objects.filter(id=show_id).delete()
    messages.success(request, 'Show deleted.')
    return redirect('Administrator:show_list')


def configure_seat_layout(request, screen_id):
    show = get_object_or_404(Show, id=screen_id)
    if request.method == 'POST':
        rows = int(request.POST['rows'])
        cols = int(request.POST['cols'])
        for r in range(1, rows + 1):
            for c in range(1, cols + 1):
                SeatLayout.objects.create(show=show, row=chr(64 + r), column=c)
        messages.success(request, 'Seat layout configured.')
        return redirect('Administrator:show_list')
    return render(request, 'Administrator/configure_seat_layout.html', {'show': show})


def mark_blocked_or_premium(request, seat_id):
    seat = get_object_or_404(SeatLayout, id=seat_id)
    if request.method == 'POST':
        seat.is_blocked = 'is_blocked' in request.POST
        seat.is_premium = 'is_premium' in request.POST
        seat.save()
        messages.success(request, 'Seat updated.')
        return redirect('Administrator:show_list')
    return render(request, 'Administrator/mark_seat.html', {'seat': seat})


def manage_bookings(request):
    bookings = Booking.objects.all().order_by('-booking_time')
    return render(request, 'Administrator/manage_bookings.html', {'bookings': bookings})




def view_bookings(request):
    bookings = Booking.objects.all()
    return render(request, 'Administrator/booking_list.html', {'bookings': bookings})


def booking_details(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    return render(request, 'Administrator/booking_details.html', {'booking': booking})

def update_booking_status(request, booking_id, action):
    booking = get_object_or_404(Booking, id=booking_id)
    if action == 'cancel':
        booking.status = 'Cancelled'
    elif action == 'confirm':
        booking.status = 'Confirmed'
    booking.save()
    messages.success(request, f"Booking marked as {booking.status}.")
    return redirect('Administrator:view_bookings')


def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    booking.status = 'Cancelled'
    booking.save()
    messages.success(request, 'Booking cancelled.')
    return redirect('Administrator:view_bookings')


def analytics_dashboard(request):
    total_bookings = Booking.objects.count()
    total_revenue = Booking.objects.filter(status='Confirmed').aggregate(Sum('total_price'))['total_price__sum'] or 0
    top_movies = Movie.objects.annotate(bookings=Count('show__booking')).order_by('-bookings')[:5]
    return render(request, 'Administrator/analytics_dashboard.html', {
        'total_bookings': total_bookings,
        'total_revenue': total_revenue,
        'top_movies': top_movies,
    })


def view_shows_by_movie(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    shows = Show.objects.filter(movie=movie).order_by('date', 'start_time')
    return render(request, 'Administrator/view_shows_by_movie.html', {
        'movie': movie,
        'shows': shows
    })