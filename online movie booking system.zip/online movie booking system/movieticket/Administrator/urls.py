from django.urls import path
from . import views

app_name = 'Administrator'

urlpatterns = [
    path('login/', views.admin_login, name='admin_login'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('movies/add/', views.add_movie, name='add_movie'),
    path('movies/edit/<int:movie_id>/', views.edit_movie, name='edit_movie'),
    path('movies/delete/<int:movie_id>/', views.delete_movie, name='delete_movie'),
    path('movies/', views.movie_list, name='movie_list'),
    path('shows/add/', views.add_show, name='add_show'),
    path('shows/edit/<int:show_id>/', views.edit_show, name='edit_show'),
    path('shows/delete/<int:show_id>/', views.delete_show, name='delete_show'),
    path('shows/', views.show_list, name='show_list'),
    path('shows/movie/<int:movie_id>/', views.view_shows_by_movie, name='view_shows_by_movie'),
    path('seats/configure/<int:screen_id>/', views.configure_seat_layout, name='configure_seat_layout'),
    path('seats/block_premium/<int:seat_id>/', views.mark_blocked_or_premium, name='mark_blocked_or_premium'),
    path('bookings/', views.view_bookings, name='view_bookings'),
    path('bookings/<int:booking_id>/', views.booking_details, name='booking_details'),
    path('bookings/cancel/<int:booking_id>/', views.cancel_booking, name='cancel_booking'),
    path('bookings/manage/', views.manage_bookings, name='manage_bookings'),
    path('bookings/update/<int:booking_id>/<str:action>/', views.update_booking_status, name='update_booking_status'),
    path('analytics/', views.analytics_dashboard, name='analytics_dashboard'),
]
