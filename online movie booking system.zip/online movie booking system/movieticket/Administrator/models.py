from django.utils import timezone
import uuid
from django.db import models
from django.core.files.base import ContentFile
from io import BytesIO

class AdminTable(models.Model):
    username = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=100)  

    def __str__(self):
        return self.username

class Movie(models.Model):
    title = models.CharField(max_length=200)
    poster_image = models.ImageField(upload_to='movie_posters/')
    description = models.TextField()
    genre = models.CharField(max_length=100)
    language = models.CharField(max_length=50)
    duration = models.CharField(max_length=20) 
    release_date = models.DateField()

    def __str__(self):
        return self.title

class Show(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    theater_name = models.CharField(max_length=100)
    screen_number = models.CharField(max_length=10)
    language = models.CharField(max_length=50)  
    normal_price = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    premium_price = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.movie.title} - {self.date} {self.start_time}"


class SeatLayout(models.Model):
    show = models.ForeignKey(Show, on_delete=models.CASCADE)
    row = models.CharField(max_length=5)
    column = models.IntegerField()
    is_blocked = models.BooleanField(default=False)
    is_premium = models.BooleanField(default=False)
    is_booked = models.BooleanField(default=False)

    def __str__(self):
        return f"Seat {self.row}{self.column} - Show {self.show.id}"

class Booking(models.Model):
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Confirmed', 'Confirmed'),
        ('Cancelled', 'Cancelled')
    )

    reference_number = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    customer_name = models.CharField(max_length=100)
    customer_email = models.EmailField()
    show = models.ForeignKey('Show', on_delete=models.CASCADE)
    seats = models.ManyToManyField('SeatLayout')
    booking_time = models.DateTimeField(default=timezone.now)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending') 
    

    def __str__(self):
        return f"{self.reference_number} - {self.customer_name}"
    