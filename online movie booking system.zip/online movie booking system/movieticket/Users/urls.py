from django.urls import path
from . import views

app_name = 'Users'

urlpatterns = [
    path('register/', views.user_register, name='user_register'),
    path('login/', views.user_login, name='user_login'),
    path('logout/', views.user_logout, name='user_logout'),
    path('dashboard/', views.user_dashboard, name='user_dashboard'),
    path('movies/', views.movie_list, name='movie_list'),
    path('movies/<int:movie_id>/', views.movie_detail, name='movie_detail'),
    path('shows/<int:show_id>/seats/', views.select_seats, name='select_seats'),
    path('shows/<int:show_id>/book/', views.book_tickets, name='book_tickets'),
    path('booking/confirmation/<int:booking_id>/', views.booking_confirmation, name='booking_confirmation'),
    path('bookings/history/', views.booking_history, name='booking_history'),
    path('bookings/cancel/<int:booking_id>/', views.cancel_booking, name='cancel_booking'),
    path('ticket/<int:booking_id>/view/', views.view_ticket, name='view_ticket'),
    path('ticket/<int:booking_id>/download/', views.download_ticket, name='download_ticket'),


]
