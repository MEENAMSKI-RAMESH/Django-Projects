from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import UserProfile
from Administrator.models import Movie, Show, SeatLayout, Booking
from django.utils import timezone
from django.db.models import Count
import uuid


def user_register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        password = make_password(request.POST['password'])

        if UserProfile.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered.')
            return redirect('Users:user_register')

        UserProfile.objects.create(name=name, email=email, phone=phone, password=password)
        messages.success(request, 'Registration successful. Please login.')
        return redirect('Users:user_login')

    return render(request, 'Users/register.html')


def user_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        try:
            user = UserProfile.objects.get(email=email)
            if check_password(password, user.password):
                request.session['user_id'] = user.id
                request.session['user_name'] = user.name
                return redirect('Users:user_dashboard')
            else:
                messages.error(request, 'Invalid password.')
        except UserProfile.DoesNotExist:
            messages.error(request, 'User not found.')

        return redirect('Users:user_login')

    return render(request, 'Users/login.html')


def user_logout(request):
    request.session.flush()
    return redirect('Users:user_login')


def user_dashboard(request):
    if 'user_id' not in request.session:
        return redirect('Users:user_login')
    return render(request, 'Users/dashboard.html', {'user_name': request.session.get('user_name')})


def movie_list(request):
    genre = request.GET.get('genre')
    language = request.GET.get('language')
    date = request.GET.get('date')

    movies = Movie.objects.annotate(show_count=Count('show')).filter(show_count__gt=0)

    if genre:
        movies = movies.filter(genre__icontains=genre)
    if language:
        movies = movies.filter(language__icontains=language)
    if date:
        movies = movies.filter(show__date=date).distinct()

    return render(request, 'Users/movie_list.html', {
        'movies': movies,
        'genre': genre,
        'language': language,
        'date': date,
    })


def movie_detail(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    shows = Show.objects.filter(movie=movie).order_by('date', 'start_time')
    return render(request, 'Users/movie_detail.html', {'movie': movie, 'shows': shows})


def select_seats(request, show_id):
    if 'user_id' not in request.session:
        return redirect('Users:user_login')

    show = get_object_or_404(Show, id=show_id)
    seats = SeatLayout.objects.filter(show=show).order_by('row', 'column')

    return render(request, 'Users/select_seats.html', {
        'show': show,
        'seats': seats
    })


def book_tickets(request, show_id):
    if 'user_id' not in request.session:
        return redirect('Users:user_login')

    show = get_object_or_404(Show, id=show_id)
    user = get_object_or_404(UserProfile, id=request.session['user_id'])

    if request.method == 'POST':
        selected_seat_ids = request.POST.getlist('seats')
        seats = SeatLayout.objects.filter(id__in=selected_seat_ids, show=show, is_booked=False ,is_blocked=False)

        if not seats:
            messages.error(request, 'Selected seats are not available.')
            return redirect('Users:select_seats', show_id=show_id)

        total_price = 0
        for seat in seats:
            if seat.is_premium:
                total_price += show.premium_price
            else:
                total_price += show.normal_price

        booking = Booking.objects.create(
            reference_number=uuid.uuid4(),
            customer_name=user.name,
            customer_email=user.email,
            show=show,
            booking_time=timezone.now(),
            total_price=total_price,
            status='Pending'
        )

        booking.seats.set(seats)
        booking.save()

        for seat in seats:
            seat.is_booked = True
            seat.save()

        return redirect('Users:booking_confirmation', booking_id=booking.id)

    return redirect('Users:select_seats', show_id=show_id)


def booking_confirmation(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    return render(request, 'Users/booking_confirmation.html', {'booking': booking})


def booking_history(request):
    if 'user_id' not in request.session:
        return redirect('Users:user_login')

    user = get_object_or_404(UserProfile, id=request.session['user_id'])
    bookings = Booking.objects.filter(customer_email=user.email).order_by('-booking_time')
    return render(request, 'Users/booking_history.html', {'bookings': bookings})


def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)

    if booking.show.date > timezone.now().date() or (
        booking.show.date == timezone.now().date() and booking.show.start_time > timezone.now().time()
    ):
        booking.status = 'Cancelled'
        booking.save()

        for seat in booking.seats.all():
            seat.is_booked = False
            seat.save()

        messages.success(request, 'Booking cancelled successfully.')
    else:
        messages.error(request, 'Booking cannot be cancelled after showtime.')

    return redirect('Users:booking_history')




def view_ticket(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)

    if booking.status != 'Confirmed':
        messages.error(request, "Ticket is not confirmed yet.")
        return redirect('Users:booking_history')

    return render(request, 'Users/booking_ticket.html', {
        'booking': booking
    })


def download_ticket(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)

    if booking.status != "Confirmed":
        return render(request, "Users/booking_history.html", {"message": "Ticket is not confirmed yet."})

    return render(request, "Users/booking_ticket.html", {"booking": booking})