from datetime import timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.utils import timezone
from .models import Usertable
from lib.models import Book, BorrowRequest

def index(request):
    return render(request, 'lib/index.html')


def register_view(request):
    if request.method == "POST":
        Usertable.objects.create(
            full_name=request.POST['fullname'],
            username=request.POST['username'],
            password=request.POST['password'],
            email=request.POST['email']
        )
        return redirect('Users:login')
    return render(request, 'Users/register.html')

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        try:
            user = Usertable.objects.get(username=username, password=password)
            request.session['uid'] = user.id
            return redirect('Users:userhome')
        except Usertable.DoesNotExist:
            return render(request, 'Users/login.html', {'ERR': 'Invalid Credentials'})
    return render(request, 'Users/login.html')

def logout_view(request):
    request.session.flush()
    return redirect('Users:index')



def userhome_view(request):
    if 'uid' not in request.session:
        return redirect('Users:login')
    
    query = request.GET.get('q')
    if query:
        books = Book.objects.filter(available=True).filter(
            Q(title__icontains=query) |
            Q(author__name__icontains=query) |
            Q(category__name__icontains=query)
        )
    else:
        books = Book.objects.filter(available=True)
    
    return render(request, 'Users/userhome.html', {'books': books})


def borrow_book_view(request, book_id):
    if 'uid' not in request.session:
        return redirect('Users:login')

    user = get_object_or_404(Usertable, id=request.session['uid'])
    book = get_object_or_404(Book, id=book_id)

    if request.method == 'POST':
        if BorrowRequest.objects.filter(user=user, book=book, is_returned=False).exists():
            return render(request, 'Users/borrow_status.html', {'requests': BorrowRequest.objects.filter(user=user), 'message': 'You have already borrowed this book.'})

        BorrowRequest.objects.create(
            user=user,
            book=book,
            request_date=timezone.now().date(),
            return_date=timezone.now().date() + timedelta(days=15),
            status='Pending',
            is_returned=False
        )
        return redirect('Users:borrow_status')

    return render(request, 'Users/borrow_confirm.html', {'book': book})


def borrow_status_view(request):
    if 'uid' not in request.session:
        return redirect('Users:login')

    user = get_object_or_404(Usertable, id=request.session['uid'])
    requests = BorrowRequest.objects.filter(user=user)

    return render(request, 'Users/borrow_status.html', {'requests': requests})
