from datetime import timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import Admintable, Book, BorrowRequest, Category, Author
from Users.models import Usertable
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from django.db.models import Q

def index(request):
    return render(request, 'lib/index.html')

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            admin = Admintable.objects.get(username=username, password=password)
            request.session['aid'] = admin.id
            return redirect('lib:libhome')
        except Admintable.DoesNotExist:
            return render(request, 'lib/Login.html', {'ERR': 'Invalid Credentials'})
    return render(request, 'lib/Login.html')

def logout_view(request):
    request.session.flush()
    return redirect('lib:index')

def libhome_view(request):
    if 'aid' not in request.session:
        return redirect('lib:login')
    return render(request, 'lib/libhome.html')


def addbook_view(request):
    if 'aid' not in request.session:
        return redirect('lib:login')
    if request.method == "POST":
        category = get_object_or_404(Category, id=request.POST['category'])
        author = get_object_or_404(Author, id=request.POST['author'])
        Book.objects.create(
            title=request.POST['title'],
            author=author,
            category=category,
            description=request.POST['description'],
            available=True
        )
        return redirect('lib:book_list')
    categories = Category.objects.all()
    authors = Author.objects.all()
    return render(request, 'lib/addbooks.html', {'categories': categories, 'authors': authors})

def edit_book_view(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == "POST":
        book.title = request.POST['title']
        book.author = get_object_or_404(Author, id=request.POST['author'])
        book.category = get_object_or_404(Category, id=request.POST['category'])
        book.description = request.POST['description']
        book.available = 'available' in request.POST
        book.save()
        return redirect('lib:book_list')
    categories = Category.objects.all()
    authors = Author.objects.all()
    return render(request, 'lib/editbook.html', {'book': book, 'categories': categories, 'authors': authors})

def delete_book_view(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    book.delete()
    return redirect('lib:book_list')

def add_category_view(request):
    if request.method == "POST":
        Category.objects.create(name=request.POST['name'])
        return redirect('lib:book_list')
    return render(request, 'lib/add_category.html')

def add_author_view(request):
    if request.method == "POST":
        Author.objects.create(name=request.POST['name'])
        return redirect('lib:book_list')
    return render(request, 'lib/add_author.html')

def book_list_view(request):
    query = request.GET.get('q')
    if query:
        books = Book.objects.filter(
            Q(title__icontains=query) |
            Q(category__name__icontains=query) |
            Q(author__name__icontains=query)
        )
    else:
        books = Book.objects.all()
    return render(request, 'lib/booklist.html', {'books': books})


def borrow_requests_view(request):
    requests = BorrowRequest.objects.all()
    return render(request, 'lib/requests.html', {'requests': requests})

def approve_request_view(request, request_id):
    req = get_object_or_404(BorrowRequest, id=request_id)
    req.status = 'Approved'
    req.return_date = timezone.now().date() + timedelta(days=15)
    req.book.available = False
    req.book.save()
    req.save()
    return redirect('lib:borrow_requests')

def decline_request_view(request, request_id):
    req = get_object_or_404(BorrowRequest, id=request_id)
    req.status = 'Declined'
    req.save()
    return redirect('lib:borrow_requests')

def mark_returned_view(request, request_id):
    req = get_object_or_404(BorrowRequest, id=request_id)
    req.is_returned = True
    req.book.available = True
    req.book.save()
    req.save()
    return redirect('lib:borrow_requests')

def edit_return_date(request, request_id):
    req = get_object_or_404(BorrowRequest, id=request_id)
    if request.method == "POST":
        return_date = request.POST.get("return_date")
        if return_date:
            req.return_date = return_date
            req.save()
            return redirect('lib:borrow_requests')
    return render(request, 'lib/edit_return_date.html', {'req': req})


def user_list_view(request):
    users = Usertable.objects.all()
    return render(request, 'lib/userlist.html', {'users': users})

def user_borrow_history(request, user_id):
    user = get_object_or_404(Usertable, id=user_id)
    history = BorrowRequest.objects.filter(user=user)
    return render(request, 'lib/borrowhistory.html', {'user': user, 'history': history})


def dashboard_view(request):
    active_borrows = BorrowRequest.objects.filter(status='Approved', is_returned=False).count()
    overdue = BorrowRequest.objects.filter(
        status='Approved', is_returned=False, return_date__lt=timezone.now().date()
    ).count()
    pending = BorrowRequest.objects.filter(status='Pending').count()
    total_books = Book.objects.count()
    return render(request, 'lib/dashboard.html', {
        'active': active_borrows,
        'overdue': overdue,
        'pending': pending,
        'total': total_books
    })


def due_reminders_view(request):
    if 'aid' not in request.session:
        return redirect('lib:login')

    today = timezone.now().date()
    due_soon = BorrowRequest.objects.filter(
        is_returned=False,
        status='Approved',
        return_date__gte=today,
        return_date__lte=today + timedelta(days=3)
    ).order_by('return_date')

    return render(request, 'lib/due_reminders.html', {'borrows': due_soon})


def send_reminder_now(request, request_id):
    if 'aid' not in request.session:
        return redirect('lib:login')

    borrow = get_object_or_404(BorrowRequest, id=request_id)
    subject = f"Reminder: Return '{borrow.book.title}' by {borrow.return_date}"
    message = f"""
    Hi {borrow.user.full_name},

    This is a reminder to return the book '{borrow.book.title}' by {borrow.return_date}.
    
    Please return it on time to avoid penalties.

    Regards,
    Library Management
    """
    send_mail(subject, message, None, [borrow.user.email])
    messages.success(request, f"Reminder sent to {borrow.user.email} ")
    return redirect('lib:due_reminders')
