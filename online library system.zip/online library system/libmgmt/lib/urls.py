from django.urls import path
from . import views

app_name = 'lib'

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('libhome/', views.libhome_view, name='libhome'),
    path('index/',views.index,name='index'),
    path('addbooks/', views.addbook_view, name='addbooks'),
    path('books/', views.book_list_view, name='book_list'),
    path('editbook/<int:book_id>/', views.edit_book_view, name='edit_book'),
    path('deletebook/<int:book_id>/', views.delete_book_view, name='delete_book'),
    path('add-category/', views.add_category_view, name='add_category'),
    path('add-author/', views.add_author_view, name='add_author'),
    path('requests/', views.borrow_requests_view, name='borrow_requests'),
    path('approve/<int:request_id>/', views.approve_request_view, name='approve_request'),
    path('decline/<int:request_id>/', views.decline_request_view, name='decline_request'),
    path('mark-returned/<int:request_id>/', views.mark_returned_view, name='mark_returned'),
    path('edit-return-date/<int:request_id>/', views.edit_return_date, name='edit_return_date'),
    path('users/', views.user_list_view, name='user_list'),
    path('user-history/<int:user_id>/', views.user_borrow_history, name='user_borrow_history'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('due-reminders/', views.due_reminders_view, name='due_reminders'),
    path('send-reminder/<int:request_id>/', views.send_reminder_now, name='send_reminder_now'),

]
