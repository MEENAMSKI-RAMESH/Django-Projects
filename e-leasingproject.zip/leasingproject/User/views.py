from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import User, LeaseRequest, UserMessage, PropertyReview
from Administrator.models import Property, Payment
from Owner.models import Owner
from django.db.models import Q

# =============================
# Authentication
# =============================
def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = make_password(request.POST['password'])
        contact = request.POST['contact']
        address = request.POST['address']
        document = request.FILES.get('document')

        User.objects.create(
            username=username,
            email=email,
            password=password,
            contact_number=contact,
            address=address,
            identity_document=document
        )
        messages.success(request, "Registration successful. Please login.")
        return redirect('User:login')
    return render(request, 'User/register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            user = User.objects.get(username=username)
            if check_password(password, user.password):
                request.session['user_id'] = user.id
                return redirect('User:home')
            else:
                messages.error(request, "Invalid credentials")
        except User.DoesNotExist:
            messages.error(request, "Invalid credentials")
    return render(request, 'User/login.html')

def logout(request):
    request.session.flush()
    return redirect('index')

def home(request):
    if 'user_id' not in request.session:
        return redirect('User:login')
    return render(request, 'User/home.html')

# =============================
# Profile Management
# =============================
def profile(request):
    user = get_object_or_404(User, id=request.session['user_id'])
    return render(request, 'User/profile.html', {'user': user})

def edit_profile(request):
    user = get_object_or_404(User, id=request.session['user_id'])
    if request.method == 'POST':
        user.contact_number = request.POST['contact']
        user.address = request.POST['address']
        if 'profile_picture' in request.FILES:
            user.profile_picture = request.FILES['profile_picture']
        user.save()
        messages.success(request, "Profile updated.")
        return redirect('User:profile')
    return render(request, 'User/edit_profile.html', {'user': user})

# =============================
# Property Browsing
# =============================
def browse_properties(request):
    properties = Property.objects.filter(is_approved=True)
    return render(request, 'User/browse_properties.html', {'properties': properties})

def property_detail(request, property_id):
    property = get_object_or_404(Property, id=property_id)
    return render(request, 'User/property_detail.html', {'property': property})

def filter_properties(request):
    query = request.GET.get('q')
    properties = Property.objects.filter(
        Q(title__icontains=query) | Q(description__icontains=query), is_approved=True
    ) if query else Property.objects.filter(is_approved=True)
    return render(request, 'User/browse_properties.html', {'properties': properties, 'query': query})

# =============================
# Lease Offer
# =============================
def send_offer(request, property_id):
    if request.method == 'POST':
        LeaseRequest.objects.create(
            user_id=request.session['user_id'],
            property_id=property_id,
            offered_price=request.POST['offered_price'],
            message=request.POST['message']
        )
        messages.success(request, "Lease request sent.")
        return redirect('User:my_offers')
    return render(request, 'User/send_offer.html', {'property_id': property_id})

def my_offers(request):
    offers = LeaseRequest.objects.filter(user_id=request.session['user_id'])
    return render(request, 'User/my_offers.html', {'offers': offers})

# =============================
# Payments
# =============================
from django.utils import timezone
from Administrator.models import Payment
from User.models import User
from django.core.files.base import ContentFile
import io

def make_payment(request, offer_id):
    offer = get_object_or_404(LeaseRequest, id=offer_id, user_id=request.session['user_id'])

    if not offer.is_approved:
        messages.warning(request, "Offer is not approved yet.")
        return redirect('User:my_offers')

    if request.method == 'POST':
        invoice_text = f"""Invoice
-------------------
Property: {offer.property.title}
Amount: ₹{offer.offered_price}
Date: {timezone.now().strftime('%Y-%m-%d %H:%M')}
Status: Paid
"""
        invoice_file = ContentFile(invoice_text.encode('utf-8'))
        filename = f"invoice_user_{offer.id}.txt"

        # Save payment record
        payment = Payment.objects.create(
            lessee=offer.user,
            property=offer.property,
            amount=offer.offered_price,
            status='Paid',
            date_paid=timezone.now(),
        )
        payment.invoice_file.save(filename, invoice_file)

        offer.is_paid = True
        offer.save()

        messages.success(request, "Payment successful.")
        return redirect('User:my_offers')

    return render(request, 'User/make_payment.html', {'offer': offer})

def payment_history(request):
    payments = Payment.objects.filter(lessee_id=request.session['user_id'])
    return render(request, 'User/payment_history.html', {'payments': payments})

# =============================
# Messaging
# =============================
def messages_view(request):
    user_id = request.session['user_id']
    messages_list = UserMessage.objects.filter(Q(sender_id=user_id) | Q(receiver_id=user_id)).order_by('-timestamp')
    return render(request, 'User/messages.html', {'messages': messages_list})

def send_message(request, owner_id):
    if request.method == 'POST':
        UserMessage.objects.create(
            sender_id=request.session['user_id'],
            receiver_id=owner_id,
            content=request.POST['content']
        )
        return redirect('User:messages')
    owner = get_object_or_404(Owner, id=owner_id)
    return render(request, 'User/send_message.html', {'owner': owner})

# =============================
# Reviews
# =============================
def leave_review(request, property_id):
    if request.method == 'POST':
        PropertyReview.objects.create(
            user_id=request.session['user_id'],
            property_id=property_id,
            rating=request.POST['rating'],
            comment=request.POST['comment']
        )
        messages.success(request, "Review submitted.")
        return redirect('User:my_reviews')
    return render(request, 'User/leave_review.html', {'property_id': property_id})

def my_reviews(request):
    reviews = PropertyReview.objects.filter(user_id=request.session['user_id'])
    return render(request, 'User/my_reviews.html', {'reviews': reviews})
