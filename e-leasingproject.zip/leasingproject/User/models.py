from django.db import models
from django.utils import timezone

# ===============================
# 1. User Profile & Authentication
# ===============================
class User(models.Model):
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)  # Hash in production
    contact_number = models.CharField(max_length=20)
    address = models.TextField()
    profile_picture = models.ImageField(upload_to='user_profiles/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

# ===============================
# 2. Lease Request (Offer)
# ===============================
class LeaseRequest(models.Model):
    user = models.ForeignKey('User.User', on_delete=models.CASCADE)
    property = models.ForeignKey('Administrator.Property', on_delete=models.CASCADE)
    message = models.TextField(blank=True)
    offered_price = models.DecimalField(max_digits=10, decimal_places=2)
    is_approved = models.BooleanField(default=False)
    is_paid = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} → {self.property.title}"

# ===============================
# 3. Rent Payment (Reference Admin Payment)
# ===============================
# Reuse Administrator.models.Payment

# ===============================
# 4. Chat with Owner
# ===============================
class UserMessage(models.Model):
    sender = models.ForeignKey('User.User', on_delete=models.CASCADE, related_name='user_sent_messages')
    receiver = models.ForeignKey('Owner.Owner', on_delete=models.CASCADE, related_name='owner_received_messages')
    content = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender.username} → {self.receiver.username}"

# ===============================
# 5. Property Reviews
# ===============================
class PropertyReview(models.Model):
    user = models.ForeignKey('User.User', on_delete=models.CASCADE)
    property = models.ForeignKey('Administrator.Property', on_delete=models.CASCADE)
    rating = models.PositiveIntegerField()  # 1 to 5
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Review by {self.user.username} on {self.property.title}"
