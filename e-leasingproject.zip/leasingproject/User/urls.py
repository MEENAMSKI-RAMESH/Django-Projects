from django.urls import path
from . import views

app_name = 'User'

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('home/', views.home, name='home'),
    path('profile/', views.profile, name='profile'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),

    path('browse/', views.browse_properties, name='browse_properties'),
    path('property/<int:property_id>/', views.property_detail, name='property_detail'),
    path('filter/', views.filter_properties, name='filter_properties'),

    path('send_offer/<int:property_id>/', views.send_offer, name='send_offer'),
    path('my_offers/', views.my_offers, name='my_offers'),

    path('make_payment/<int:offer_id>/', views.make_payment, name='make_payment'),
    path('payment_history/', views.payment_history, name='payment_history'),

    path('messages/', views.messages_view, name='messages'),
    path('send_message/<int:owner_id>/', views.send_message, name='send_message'),

    path('review/<int:property_id>/', views.leave_review, name='leave_review'),
    path('my_reviews/', views.my_reviews, name='my_reviews'),
]
