from django.urls import path
from . import views

app_name = 'Owner'

urlpatterns = [
    # Authentication
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('home/', views.home, name='home'),

    # Profile Management
    path('profile/', views.view_profile, name='view_profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),

    # Listing Management
    path('listings/', views.view_listings, name='view_listings'),
    path('listing/add/', views.add_listing, name='add_listing'),
    path('listing/edit/<int:listing_id>/', views.edit_listing, name='edit_listing'),
    path('listing/delete/<int:listing_id>/', views.delete_listing, name='delete_listing'),

    # Offer Handling
    path('offers/', views.view_offers, name='view_offers'),
    path('offer/accept/<int:offer_id>/', views.accept_offer, name='accept_offer'),
    path('offer/discount/<int:listing_id>/', views.apply_discount, name='apply_discount'),

    # Rental Tracking
    path('rentals/', views.track_rentals, name='track_rentals'),
    path('payments/', views.view_payments, name='view_payments'),

    # Chat with Users
    path('messages/', views.view_messages, name='view_messages'),
    path('messages/send/<int:user_id>/', views.send_message, name='send_message'),

    # Reports Dashboard
    path('reports/', views.reports_dashboard, name='reports_dashboard'),
]
