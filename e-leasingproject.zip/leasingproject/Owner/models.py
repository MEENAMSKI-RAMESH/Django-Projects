from django.db import models
from django.utils import timezone

# -------------------------------------
# 1. Owner Profile
# -------------------------------------
class Owner(models.Model):
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)  # Hashed in production
    contact_number = models.CharField(max_length=20)
    address = models.TextField()
    profile_picture = models.ImageField(upload_to='owner_profiles/', null=True, blank=True)
    verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

# -------------------------------------
# 2. Offer Handling
# -------------------------------------
class Offer(models.Model):
    property = models.ForeignKey('Administrator.Property', on_delete=models.CASCADE)
    offered_by = models.ForeignKey('User.User', on_delete=models.CASCADE)
    offered_price = models.DecimalField(max_digits=10, decimal_places=2)
    message = models.TextField(blank=True)
    is_accepted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Offer by {self.offered_by.username} on {self.property.title}"

# -------------------------------------
# 3. Discounts on Listings
# -------------------------------------
class Discount(models.Model):
    property = models.ForeignKey('Administrator.Property', on_delete=models.CASCADE)
    discount_type = models.CharField(max_length=50, choices=[
        ('Seasonal', 'Seasonal'),
        ('Negotiated', 'Negotiated'),
    ])
    percentage = models.PositiveIntegerField(help_text="Enter value in %")
    start_date = models.DateField()
    end_date = models.DateField()

    def __str__(self):
        return f"{self.discount_type} - {self.percentage}% for {self.property.title}"

# -------------------------------------
# 4. Rental Tracking
# -------------------------------------
class Lease(models.Model):
    property = models.ForeignKey('Administrator.Property', on_delete=models.CASCADE)
    lessee = models.ForeignKey('User.User', on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.property.title} leased by {self.lessee.username}"

# -------------------------------------
# 5. Messaging with Users
# -------------------------------------
class Message(models.Model):
    sender = models.ForeignKey(
        Owner,
        on_delete=models.CASCADE,
        related_name='sent_messages'
    )
    receiver = models.ForeignKey(
        'User.User',
        on_delete=models.CASCADE,
        related_name='received_messages'
    )
    content = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender.username} → {self.receiver.username} @ {self.timestamp}"

# -------------------------------------
# 6. Owner Reports
# -------------------------------------
class OwnerReport(models.Model):
    owner = models.ForeignKey(Owner, on_delete=models.CASCADE)
    month = models.CharField(max_length=20)
    year = models.IntegerField()
    total_income = models.DecimalField(max_digits=12, decimal_places=2)
    occupancy_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        help_text="Percentage"
    )

    def __str__(self):
        return f"Report: {self.owner.username} - {self.month}/{self.year}"
