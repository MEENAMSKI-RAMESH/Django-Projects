from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import Owner, Offer, Discount, Lease, Message, OwnerReport
from Administrator.models import Property, Payment
from User.models import LeaseRequest, User
from datetime import date

# =============================
# Authentication
# =============================
def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = make_password(request.POST['password'])
        contact_number = request.POST['contact']
        address = request.POST['address']
        profile_picture = request.FILES.get('profile_picture')

        Owner.objects.create(
            username=username, email=email, password=password,
            contact_number=contact_number, address=address,
            profile_picture=profile_picture
        )
        messages.success(request, "Registration successful! Please wait for verification.")
        return redirect('Owner:login')
    return render(request, 'Owner/register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            owner = Owner.objects.get(username=username)
            if check_password(password, owner.password):
                if not owner.verified:
                    messages.warning(request, "Your account is not verified yet.")
                else:
                    request.session['owner_id'] = owner.id
                    return redirect('Owner:home')
            else:
                messages.error(request, "Invalid credentials")
        except Owner.DoesNotExist:
            messages.error(request, "Invalid credentials")
    return render(request, 'Owner/login.html')

def logout(request):
    request.session.flush()
    return redirect('index')

def home(request):
    if 'owner_id' not in request.session:
        return redirect('Owner:login')
    return render(request, 'Owner/home.html')

# =============================
# Profile Management
# =============================
def view_profile(request):
    owner = get_object_or_404(Owner, id=request.session['owner_id'])
    return render(request, 'Owner/profile.html', {'owner': owner})

def edit_profile(request):
    owner = get_object_or_404(Owner, id=request.session['owner_id'])
    if request.method == 'POST':
        owner.contact_number = request.POST['contact']
        owner.address = request.POST['address']
        if 'profile_picture' in request.FILES:
            owner.profile_picture = request.FILES['profile_picture']
        owner.save()
        messages.success(request, "Profile updated successfully.")
        return redirect('Owner:view_profile')
    return render(request, 'Owner/edit_profile.html', {'owner': owner})

# =============================
# Listing Management
# =============================
def view_listings(request):
    properties = Property.objects.filter(owner_id=request.session['owner_id'])
    return render(request, 'Owner/listings.html', {'properties': properties})

def add_listing(request):
    if request.method == 'POST':
        Property.objects.create(
            title=request.POST['title'],
            description=request.POST['description'],
            property_type=request.POST['property_type'],
            price=request.POST['price'],
            image=request.FILES.get('image'),
            owner_id=request.session['owner_id']
        )
        messages.success(request, "Listing added successfully.")
        return redirect('Owner:view_listings')
    return render(request, 'Owner/add_listing.html')

def edit_listing(request, listing_id):
    property = get_object_or_404(Property, id=listing_id, owner_id=request.session['owner_id'])
    if request.method == 'POST':
        property.title = request.POST['title']
        property.description = request.POST['description']
        property.property_type = request.POST['property_type']
        property.price = request.POST['price']
        if 'image' in request.FILES:
            property.image = request.FILES['image']
        property.save()
        messages.success(request, "Listing updated successfully.")
        return redirect('Owner:view_listings')
    return render(request, 'Owner/edit_listing.html', {'property': property})

def delete_listing(request, listing_id):
    property = get_object_or_404(Property, id=listing_id, owner_id=request.session['owner_id'])
    property.delete()
    messages.success(request, "Listing deleted successfully.")
    return redirect('Owner:view_listings')

# =============================
# Offer Handling
# =============================
def view_offers(request):
    offers = LeaseRequest.objects.filter(property__owner_id=request.session['owner_id'])
    return render(request, 'Owner/view_offers.html', {'offers': offers})

def accept_offer(request, offer_id):
    offer = get_object_or_404(LeaseRequest, id=offer_id, property__owner_id=request.session['owner_id'])
    offer.is_approved = True
    offer.save()
    messages.success(request, "Offer accepted.")
    return redirect('Owner:view_offers')

def apply_discount(request, listing_id):
    property = get_object_or_404(Property, id=listing_id, owner_id=request.session['owner_id'])
    if request.method == 'POST':
        Discount.objects.create(
            property=property,
            discount_type=request.POST['discount_type'],
            percentage=request.POST['percentage'],
            start_date=request.POST['start_date'],
            end_date=request.POST['end_date']
        )
        messages.success(request, "Discount applied.")
        return redirect('Owner:view_listings')
    return render(request, 'Owner/apply_discount.html', {'property': property})

# =============================
# Rental Tracking
# =============================
def track_rentals(request):
    leases = Lease.objects.filter(property__owner_id=request.session['owner_id'])
    return render(request, 'Owner/track_rentals.html', {'leases': leases})

def view_payments(request):
    payments = Payment.objects.filter(property__owner_id=request.session['owner_id'])
    return render(request, 'Owner/view_payments.html', {'payments': payments})

# =============================
# Chat with Users
# =============================
def view_messages(request):
    owner_id = request.session['owner_id']
    messages_list = Message.objects.filter(sender_id=owner_id) | Message.objects.filter(receiver_id=owner_id)
    messages_list = messages_list.order_by('-timestamp')
    return render(request, 'Owner/messages.html', {'messages': messages_list})

def send_message(request, user_id):
    if request.method == 'POST':
        Message.objects.create(
            sender_id=request.session['owner_id'],
            receiver_id=user_id,
            content=request.POST['content']
        )
        return redirect('Owner:view_messages')
    user = get_object_or_404(User, id=user_id)
    return render(request, 'Owner/send_message.html', {'user': user})

# =============================
# Reports Dashboard
# =============================
def reports_dashboard(request):
    reports = OwnerReport.objects.filter(owner_id=request.session['owner_id'])
    return render(request, 'Owner/reports.html', {'reports': reports})
