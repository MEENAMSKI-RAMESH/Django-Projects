from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Admintable, AdminLog, Property, Payment, Dispute, ChatMonitor, FraudReport
from Administrator import models

# ========================
# Index Page (Landing Page)
# ========================
def index(request):
    return render(request, 'index.html')


# ========================
# Admin Authentication
# ========================
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            admin = Admintable.objects.get(username=username, password=password)
            request.session['admin_id'] = admin.id
            return redirect('Administrator:home')
        except Admintable.DoesNotExist:
            messages.error(request, "Invalid login credentials")
    return render(request, 'Administrator/login.html')

def logout(request):
    request.session.flush()
    return redirect('index')

def home(request):
    if 'admin_id' not in request.session:
        return redirect('Administrator:login')
    return render(request, 'Administrator/home.html')


# ========================
# User Management
# ========================
def view_users(request):
    users = User.objects.all()
    owners = Owner.objects.all()
    staff_members = Staff.objects.all()
    return render(request, 'Administrator/view_users.html', {
        'users': users,
        'owners': owners,
        'staff_members': staff_members,
    })

def verify_owner(request, owner_id):
    owner = Owner.objects.get(id=owner_id)
    owner.verified = True
    owner.save()
    AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Verified owner {owner.username}")
    return redirect('Administrator:view_users')

def verify_staff(request, staff_id):
    staff = Staff.objects.get(id=staff_id)
    staff.verified = True
    staff.save()
    AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Verified staff {staff.username}")
    return redirect('Administrator:view_users')


# ========================
# Property Management
# ========================
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Property, AdminLog
from Owner.models import Owner  # Assuming owner is defined there
from django.core.files.storage import FileSystemStorage

# ========================
# Property Management
# ========================

def manage_properties(request):
    properties = Property.objects.all().order_by('-created_at')
    return render(request, 'Administrator/manage_properties.html', {'properties': properties})


def add_property(request):
    if request.method == 'POST':
        title = request.POST['title']
        description = request.POST['description']
        property_type = request.POST['property_type']
        price = request.POST['price']
        owner_id = request.POST['owner_id']
        image = request.FILES.get('image')

        owner = get_object_or_404(Owner, id=owner_id)
        
        property_obj = Property.objects.create(
            title=title,
            description=description,
            property_type=property_type,
            price=price,
            owner=owner,
            image=image
        )

        AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Added property '{property_obj.title}'")
        messages.success(request, "Property added successfully.")
        return redirect('Administrator:manage_properties')

    owners = Owner.objects.all()
    return render(request, 'Administrator/add_property.html', {'owners': owners})


def update_property(request, property_id):
    property = get_object_or_404(Property, id=property_id)
    
    if request.method == 'POST':
        property.title = request.POST['title']
        property.description = request.POST['description']
        property.property_type = request.POST['property_type']
        property.price = request.POST['price']

        if 'image' in request.FILES:
            property.image = request.FILES['image']

        property.save()
        AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Updated property '{property.title}'")
        messages.success(request, "Property updated successfully.")
        return redirect('Administrator:manage_properties')

    return render(request, 'Administrator/update_property.html', {'property': property})


def delete_property(request, property_id):
    property = get_object_or_404(Property, id=property_id)
    title = property.title
    property.delete()
    AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Deleted property '{title}'")
    messages.success(request, "Property deleted successfully.")
    return redirect('Administrator:manage_properties')


def approve_property(request, property_id):
    property = get_object_or_404(Property, id=property_id)
    property.is_approved = True
    property.save()
    AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Approved property '{property.title}'")
    return redirect('Administrator:manage_properties')


def reject_property(request, property_id):
    property = get_object_or_404(Property, id=property_id)
    property.is_approved = False
    property.save()
    AdminLog.objects.create(admin_id=request.session['admin_id'], action=f"Rejected property '{property.title}'")
    return redirect('Administrator:manage_properties')


import os
from django.http import HttpResponse
from django.conf import settings
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Payment, Dispute, AdminLog

# ========================
# Payment Monitoring
# ========================

def view_payments(request):
    payments = Payment.objects.select_related('lessee', 'property').all().order_by('-date_paid')
    disputes = Dispute.objects.select_related('payment').all()
    return render(request, 'Administrator/view_payments.html', {
        'payments': payments,
        'disputes': disputes
    })


def generate_invoice(request, payment_id):
    payment = get_object_or_404(Payment, id=payment_id)
    
    if not payment.invoice_file:
        messages.warning(request, "No invoice file attached to this payment.")
        return redirect('Administrator:view_payments')

    invoice_path = payment.invoice_file.path

    if not os.path.exists(invoice_path):
        messages.error(request, "Invoice file not found.")
        return redirect('Administrator:view_payments')

    with open(invoice_path, 'rb') as f:
        response = HttpResponse(f.read(), content_type="application/pdf")
        response['Content-Disposition'] = f'inline; filename="{os.path.basename(invoice_path)}"'
        return response


def resolve_dispute(request, payment_id):
    try:
        dispute = Dispute.objects.get(payment_id=payment_id)
        dispute.resolved = True
        dispute.admin_response = "Resolved by Admin"
        dispute.save()

        AdminLog.objects.create(
            admin_id=request.session['admin_id'],
            action=f"Resolved dispute for payment ID {payment_id}"
        )
        messages.success(request, "Dispute resolved successfully.")
    except Dispute.DoesNotExist:
        messages.error(request, "Dispute not found for this payment.")
    
    return redirect('Administrator:view_payments')

from django.shortcuts import render
from Owner.models import Owner
from Staff.models import Staff
from User.models import User
from .models import Property, Payment, Dispute

# ========================
# Reports & Analytics
# ========================
from django.db.models import Sum
from django.db.models import Sum  # Add this at the top

def reports(request):
    total_owners = Owner.objects.count()
    total_verified_owners = Owner.objects.filter(verified=True).count()

    total_staff = Staff.objects.count()
    total_verified_staff = Staff.objects.filter(verified=True).count()

    total_users = User.objects.count()
    total_properties = Property.objects.count()

    total_payments = Payment.objects.count()
    total_paid = Payment.objects.filter(status="Paid").count()
    total_revenue = Payment.objects.filter(status="Paid").aggregate(total=Sum('amount'))['total'] or 0

    total_disputes = Dispute.objects.count()
    resolved_disputes = Dispute.objects.filter(resolved=True).count()
    unresolved_disputes = total_disputes - resolved_disputes

    context = {
        'total_owners': total_owners,
        'total_verified_owners': total_verified_owners,
        'total_staff': total_staff,
        'total_verified_staff': total_verified_staff,
        'total_users': total_users,
        'total_properties': total_properties,
        'total_payments': total_payments,
        'total_paid': total_paid,
        'total_revenue': total_revenue,
        'total_disputes': total_disputes,
        'resolved_disputes': resolved_disputes,
        'unresolved_disputes': unresolved_disputes,
    }

    return render(request, 'Administrator/reports.html', context)


from django.http import JsonResponse
from Owner.models import Owner
from Staff.models import Staff
from User.models import User
from .models import Property

def user_activity_chart(request):
    data = {
        'labels': ['Owners', 'Staff', 'Users'],
        'data': [
            Owner.objects.count(),
            Staff.objects.count(),
            User.objects.count()
        ]
    }
    return JsonResponse(data)

def property_category_chart(request):
    categories = ['Residential', 'Commercial', 'Vehicle', 'Office']
    data = {
        'labels': categories,
        'data': [Property.objects.filter(property_type=cat).count() for cat in categories]
    }
    return JsonResponse(data)


# ========================
# Communication Oversight
# ========================
from django.db.models import Q

def chat_monitor(request):
    search_query = request.GET.get('q')
    if search_query:
        chats = ChatMonitor.objects.filter(
            Q(sender__icontains=search_query) |
            Q(receiver__icontains=search_query) |
            Q(message__icontains=search_query)
        ).order_by('-timestamp')
    else:
        chats = ChatMonitor.objects.all().order_by('-timestamp')
    
    return render(request, 'Administrator/chat_monitor.html', {
        'chats': chats,
        'query': search_query
    })

# ========================
# Fraud Detection
# ========================
def fraud_detection(request):
    reports = FraudReport.objects.all().order_by('-reported_at')

    if request.method == "POST":
        report_id = request.POST.get("report_id")
        action = request.POST.get("action")

        report = FraudReport.objects.get(id=report_id)
        if action == "verify":
            report.is_verified = True
        elif action == "unverify":
            report.is_verified = False
        report.save()

        AdminLog.objects.create(
            admin_id=request.session['admin_id'],
            action=f"{'Verified' if report.is_verified else 'Unverified'} fraud report for {report.property.title}"
        )

        return redirect('Administrator:fraud_detection')

    return render(request, 'Administrator/fraud_detection.html', {'reports': reports})
