from django.urls import path
from . import views

app_name = 'Administrator'

urlpatterns = [
    # Authentication
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('home/', views.home, name='home'),

    # User Management
    path('view_users/', views.view_users, name='view_users'),
    path('verify_owner/<int:owner_id>/', views.verify_owner, name='verify_owner'),
    path('verify_staff/<int:staff_id>/', views.verify_staff, name='verify_staff'),

    # Property Management
    path('manage_properties/', views.manage_properties, name='manage_properties'),
    path('add_property/', views.add_property, name='add_property'),
    path('update_property/', views.update_property, name='update_property'),
    path('delete_property/', views.delete_property, name='delete_property'),
    path('approve_property/<int:property_id>/', views.approve_property, name='approve_property'),
    path('reject_property/<int:property_id>/', views.reject_property, name='reject_property'),

    # Payment Monitoring
    path('view_payments/', views.view_payments, name='view_payments'),
    path('generate_invoice/<int:payment_id>/', views.generate_invoice, name='generate_invoice'),
    path('resolve_dispute/<int:payment_id>/', views.resolve_dispute, name='resolve_dispute'),

    # Analytics & Reports
    path('reports/', views.reports, name='reports'),
    path('user_activity_chart/', views.user_activity_chart, name='user_activity_chart'),
    path('property_category_chart/', views.property_category_chart, name='property_category_chart'),

    # Communication Oversight
    path('chat_monitor/', views.chat_monitor, name='chat_monitor'),

    # Security & Fraud Detection
    path('fraud_detection/', views.fraud_detection, name='fraud_detection'),
]
