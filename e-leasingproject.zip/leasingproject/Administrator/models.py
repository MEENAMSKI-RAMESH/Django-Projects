from django.db import models
from django.utils import timezone

# Admin Login Table
class Admintable(models.Model):
    username = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=100)  # Store hashed in production

    def __str__(self):
        return self.username


# Admin Log Table - For auditing admin actions
class AdminLog(models.Model):
    admin = models.ForeignKey(Admintable, on_delete=models.CASCADE)
    action = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.admin.username} - {self.action} @ {self.timestamp}"


# Property Model (if not already in another module like Owner)
class Property(models.Model):
    PROPERTY_TYPE_CHOICES = (
        ('Residential', 'Residential'),
        ('Commercial', 'Commercial'),
        ('Vehicle', 'Vehicle'),
        ('Office', 'Office'),
    )

    title = models.CharField(max_length=200)
    description = models.TextField()
    owner = models.ForeignKey('Owner.Owner', on_delete=models.CASCADE)
    property_type = models.CharField(max_length=50, choices=PROPERTY_TYPE_CHOICES)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    is_approved = models.BooleanField(default=False)
    image = models.ImageField(upload_to='property_images/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


# Payment Monitoring Table
class Payment(models.Model):
    lessee = models.ForeignKey('User.User', on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=[('Paid', 'Paid'), ('Pending', 'Pending')])
    date_paid = models.DateTimeField(null=True, blank=True)
    invoice_file = models.FileField(upload_to='invoices/', null=True, blank=True)

    def __str__(self):
        return f"{self.lessee} - {self.property.title} - {self.amount}"


# Dispute Table
class Dispute(models.Model):
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE)
    issue_description = models.TextField()
    resolved = models.BooleanField(default=False)
    admin_response = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Dispute for Payment ID {self.payment.id}"


# Chat Monitor Table (for Admin Oversight)
class ChatMonitor(models.Model):
    sender = models.CharField(max_length=100)
    receiver = models.CharField(max_length=100)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    flagged = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender} → {self.receiver} @ {self.timestamp}"


# Fraud Detection Table
class FraudReport(models.Model):
    reported_by = models.CharField(max_length=100)
    property = models.ForeignKey(Property, on_delete=models.SET_NULL, null=True)
    reason = models.TextField()
    is_verified = models.BooleanField(default=False)
    reported_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Fraud Report by {self.reported_by} on {self.property}"
