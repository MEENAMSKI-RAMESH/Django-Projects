from django.db import models
from django.utils import timezone
from Administrator.models import Property
from Owner.models import Owner
from User.models import User

# -----------------------------------------
# 1. Staff Profile (basic authentication)
# -----------------------------------------
class Staff(models.Model):
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)  # Hash in production
    contact_number = models.CharField(max_length=20)
    verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

# -----------------------------------------
# 2. Listing Verification Log
# -----------------------------------------
class ListingVerification(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    verified_at = models.DateTimeField(auto_now_add=True)
    remarks = models.TextField(blank=True)

    def __str__(self):
        return f"{self.staff.username} verified {self.property.title}"

# -----------------------------------------
# 3. Complaint Handling
# -----------------------------------------
class Complaint(models.Model):
    reported_by = models.ForeignKey(User, on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.SET_NULL, null=True)
    description = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)

    def __str__(self):
        return f"Complaint by {self.reported_by.username}"

class ComplaintResponse(models.Model):
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE)
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
    response_text = models.TextField()
    responded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Response to Complaint #{self.complaint.id}"

# -----------------------------------------
# 4. Owner Listing Assistance (optional tracking)
# -----------------------------------------
class ListingAssistance(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
    owner = models.ForeignKey(Owner, on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    assisted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.staff.username} helped {self.owner.username} on {self.property.title}"
