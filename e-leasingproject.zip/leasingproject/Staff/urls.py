from django.urls import path
from . import views

app_name = 'Staff'

urlpatterns = [
    # Authentication
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('home/', views.home, name='home'),

    # Assistance Operations
    path('verify_listings/', views.verify_listings, name='verify_listings'),
    path('verify_listing/<int:property_id>/', views.verify_listing, name='verify_listing'),
    path('support_users/', views.support_users, name='support_users'),

    # Complaint Handling
    path('view_complaints/', views.view_complaints, name='view_complaints'),
    path('respond_complaint/<int:complaint_id>/', views.respond_complaint, name='respond_complaint'),
    path('all_offers/', views.view_all_offers, name='view_all_offers'),


    # Data Entry Assistance
    path('add_listing_for_owner/', views.add_listing_for_owner, name='add_listing_for_owner'),
    path('manage_availability/', views.manage_availability, name='manage_availability'),
]
