from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import Staff, ListingVerification, Complaint, ComplaintResponse, ListingAssistance
from Administrator.models import Property
from Owner.models import Owner
from User.models import LeaseRequest, User
from django.utils import timezone

# =============================
# Authentication
# =============================
def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = make_password(request.POST['password'])
        contact_number = request.POST['contact']

        Staff.objects.create(
            username=username,
            email=email,
            password=password,
            contact_number=contact_number
        )
        messages.success(request, "Registration successful! Please wait for verification.")
        return redirect('Staff:login')
    return render(request, 'Staff/register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            staff = Staff.objects.get(username=username)
            if check_password(password, staff.password):
                if not staff.verified:
                    messages.warning(request, "Your account is not verified yet.")
                else:
                    request.session['staff_id'] = staff.id
                    return redirect('Staff:home')
            else:
                messages.error(request, "Invalid credentials")
        except Staff.DoesNotExist:
            messages.error(request, "Invalid credentials")
    return render(request, 'Staff/login.html')

def logout(request):
    request.session.flush()
    return redirect('index')

def home(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    return render(request, 'Staff/home.html')

# =============================
# Assistance Operations
# =============================
def verify_listings(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    properties = Property.objects.filter(is_approved=False)
    return render(request, 'Staff/verify_listings.html', {'properties': properties})

def verify_listing(request, property_id):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    property = get_object_or_404(Property, id=property_id)
    if request.method == 'POST':
        remarks = request.POST.get('remarks', '')
        property.is_approved = True
        property.save()
        ListingVerification.objects.create(
            staff_id=request.session['staff_id'],
            property=property,
            remarks=remarks
        )
        messages.success(request, "Property verified successfully.")
        return redirect('Staff:verify_listings')
    return render(request, 'Staff/verify_listing.html', {'property': property})

def support_users(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    users = User.objects.all()
    return render(request, 'Staff/support_users.html', {'users': users})

# =============================
# Complaint Handling
# =============================
def view_complaints(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    complaints = Complaint.objects.filter(resolved=False)
    return render(request, 'Staff/view_complaints.html', {'complaints': complaints})

def respond_complaint(request, complaint_id):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    complaint = get_object_or_404(Complaint, id=complaint_id)
    if request.method == 'POST':
        response_text = request.POST['response']
        ComplaintResponse.objects.create(
            complaint=complaint,
            staff_id=request.session['staff_id'],
            response_text=response_text
        )
        complaint.resolved = True
        complaint.save()
        messages.success(request, "Complaint resolved successfully.")
        return redirect('Staff:view_complaints')
    return render(request, 'Staff/respond_complaint.html', {'complaint': complaint})

# =============================
# Data Entry Assistance
# =============================
def add_listing_for_owner(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    if request.method == 'POST':
        title = request.POST['title']
        description = request.POST['description']
        property_type = request.POST['property_type']
        price = request.POST['price']
        owner_id = request.POST['owner_id']
        image = request.FILES.get('image')

        owner = get_object_or_404(Owner, id=owner_id)
        property = Property.objects.create(
            title=title,
            description=description,
            property_type=property_type,
            price=price,
            owner=owner,
            image=image,
            is_approved=False
        )
        ListingAssistance.objects.create(
            staff_id=request.session['staff_id'],
            owner=owner,
            property=property
        )
        messages.success(request, "Listing added on behalf of owner.")
        return redirect('Staff:add_listing_for_owner')

    owners = Owner.objects.filter(verified=True)
    return render(request, 'Staff/add_listing_for_owner.html', {'owners': owners})

def view_all_offers(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    offers = LeaseRequest.objects.all().select_related('property', 'user')
    return render(request, 'Staff/view_all_offers.html', {'offers': offers})

def manage_availability(request):
    if 'staff_id' not in request.session:
        return redirect('Staff:login')
    properties = Property.objects.all()
    return render(request, 'Staff/manage_availability.html', {'properties': properties})
