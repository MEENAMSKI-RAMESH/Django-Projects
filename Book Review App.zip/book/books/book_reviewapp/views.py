

from django.contrib import messages  
from django.shortcuts import render, redirect, get_object_or_404
from .models import Book, Review

def home_view(request):
    return render(request, 'home.html')

def addbook_view(request):
    if request.method == 'POST':
        title = request.POST['title']
        author = request.POST['author']
        description = request.POST['description']
        Book.objects.create(title=title, author=author, description=description)
        messages.success(request, "Book added successfully!")  
        return redirect('addbook')
    return render(request, 'addbook.html')

def bookreview_view(request):
    books = Book.objects.all()
    if request.method == 'POST':
        book_id = request.POST['book_id']
        review_text = request.POST['review_text']
        book = get_object_or_404(Book, id=book_id)
        Review.objects.create(book=book, review_text=review_text)
        messages.success(request, "Book Review added successfully!")  
        return redirect('addreview')
    return render(request, 'addreview.html', {'books': books})

def booklist_view(request):
    books = Book.objects.all()
    return render(request, 'booklist.html', {'books': books})

def deletebook_view(request):
    books = Book.objects.all()
    if request.method == 'POST':
        book_id = request.POST['book_id']
        Book.objects.filter(id=book_id).delete()
        messages.success(request, "Book details deleted successfully!")  
        return redirect('deletebook')
    return render(request, 'deletebook.html', {'books': books})
